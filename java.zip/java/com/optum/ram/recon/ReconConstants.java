package com.optum.ram.recon;

public class ReconConstants {
	
	public static final String RECON_FEATURES = "src/main/resources/recon/feature_files";
	
	public static final String RECON_RESULT_FORMAT = "json:target/test_results/recon.json";
	
	public static final String NO_MEM_DATA = "No MemberShip Data available in system for the plan %s"; 
	
	public static final String JOB_FEATURE_STATUS = "The Job Status Feature file is ";
	
	public static final String RECON_JOB_FAIL = "The RECON Job failed.Please check the Server log";

	public static final String NO_BNP_RECORDS = "No BNP[217] records are avilable in RECON details for the plan %s";
	
	public static final String FALSE_BNP = "BNP[217] records are not as per the requirement for the plan %s";

	public static final String NO_ERR_RECORDS = "No ERR[222] records are avilable in RECON details for the plan %s";
	
	public static final String FALSE_ERR = "ERR[222] records are not as per the requirement for the plan %s";

	public static final String NO_PSA_RECORDS = "No PSA[203] records are avilable in RECON details for the plan %s";

	public static final String FALSE_PSA = "PSA[203] records are not as per the requirement for the plan %s";

	public static final String NO_PDH_RECORDS = "No PDH[221] records are avilable in RECON details for the plan %s";

	public static final String FALSE_PDH = "PDH[221] records are not as per the requirement for the plan %s";

	public static final String NO_PDL_RECORDS = "No PDL[202] records are avilable in RECON details for the plan %s";;

	public static final String FALSE_PDL = "PDL[202] records are not as per the requirement for the plan %s";

	public static final String FALSE_PNB = "PNB[200] records are not as per the requirement for the plan %s";

	public static final String NO_PNB_RECORDS = "No PNB[200] records are avilable in RECON details for the plan %s";;
}
