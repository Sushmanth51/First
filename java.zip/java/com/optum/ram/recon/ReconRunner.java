package com.optum.ram.recon;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

import com.optum.facets.atdd.common.utils.ConnectionHelper;
import com.optum.facets.atdd.common.utils.FlatFileProcessor;
import com.optum.ram.atdd.common.utils.CSPCommonTestBase;
import com.optum.ram.atdd.common.utils.RAMCommonDBQuires;
import com.optum.ram.invoice.InvoiceCommon;
import com.optum.ram.ramui.PageModules;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@CucumberOptions(features = ReconConstants.RECON_FEATURES, format = {
		ReconConstants.RECON_RESULT_FORMAT }, snippets = SnippetType.CAMELCASE)
public class ReconRunner extends CSPCommonTestBase{
	public static String eligiblityUploadExtractTDFilePath = "src/main/resources/eligibilityUpload/testdata/EligibilityUpload_TestData.xls";
	public static String eligiblityUploadExtractTDConfigTable = "ELIGIBILITY_UPLOAD_TEST_DATA_CONFIG_TABLE";
	public static String eligiblityUploadExtractTDActualTable = "ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE";
	static boolean jobStatus = false;
	String EMPTY = "";
	
	/*public static void main(String[] args) throws Exception {
		ReconRunner rubber = new ReconRunner();
		//rubber.checkMemberDataPresence("VAMDN");
		rubber.checkPNBpresence("UHGVA");	
		rubber.verifyPNBresult("UHGVA");	
	}*/
	
	@BeforeClass
	public void setUpClass()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException, IOException {
		super.setUpClass();
		try {

			ConnectionHelper.sqliteConnection = ConnectionHelper
					.openSqliteConnection("src/main/resources/eligibilityUpload/db_file/eligibilityUpload.db");
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String strcolnames = FlatFileProcessor.getExcelColumn(eligiblityUploadExtractTDFilePath, "Global");
		FlatFileProcessor.createConfigTable(eligiblityUploadExtractTDConfigTable, strcolnames);
		List myList;
		try {

			myList = FlatFileProcessor.readExcelData(eligiblityUploadExtractTDFilePath, "Global");
			FlatFileProcessor.createAndPopulateDetailsTableFromDataFile(myList, eligiblityUploadExtractTDConfigTable,
					eligiblityUploadExtractTDActualTable, 1, myList.size(), true);
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * TC052
	 * @param plan
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 * Method to check Member info
	 */
	@Given("^Member information should be available in sytem for plan \"([^\"]*)\"$")
	public void checkMemberDataPresence(String plan) throws ClassNotFoundException, SQLException, IOException {
		boolean checkStatus = false;
		InvoiceCommon common = new InvoiceCommon();
		try {
			checkStatus = common.checkMemberDataPresence(plan);
			if (!checkStatus) {
				Assert.fail(String.format(ReconConstants.NO_MEM_DATA,plan));
			}
		} catch (Exception e) {
			Assert.fail(String.format(ReconConstants.NO_MEM_DATA,plan)+e.getMessage());
		}
	}
	
	/**
	 * TC052
	 * @param plan
	 * @param revType
	 * @param seqRevId
	 * Method to trigger ReconBatch
	 */
	@When("^The Recon Job Should run with out any errors for plan \"([^\"]*)\"$")
	public void triggerReconBatch(String plan) {
		ReconCommon common = new ReconCommon();
		jobStatus = common.triggerReconJob(plan);
		if (!jobStatus) {
			Assert.fail(ReconConstants.RECON_JOB_FAIL);
		}
	}
	
	/**
	 * TC052
	 * Method to check the status of the batch
	 */
	@Then("^Verify status of the Recon batch execution$")
	public void verifyReconBatchStatus() {
		if (!jobStatus) {
			Assert.fail(ReconConstants.RECON_JOB_FAIL);
		}
	}

	
	/**
	 * @TC053
	 * @param plan
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check presence of BNP records
	 */
	@When("^If Recon Error BNP 217 available in RECON Details for the plan \"([^\"]*)\"$")
	public void checkBNPpresence(String plan) throws ClassNotFoundException, IOException, SQLException{
		boolean checkStatus = false;
		ReconCommon common = new ReconCommon();
		try {
			checkStatus = common.checkBNPPresence(plan);
			if (!checkStatus) {
				Assert.fail(String.format(ReconConstants.NO_BNP_RECORDS, plan));
			}
		} catch (Exception e) {
			Assert.fail(String.format(ReconConstants.NO_BNP_RECORDS, plan)+e.getMessage());
		}
	}
	
	/**
	 * @TC053
	 * @param plan
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to validate the BNP records
	 */
	@Then("^Verify such records persisited due when there is Invoice and there is no entry in Payment for plan \"([^\"]*)\"$")
	public void verifyBNPresult(String plan) throws ClassNotFoundException, IOException, SQLException {
		String medicaidIds;
		ReconCommon common = new ReconCommon();
		try {
			medicaidIds = common.verifyBNPresult(plan);
			if (!EMPTY.equalsIgnoreCase(medicaidIds)) {
				Assert.fail(String.format(ReconConstants.FALSE_BNP, plan+"-"+medicaidIds));
			}
		} catch (Exception e) {
			Assert.fail(String.format(ReconConstants.FALSE_BNP, plan) + e.getMessage());
		}
	}
	
	/**
	 * @TC054
	 * @param plan
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check ERR presence
	 */
	@When("^If Recon Error ERR 222 available in RECON Details for the plan \"([^\"]*)\"$")
	public void checkERRpresence(String plan) throws ClassNotFoundException, IOException, SQLException{
		boolean checkStatus = false;
		ReconCommon common = new ReconCommon();
		try {
			checkStatus = common.checkERRPresence(plan);
			if (!checkStatus) {
				Assert.fail(String.format(ReconConstants.NO_ERR_RECORDS, plan));
			}
		} catch (Exception e) {
			Assert.fail(String.format(ReconConstants.NO_ERR_RECORDS, plan)+e.getMessage());
		}
	}
	
	/**
	 * @TC054
	 * @param plan
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to validate the ERR records 
	 */
	@Then("^Verify such records persisited due when corresponding invoice has any of the errors MKM, DMI, MES, IKM, NRF & MRF for plan \"([^\"]*)\"$")
	public void verifyERRresult(String plan) throws ClassNotFoundException, IOException, SQLException {
		String medicaidIds;
		ReconCommon common = new ReconCommon();
		try {
			medicaidIds = common.verifyERRresult(plan);
			if (!EMPTY.equalsIgnoreCase(medicaidIds)) {
				Assert.fail(String.format(ReconConstants.FALSE_ERR, plan+"-"+medicaidIds));
			}
		} catch (Exception e) {
			Assert.fail(String.format(ReconConstants.FALSE_ERR, plan) + e.getMessage());
		}
	}
	
	/**
	 * @TC055
	 * @param plan
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check the presence of PSA records
	 */
	@When("^If Recon status PSA 203 available in RECON Details for the plan \"([^\"]*)\"$")
	public void checkPSApresence(String plan) throws ClassNotFoundException, IOException, SQLException{
		boolean checkStatus = false;
		ReconCommon common = new ReconCommon();
		try {
			checkStatus = common.checkPSApresence(plan);
			if (!checkStatus) {
				Assert.fail(String.format(ReconConstants.NO_PSA_RECORDS, plan));
			}
		} catch (Exception e) {
			Assert.fail(String.format(ReconConstants.NO_PSA_RECORDS, plan)+e.getMessage());
		}
	}
	
	/**
	 * @TC055
	 * @param plan
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Methods to validate the PSA records
	 */
	@Then("^Verify such records persisited due when corresponding invoice and payment amount is same \"([^\"]*)\"$")
	public void verifyPSAresult(String plan) throws ClassNotFoundException, IOException, SQLException {
		String medicaidIds;
		ReconCommon common = new ReconCommon();
		try {
			medicaidIds = common.verifyPSAresult(plan);
			if (!EMPTY.equalsIgnoreCase(medicaidIds)) {
				Assert.fail(String.format(ReconConstants.FALSE_PSA, plan+"-"+medicaidIds));
			}
		} catch (Exception e) {
			Assert.fail(String.format(ReconConstants.FALSE_PSA, plan) + e.getMessage());
		}
	}
	
	/**
	 * @TC056
	 * @param plan
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check the presence of PDH records
	 */
	@When("^If Recon status PDH 221 available in RECON Details for the plan \"([^\"]*)\"$")
	public void checkPDHpresence(String plan) throws ClassNotFoundException, IOException, SQLException{
		boolean checkStatus = false;
		ReconCommon common = new ReconCommon();
		try {
			checkStatus = common.checkPDHpresence(plan);
			if (!checkStatus) {
				Assert.fail(String.format(ReconConstants.NO_PDH_RECORDS, plan));
			}
		} catch (Exception e) {
			Assert.fail(String.format(ReconConstants.NO_PDH_RECORDS, plan)+e.getMessage());
		}
	}
	
	/**
	 * @TC056
	 * @param plan
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Methods to validate the PDH records
	 */
	@Then("^Verify such records persisited due when corresponding PAYMENT is greater than INVOICE amount \"([^\"]*)\"$")
	public void verifyPDHresult(String plan) throws ClassNotFoundException, IOException, SQLException {
		String medicaidIds;
		ReconCommon common = new ReconCommon();
		try {
			medicaidIds = common.verifyPDHresult(plan);
			if (!EMPTY.equalsIgnoreCase(medicaidIds)) {
				Assert.fail(String.format(ReconConstants.FALSE_PDH, plan+"-"+medicaidIds));
			}
		} catch (Exception e) {
			Assert.fail(String.format(ReconConstants.FALSE_PDH, plan) + e.getMessage());
		}
	}
	
	/**
	 * @TC057
	 * @param plan
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check the presence of PDL records
	 */
	@When("^If Recon status PDL 202 available in RECON Details for the plan \"([^\"]*)\"$")
	public void checkPDLpresence(String plan) throws ClassNotFoundException, IOException, SQLException{
		boolean checkStatus = false;
		ReconCommon common = new ReconCommon();
		try {
			checkStatus = common.checkPDLpresence(plan);
			if (!checkStatus) {
				Assert.fail(String.format(ReconConstants.NO_PDL_RECORDS, plan));
			}
		} catch (Exception e) {
			Assert.fail(String.format(ReconConstants.NO_PDL_RECORDS, plan)+e.getMessage());
		}
	}
	
	/**
	 * @TC057
	 * @param plan
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Methods to validate the PDL records
	 */
	@Then("^Verify such records persisited due when corresponding PAYMENT is lesser than INVOICE amount \"([^\"]*)\"$")
	public void verifyPDLresult(String plan) throws ClassNotFoundException, IOException, SQLException {
		String medicaidIds;
		ReconCommon common = new ReconCommon();
		try {
			medicaidIds = common.verifyPDLresult(plan);
			if (!EMPTY.equalsIgnoreCase(medicaidIds)) {
				Assert.fail(String.format(ReconConstants.FALSE_PDL, plan+"-"+medicaidIds));
			}
		} catch (Exception e) {
			Assert.fail(String.format(ReconConstants.FALSE_PDL, plan) + e.getMessage());
		}
	}
	
	/**
	 * @TC058
	 * @param plan
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check presence of PNB records
	 */
	@When("^If Recon status PNB 200 available in RECON Details for the plan \"([^\"]*)\"$")
	public void checkPNBpresence(String plan) throws ClassNotFoundException, IOException, SQLException{
		boolean checkStatus = false;
		ReconCommon common = new ReconCommon();
		try {
			checkStatus = common.checkPNBPresence(plan);
			if (!checkStatus) {
				Assert.fail(String.format(ReconConstants.NO_PNB_RECORDS, plan));
			}
		} catch (Exception e) {
			Assert.fail(String.format(ReconConstants.NO_PNB_RECORDS, plan)+e.getMessage());
		}
	}
	
	/**
	 * @TC058
	 * @param plan
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to validate the PNB records
	 */
	@Then("^Verify such records persisited due when there is Payment and there is no entry in Invoice for plan \"([^\"]*)\"$")
	public void verifyPNBresult(String plan) throws ClassNotFoundException, IOException, SQLException {
		String medicaidIds;
		ReconCommon common = new ReconCommon();
		try {
			medicaidIds = common.verifyPNBresult(plan);
			if (!EMPTY.equalsIgnoreCase(medicaidIds)) {
				Assert.fail(String.format(ReconConstants.FALSE_PNB, plan+"-"+medicaidIds));
			}
		} catch (Exception e) {
			Assert.fail(String.format(ReconConstants.FALSE_PNB, plan) + e.getMessage());
		}
	}
	

}
