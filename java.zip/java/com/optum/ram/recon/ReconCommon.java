package com.optum.ram.recon;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.testng.AssertJUnit;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.optum.ram.atdd.common.utils.CSPPropertyReader;
import com.optum.ram.atdd.common.utils.RAMCommonDBQuires;

public class ReconCommon {
	
	private static final Log log= LogFactory.getLog(ReconCommon.class);
	/**
	 * @param plan
	 * @param revId
	 * @param seqRevId
	 * @return Reusable method to trigger Recon job
	 */
	public boolean triggerReconJob(String plan) {
		boolean jobStatus = false;
		try {
			jobStatus = execute_unix_job_jsch(
					String.format(CSPPropertyReader.getReconJob(),plan),
					CSPPropertyReader.getUnixServer(), CSPPropertyReader.getUnixUsername(),
					CSPPropertyReader.getUnixPassword());
			System.out.println(ReconConstants.JOB_FEATURE_STATUS + jobStatus);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jobStatus;

	}
	
	
	
	public boolean execute_unix_job_jsch(String JobName,String UnixHost,String UnixUser,String UnixPass) throws Exception
	{
		System.out.println("The JobName is :" + JobName);

		String JobLog = null;
		JSch jsch = new JSch();
		Channel channel = null;
		Session session = null;
		boolean flag = false;

		try {
			session = jsch.getSession(UnixUser, UnixHost, 22);
			session.setPassword(UnixPass);
			session.setConfig("StrictHostKeyChecking", "no");
			session.connect();
			String cmd = "cd " + "" + CSPPropertyReader.getshellJobPath() + ";" + JobName + " ";
			channel = session.openChannel("shell");
			OutputStream ops = channel.getOutputStream();
			PrintStream ps = new PrintStream(ops, true);
			channel.connect();
			ps.println(cmd);
			InputStream in = channel.getInputStream();
			byte[] tmp = new byte[1024];
			while (true) {
				while (in.available() > 0) {
					int i = in.read(tmp, 0, 1024);
					if (i < 0)
						break;
					JobLog += new String(tmp, 0, i);
					System.out.println(JobLog);
				}
				if (JobLog != null) {
					if (JobLog.contains("INFO: Recon Process ended")) {
						log.info("The Shell Job executed Successfully for " + JobName);
						flag = true;

						if (JobLog.contains("Process status 'F' is updated in the AUDIT_MASTER table")) {
							log.error("The Shell Job " + JobName
									+ " is Failed.Please check the Server Log file for more details");
							AssertJUnit.fail("The Shell Job " + JobName
									+ " is Failed.Please check the Server Log file for more details");
							flag = false;
						}
						break;
					}

					try {
						Thread.sleep(1000);
					} catch (Exception ee) {
					}
				}
			}
		} catch (Exception e) {
			log.error("Error in executing the Job" + e);
			e.printStackTrace();
		} finally {
			channel.disconnect();
			session.disconnect();
		}
		return flag;
	}

	public boolean reconJobHold(String JobName,String UnixHost,String UnixUser,String UnixPass,String planName,String seqRevenueId) throws Exception{
		System.out.println("The JobName is :" + JobName);
		
		String JobLog = null;
		JSch jsch = new JSch();
		Channel channel = null;
		Session session = null;
		boolean flag = false;

		try {
			session = jsch.getSession(UnixUser, UnixHost, 22);
			session.setPassword(UnixPass);
			session.setConfig("StrictHostKeyChecking", "no");
			session.connect();
			String cmd = "cd " + "" + CSPPropertyReader.getshellJobPath() + ";" + JobName + " ";
			channel = session.openChannel("shell");
			OutputStream ops = channel.getOutputStream();
			PrintStream ps = new PrintStream(ops, true);
			channel.connect();
			ps.println(cmd);
			InputStream in = channel.getInputStream();
			byte[] tmp = new byte[1024];
			while (true) {
				while (in.available() > 0) {
					int i = in.read(tmp, 0, 1024);
					if (i < 0)
						break;
					JobLog += new String(tmp, 0, i);
					System.out.println(JobLog);
				}
				if (JobLog != null) {
					if (JobLog.contains("INFO: Reconciliation process for "+planName+" "+seqRevenueId+" is on hold")) {
						log.info("The Shell Job executed Successfully for " + JobName);
						flag = true;

						if (JobLog.contains("Process status 'F' is updated in the AUDIT_MASTER table")) {
							log.error("The Shell Job " + JobName
									+ " is Failed.Please check the Server Log file for more details");
							AssertJUnit.fail("The Shell Job " + JobName
									+ " is Failed.Please check the Server Log file for more details");
							flag = false;
						}
						break;
					}

					try {
						Thread.sleep(1000);
					} catch (Exception ee) {
					}
				}
			}
		} catch (Exception e) {
			log.error("Error in executing the Job" + e);
			e.printStackTrace();
		} finally {
			channel.disconnect();
			session.disconnect();
		}
		return flag;
	}


	/**
	 * @param plan
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check presence of BNP records
	 */
	public boolean checkBNPPresence(String plan) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires common = new RAMCommonDBQuires();
			return common.booleanForString(String.format(ReconDBqueries.CHECK_RECON_ERROR, plan, "217"));
		}



	/**
	 * @param plan
	 * @return
	 * @throws Exception
	 * Method to validate BNP records
	 */
	public String verifyBNPresult(String plan) throws Exception {
		return verifyReconResult(plan, String.format(ReconDBqueries.GET_FALSE_BNP, plan, plan, plan, plan));
	}

	public String verifyReconResult(String plan, String qry) throws Exception{
		RAMCommonDBQuires common = new RAMCommonDBQuires();
		List<String> medicaidIds = new ArrayList<String>();
		String listString = "";
		try{
			medicaidIds = common.getSingleColumnListforQuery(qry);
		}catch (Exception e) {
			throw new Exception(e);
		}

		for (String s : medicaidIds)
		{
		    listString += s + "\t";
		}
		return listString;
		
	}

	/**
	 * @param plan
	 * @return
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check ERR presence
	 */
	public boolean checkERRPresence(String plan) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires common = new RAMCommonDBQuires();
		return common.booleanForString(String.format(ReconDBqueries.CHECK_RECON_ERROR, plan, "222"));
	}



	/**
	 * @param plan
	 * @return
	 * @throws Exception
	 * Method to validate the ERR records
	 */
	public String verifyERRresult(String plan) throws Exception {
		return verifyReconResult(plan, String.format(ReconDBqueries.GET_FALSE_ERR, plan, plan, plan));
	}



	/**
	 * @param plan
	 * @return
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check the presence of PSA records
	 */
	public boolean checkPSApresence(String plan) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires common = new RAMCommonDBQuires();
		return common.booleanForString(String.format(ReconDBqueries.CHECK_RECON_PSA, plan, "203"));
	}



	/**
	 * @param plan
	 * @return
	 * @throws Exception
	 * Method to validate the PSA records
	 */
	public String verifyPSAresult(String plan) throws Exception {
		return verifyReconResult(plan, String.format(ReconDBqueries.GET_FALSE_PSA, plan, plan, plan, plan, plan));
	}

	/**
	 * @param plan
	 * @return
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check the presence of PDH records
	 */
	public boolean checkPDHpresence(String plan) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires common = new RAMCommonDBQuires();
		return common.booleanForString(String.format(ReconDBqueries.CHECK_RECON_ERROR, plan, "221"));
	}

	/**
	 * @param plan
	 * @return
	 * @throws Exception
	 * Methods to validate the PDH records
	 */
	public String verifyPDHresult(String plan) throws Exception {
		return verifyReconResult(plan, String.format(ReconDBqueries.GET_FALSE_PDH, plan, plan, plan, plan));
	}



	/**
	 * @param plan
	 * @return
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check presence of PDL records
	 */
	public boolean checkPDLpresence(String plan) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires common = new RAMCommonDBQuires();
		return common.booleanForString(String.format(ReconDBqueries.CHECK_RECON_ERROR, plan, "202"));
	}



	/**
	 * @param plan
	 * @return
	 * @throws Exception
	 * Methods to validate the PDL records
	 */
	public String verifyPDLresult(String plan) throws Exception {
		return verifyReconResult(plan, String.format(ReconDBqueries.GET_FALSE_PDL, plan, plan, plan, plan));
	}



	public boolean checkPNBPresence(String plan) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires common = new RAMCommonDBQuires();
		return common.booleanForString(String.format(ReconDBqueries.CHECK_RECON_ERROR, plan, "200"));
	}



	public String verifyPNBresult(String plan) throws Exception {
		return verifyReconResult(plan, String.format(ReconDBqueries.GET_FALSE_PNB, plan, plan, plan, plan));
	}

}
