package com.optum.ram.rateUpload;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.testng.Assert;

import com.optum.facets.atdd.common.utils.ConnectionHelper;
import com.optum.facets.atdd.common.utils.DatabaseProcessor;

public class RateUploadDBqueries {
	public static final String RATE_UPLOAD_STATUS = "select STATUS from ram_rate_upload_header where company_code='%s' and  FILE_NAME='%s'";
	public static final String RISK_GROUPS_COUNT = "select count(*) from(select distinct risk_group from ram_rate_categ_matrix where company_code='%s')";
	public static final String RISK_GROUP_FIELDS = "SELECT CONCAT( REPLACE(NVL(rate_desc,' '),' ',''), REPLACE(NVL(TO_CHAR(effective_date,'MM/DD/YYYY'),''),' ','')"
			+ " || REPLACE(NVL(TO_CHAR(term_date, 'MM/DD/YYYY'),''),' ','')       "
			+ " ||                                                                "
			+ " (SELECT NVL(TRIM(SUM(rate)),0.00)                                 "
			+ " FROM ram_rate_categ_matrix rrcm                                   "
			+ " WHERE rrcm.effective_date         = rrc.effective_date            "
			+ " AND rrcm.seq_revenue_id           = rrc.seq_revenue_id            "
			+ " AND rrcm.term_date                = rrc.term_date                 "
			+ " AND rrcm.risk_group               = rrc.risk_group                "
			+ " AND (rrcm.age_from               IS NULL                          "
			+ " OR rrcm.age_from                  = rrc.age_from)                 "
			+ " AND (rrcm.age_to                 IS NULL                          "
			+ " OR rrcm.age_to                    = rrc.age_to )                  "
			+ " AND (rrcm.county                 IS NULL                          "
			+ " OR rrcm.county                    = rrc.county)                   "
			+ " AND (rrcm.gender                 IS NULL                          "
			+ " OR rrcm.gender                    = rrc.gender)                   "
			+ " AND (rrcm.category_of_assistance IS NULL                          "
			+ " OR rrcm.category_of_assistance    = rrc.category_of_assistance)   "
			+ " AND (rrcm.gl_product             IS NULL                          "
			+ " OR rrcm.gl_product                = rrc.gl_product)               "
			+ " AND (rrcm.proration_formula      IS NULL                          "
			+ " OR rrcm.proration_formula         = rrc.proration_formula)        "
			+ " AND (rrcm.product_code           IS NULL                          "
			+ " OR rrcm.product_code              = rrc.product_code)             "
			+ " AND (rrcm.status                 IS NULL                          "
			+ " OR rrcm.status                    = rrc.status)                   "
			+ " AND (rrcm.user_defined_1         IS NULL                          "
			+ " OR rrcm.user_defined_1            = rrc.user_defined_1)           "
			+ " AND (rrcm.user_defined_2         IS NULL                          "
			+ " OR rrcm.user_defined_2            = rrc.user_defined_2)           "
			+ " )                                                                 "
			+ " || REPLACE(NVL(gender,''),' ','')                                 "
			+ " || REPLACE(NVL( county,' '),' ','')                               "
			+ " || REPLACE(NVL(TO_CHAR(AGE_FROM),' '),' ','')                     "
			+ " || REPLACE(NVL(TO_CHAR(AGE_TO),' '),' ','')                       "
			+ " ||REPLACE(NVL(TO_CHAR(GL_PRODUCT),' '),' ','')                    "
			+ " || REPLACE(NVL(CATEGORY_OF_ASSISTANCE,' '),' ','')                "
			+ " ||REPLACE(NVL(PROGRAM_STATUS_CODE,' '),' ','')                    "
			+ " ||REPLACE(NVL(TRIM(PRODUCT_CODE),' '),' ','')                     "
			+ " ||                                                                "
			+ " CASE                                                              "
			+ "   WHEN STATUS='Y'                                                 "
			+ "   THEN 'Active'                                                   "
			+ "   WHEN STATUS='V'                                                 "
			+ "   THEN 'VOIDED'                                                   "
			+ " END                                                               "
			+ " || REPLACE(NVL(PRORATION_FORMULA,' '),' ','') ) AS RES            "
			+ "FROM ram_rate_categ_matrix rrc                                     "
			+ "WHERE RISK_GROUP          IN ('%s')                            "
			+ "AND (COMPOSITE_REVENUE_ID IS NULL                                  "
			+ "OR seq_revenue_id          = COMPOSITE_REVENUE_ID)                 "
			+ "ORDER BY effective_date DESC,                                      " + "RISK_GROUP ASC";

	public static final String PLANCODES = " SELECT "
			+ " plan_code,                                                        "
			+ " risk_group,                                                       "
			+ " rate_desc,                                                        "
			+ " revenue_type,                                                     "
			+ " NVL(TO_CHAR (effective_date, 'MM/DD/YYYY'),'') AS effective_date, "
			+ " NVL(TO_CHAR (term_date, 'MM/DD/YYYY'),'' )    AS term_date,       "
			+ "   rate,                                                           "
			+ "   gender,                                                         "
			+ " NVL(county,'')                                                    "
			+ "   age_from,                                                       "
			+ " age_to,                                                           "
			+ "  gl_product,                                                      "
			+ " CATEGORY_OF_ASSISTANCE,                                           "
			+ " PROGRAM_STATUS_CODE,                                              "
			+ " PRODUCT_CODE,                                                     "
			+ "   status,                                                         "
			+ " PRORATION_FORMULA                                                 "
			+ "FROM ram_rate_matrix                                               " + "WHERE    "
			+ "RISK_GROUP        IN ('%s')                                    "
			+ "AND (seq_revenue_id    = '110054'                                  "
			+ "OR base_seq_revenue_id = '110054' )                                " + "AND upper(STATUS)     != 'V'	"
			+ "AND revenue_type='%s'									 " + "ORDER BY effective_date DESC";

	public static final String RATES_REVENUE_TYPE = "select distinct revenue_type from ram_revenue_stream_history where seq_revenue_id "
			+ "IN((select distinct seq_revenue_id from ram_rate_matrix where company_code='%s' and seq_revenue_id<>'110057'))";

	// Service tab
	public static final String SEQ_REVENUE_ID = "select seq_revenue_id from ram_revenue_stream  where plan_name='%s' and revenue_type='%s'";
	// TRACKING_OVERALL_VALD
	public static final String MEMBERSEARCHPAGE_DBRESULTS = "SELECT det.medicaid_id,     "
			+ " demo.subscriber_id      AS subscriber_id ,								  "
			+ " demo.prev_subscriber_id AS prev_subscriber_id,                             "
			+ " det.first_name          AS first_name,                                     "
			+ " det.last_name           AS last_name,                                      "
			+ " CASE                                                                       "
			+ "   WHEN demo.social_sec_no IS NOT NULL                                      "
			+ "   THEN 'xxx-xx-'                                                           "
			+ "     || SUBSTR (demo.social_sec_no,6,4)                                     "
			+ " END                                          AS Soc_Sec,                   "
			+ " TO_CHAR(det.date_of_birth,'MM/dd/yyyy')      AS Dob,                       "
			+ " demo.gender                                  AS gender,                    "
			+ " det.risk_group                               AS risk_group,                "
			+ " det.plan_code                                AS plan_code,                 "
			+ " det.RECONCILIATION_KEY                       AS recon_key,                 "
			+ " TO_CHAR(det.revenue_start_date,'MM/dd/yyyy') AS revenue_start_date,        "
			+ " TO_CHAR(det.revenue_end_date,'MM/dd/yyyy')   AS revenue_end_date,          "
			+ " det.invoice_amount                           AS billed_Amt,                "
			+ " det.payment_amount                           AS paid_amt,                  "
			+ " det.ADJUSTMENT_AMOUNT                        AS adj_amount,                "
			+ " NVL(TAX_AMOUNT,0),                                                                "
			+ " (SELECT SUBSTR(code_desc, 0, 3)                                            "
			+ " FROM ram_code_master                                                       "
			+ " WHERE code_value = det.recon_status                                        "
			+ " AND rownum       = 1                                                       "
			+ " )                AS System_Status,                                         "
			+ " (SELECT SUBSTR(code_desc, 0, 3)                                            "
			+ " FROM ram_code_master                                                       "
			+ " WHERE code_value = det.user_status                                         "
			+ " AND rownum       = 1                                                       "
			+ " ) AS user_status                                                           "
			+ "FROM ram_reconciliation_detail det,                                         "
			+ " ram_member_demographics demo                                               "
			+ " WHERE det.seq_member_id     = demo.seq_member_id(+)                        "
			+ "AND demo.plan_name(+)       = '%s'                                          "
			+ "AND demo.term_date(+)       > sysdate                                       "
			+ "AND (det.status            != 'V'                                           "
			+ "OR det.status              IS NULL)                                         "
			+ "AND det.seq_revenue_id      ='%s'                                           "
			+ "AND det.revenue_start_date >= TO_DATE('%s','MM/DD/YYYY')                    "
			+ "AND det.revenue_end_date   <= TO_DATE('%s','MM/DD/YYYY')                    "
			+ "AND det.plan_name           = '%s'                                       "
			+ "AND det.medicaid_id         ='%s'                                 "
			+ "ORDER BY det.last_name,                                                     "
			+ " det.first_name,                                                            "
			+ " det.revenue_start_date ";
	public static final String MEMBERSEARCH_PSA_VAL = "SELECT det.medicaid_id,     "
			+ " demo.subscriber_id      AS subscriber_id ,								  "
			+ " demo.prev_subscriber_id AS prev_subscriber_id,                             "
			+ " det.first_name          AS first_name,                                     "
			+ " det.last_name           AS last_name,                                      "
			+ " CASE                                                                       "
			+ "   WHEN demo.social_sec_no IS NOT NULL                                      "
			+ "   THEN 'xxx-xx-'                                                           "
			+ "     || SUBSTR (demo.social_sec_no,6,4)                                     "
			+ " END                                          AS Soc_Sec,                   "
			+ " TO_CHAR(det.date_of_birth,'MM/dd/yyyy')      AS Dob,                       "
			+ " demo.gender                                  AS gender,                    "
			+ " det.risk_group                               AS risk_group,                "
			+ " det.plan_code                                AS plan_code,                 "
			+ " det.RECONCILIATION_KEY                       AS recon_key,                 "
			+ " TO_CHAR(det.revenue_start_date,'MM/dd/yyyy') AS revenue_start_date,        "
			+ " TO_CHAR(det.revenue_end_date,'MM/dd/yyyy')   AS revenue_end_date,          "
			+ " det.invoice_amount                           AS billed_Amt,                "
			+ " det.payment_amount                           AS paid_amt,                  "
			+ " det.ADJUSTMENT_AMOUNT                        AS adj_amount,                "
			+ " NVL(TAX_AMOUNT,0),                                                                "
			+ " (SELECT SUBSTR(code_desc, 0, 3)                                            "
			+ " FROM ram_code_master                                                       "
			+ " WHERE code_value = det.recon_status                                        "
			+ " AND rownum       = 1                                                       "
			+ " )                AS System_Status,                                         "
			+ " (SELECT SUBSTR(code_desc, 0, 3)                                            "
			+ " FROM ram_code_master                                                       "
			+ " WHERE code_value = det.user_status                                         "
			+ " AND rownum       = 1                                                       "
			+ " ) AS user_status                                                           "
			+ "FROM ram_reconciliation_archive det,                                         "
			+ " ram_member_demographics demo                                               "
			+ " WHERE det.seq_member_id     = demo.seq_member_id(+)                        "
			+ "AND demo.plan_name(+)       = '%s'                                          "
			+ "AND demo.term_date(+)       > sysdate                                       "
			+ "AND (det.status            != 'V'                                           "
			+ "OR det.status              IS NULL)                                         "
			+ "AND det.seq_revenue_id      ='%s'                                           "
			+ "AND det.revenue_start_date >= TO_DATE('%s','MM/DD/YYYY')                    "
			+ "AND det.revenue_end_date   <= TO_DATE('%s','MM/DD/YYYY')                    "
			+ "AND det.plan_name           = '%s'                                       "
			+ "AND det.medicaid_id         ='%s'                                 "
			+ "ORDER BY det.last_name,                                                     "
			+ " det.first_name,                                                            "
			+ " det.revenue_start_date ";

	public static final String TRACKINGDETAIL_SYS_STATUS_COUNT = "select count(*) from"
			+ "(select distinct RECON_STATUS from ram_reconciliation_detail where plan_name='%s'" +  "UNION "   
			+ "   select distinct RECON_STATUS from ram_reconciliation_archive where plan_name='%s')";

	public static final String DEMOGRAPHICS_MEMBERDETAIL = "SELECT medicaid_id,subscriber_id,prev_subscriber_id,first_name,last_name,date_of_birth,Gender,"
			+ "FAMILY_CASE_ID"
			+ "  FROM                                                                                               "
			+ " (SELECT                                                                                           "
			+ " demo.seq_member_id,                                                                               "
			+ "   det.medicaid_id,                                                                                "
			+ "   demo.subscriber_id AS mem_subscriber_id,                                                        "
			+ "   demo.prev_subscriber_id,                                                                        "
			+ "   det.first_name,                                                                                 "
			+ "   det.last_name,                                                                                  "
			+ "   TO_CHAR(demo.date_of_birth,'MM/dd/yyyy') AS date_of_birth,                                      "
			+ "   demo.gender,                                                                                    "
			+ "   demo.first_name mem_first_name,                                                                 "
			+ "   demo.last_name mem_last_name,                                                                   "
			+ "   demo.medicaid_id mem_medicaid_id,                                                               "
			+ "   demo.FAMILY_CASE_ID,                                                                            "
			+ "   (SELECT                                                                                         "
			+ "   subscriber_id                                                                                   "
			+ "   FROM ram_member_demographics                                                                    "
			+ "   WHERE plan_name   = '%s'                                                                     "
			+ "   AND seq_member_id = det.seq_member_id                                                           "
			+ "   AND term_date     > sysdate                                                                     "
			+ "   ) AS subscriber_id,                                                                             "
			+ "   (SELECT code_desc FROM ram_code_master WHERE code_value = det.recon_status                      "
			+ "   ) AS recon_status,                                                                              "
			+ "   (SELECT code_desc FROM ram_code_master WHERE code_value = det.user_status                       "
			+ "   )               AS user_status,                                                                 "
			+ "   det.user_status AS user_status_code                                                             "
			+ " FROM ram_member_demographics demo,                                                                "
			+ "   ram_reconciliation_detail det,                                                                  "
			+ "   ram_revenue_stream_history hist                                                                 "
			+ " WHERE det.plan_name                               = demo.plan_name                                "
			+ " AND det.plan_name                                 = '%s'                                       "
			+ " AND det.seq_revenue_id                            = '%s'                                      "
			+ "  AND det.medicaid_id                               ='%s'                                "
			+ " AND demo.term_date                                > sysdate                                       "
			+ " AND hist.seq_revenue_id                           = '%s'                                      "
			+ " AND hist.effective_date                          <= det.revenue_start_date                        "
			+ " AND (det.status                                  != 'V'                                           "
			+ " OR det.status                                    IS NULL)                                         "
			+ " AND NVL(hist.term_date,det.revenue_start_date+1) >= det.revenue_start_date                        "
			+ " UNION ALL                                                                                         "
			+ " SELECT demo.seq_member_id,                                                                        "
			+ "   det.medicaid_id,                                                                                "
			+ "   demo.subscriber_id AS mem_subscriber_id,                                                        "
			+ "   demo.prev_subscriber_id,                                                                        "
			+ "   TO_CHAR(demo.date_of_birth,'MM/dd/yyyy') AS date_of_birth,                                      "
			+ "   demo.gender,                                                                                    "
			+ "   det.first_name,                                                                                 "
			+ "   det.last_name,                                                                                  "
			+ "   demo.first_name mem_first_name,                                                                 "
			+ "   demo.last_name mem_last_name,                                                                   "
			+ "   demo.medicaid_id mem_medicaid_id,                                                               "
			+ "   demo.FAMILY_CASE_ID,                                                                            "
			+ "   (SELECT subscriber_id                                                                           "
			+ "   FROM ram_member_demographics                                                                    "
			+ "   WHERE plan_name   = '%s'                                                                     "
			+ "   AND seq_member_id = det.seq_member_id                                                           "
			+ "   AND term_date     > sysdate                                                                     "
			+ "   ) AS subscriber_id,                                                                             "
			+ "   (SELECT code_desc FROM ram_code_master WHERE code_value = det.recon_status                      "
			+ "   ) AS recon_status,                                                                              "
			+ "   (SELECT code_desc FROM ram_code_master WHERE code_value = det.user_status                       "
			+ "   )               AS user_status,                                                                 "
			+ "   det.user_status AS user_status_code                                                             "
			+ " FROM ram_member_demographics demo,                                                                "
			+ "   ram_reconciliation_archive det,                                                                 "
			+ "   ram_revenue_stream_history hist                                                                 "
			+ " WHERE det.plan_name                               = demo.plan_name                                "
			+ " AND det.plan_name                                 = '%s'                                       "
			+ " AND demo.term_date                                > sysdate                                       "
			+ " AND det.seq_revenue_id                            = '%s'                                        "
			+ " AND hist.seq_revenue_id                           = '%s'                                        "
			+ " AND hist.effective_date                          <= det.revenue_start_date                        "
			+ " AND (det.status                                  != 'V'                                           "
			+ " OR det.status                                    IS NULL)                                         "
			+ "AND det.revenue_start_date >= TO_DATE('%s','MM/DD/YYYY')                                   "
			+ " AND NVL(hist.term_date,det.revenue_start_date+1) >= det.revenue_start_date) "
			+ "where DATE_OF_BIRTH='%s' AND ROWNUM=1                                        "
			+ "ORDER BY mem_subscriber_id ASC";

	public static final String ELIGIBILITY_MEMBERDETAIL = " SELECT  *	               "
			+ " FROM                                                                            "
			+ "   ( SELECT DISTINCT subscriber_id AS mem_subscriber_id,                         "
			+ "     plan_code,                                                                  "
			+ "     effective_date,                                                             "
			+ "     term_date,                                                                  "
			+ "     elig_status,                                                                "
			+ "     county_code,                                                                "
			+ "     group_id,                                                                   "
			+ "     src_plan_code,                                                              "
			+ "     src_group_id                                                               "
			+ "   FROM                                                                          "
			+ "     (SELECT demo.subscriber_id,                                                 "
			+ "       eleg.plan_code,                                                           "
			+ "       TO_CHAR(eleg.effective_date,'MM/dd/yyyy') AS effective_date,              "
			+ "       eleg.effective_date effec,                                                "
			+ "       TO_CHAR(eleg.term_date,'MM/dd/yyyy') AS term_date,                        "
			+ "       eleg.elig_status,                                                         "
			+ "       eleg.county_code,                                                         "
			+ "       eleg.group_id,                                                            "
			+ "       eleg.src_group_id,                                                        "
			+ "       eleg.src_plan_code                                                        "
			+ "     FROM ram_member_eligibility eleg,                                           "
			+ "       ram_revenue_stream_history hist,                                          "
			+ "       ram_member_demographics demo,                                             "
			+ "       ram_reconciliation_detail det                                             "
			+ "     WHERE det.plan_name                               = '%s'                    "
			+ "     AND det.plan_name                                 = demo.plan_name          "
			+ "     AND det.plan_name                                 = eleg.plan_name          "
			+ "     AND demo.term_date                                > sysdate                 "
			+ "     AND demo.subscriber_id								='%s'                   "
			+ "     AND demo.seq_member_id                            = eleg.seq_member_id      "
			+ "     AND hist.effective_date                          <= det.revenue_start_date  "
			+ "     AND (det.status                                  != 'V'                     "
			+ "     OR det.status                                    IS NULL)                   "
			+ "     AND NVL(hist.term_date,det.revenue_start_date+1) >= det.revenue_start_date  "
			+ "     UNION ALL                                                                   "
			+ "     SELECT demo.subscriber_id,                                                  "
			+ "       eleg.plan_code,                                                           "
			+ "       TO_CHAR(eleg.effective_date,'MM/dd/yyyy') AS effective_date,              "
			+ "       eleg.effective_date effec,                                                "
			+ "       TO_CHAR(eleg.term_date,'MM/dd/yyyy') AS term_date,                        "
			+ "       eleg.elig_status,                                                         "
			+ "       eleg.county_code,                                                         "
			+ "       eleg.group_id,                                                            "
			+ "       eleg.src_group_id,                                                        "
			+ "       eleg.src_plan_code                                                        "
			+ "     FROM ram_member_eligibility eleg,                                           "
			+ "       ram_revenue_stream_history hist,                                          "
			+ "       ram_member_demographics demo,                                             "
			+ "       ram_reconciliation_archive det                                            "
			+ "     WHERE det.plan_name                               = '%s'                    "
			+ "     AND det.plan_name                                 = demo.plan_name          "
			+ "     AND det.plan_name                                 = eleg.plan_name          "
			+ "     AND det.seq_revenue_id                            = '%s'                    "
			+ "     AND demo.term_date                                > sysdate                 "
			+ "     AND demo.seq_member_id                            = eleg.seq_member_id      "
			+ "     AND hist.seq_revenue_id                           = '%s'                    "
			+ "     AND hist.effective_date                          <= det.revenue_start_date  "
			+ "     AND (det.status                                  != 'V'                     "
			+ "     OR det.status                                    IS NULL)                   "
			+ "     AND NVL(hist.term_date,det.revenue_start_date+1) >= det.revenue_start_date  "
			+ "                                                                                 "
			+ "     )                                                                           "
			+ "   ORDER BY effec DESC                                                           "
			+ "   )                                                                             "
			+ " ORDER BY mem_subscriber_id ASC," + "   effective_date DESC";

	public static final String INVOICE_MEMBERDETAIL = " SELECT *                                                                   "
			+ "FROM                                                                      "
			+ "  (SELECT                                                                 "
			+ "    demo.subscriber_id   AS mem_subscriber_id,                            "
			+ "    TO_CHAR(inv.revenue_start_date,'MM/dd/yyyy') AS revenue_start_date,   "
			+ "    TO_CHAR(inv.revenue_end_date,'MM/dd/yyyy')   AS revenue_end_date,     "
			+ "    inv.USER_DEFINED_1     AS plan_code,                                  "
			+ "    rsh.revenue_type,                                                     "
			+ "    inv.reconciliation_key AS recon_key,                                  "
			+ "    TO_CHAR(demo.date_of_birth,'MM/dd/yyyy') AS date_of_birth,            "
			+ "    inv.county_code,                                                      "
			+ "    inv.invoice_amount ,                                                  "
			+ "    (SELECT SUBSTR(code_desc, 0, 3)                                       "
			+ "    FROM ram_code_master cm                                               "
			+ "    WHERE cm.code_value = inv.error_code                                  "
			+ "    ) AS code_desc,                                                       "
			+ "    TO_CHAR(inv.insert_datetime,'MM/dd/yyyy') insert_datetime,             "
			+ "inv.seq_invoice_detail_id" + "  FROM ram_invoice_detail inv,                                            "
			+ "    ram_member_demographics demo,                                         "
			+ "    ram_revenue_stream rsh                                                "
			+ "  WHERE inv.plan_name                          = '%s'                  "
			+ "  AND inv.plan_name                            = demo.plan_name           "
			+ "  AND (rsh.seq_revenue_id                      = '%s'                 "
			+ "  OR rsh.base_seq_revenue_id                   = '%s')                "
			+ "  AND inv.seq_revenue_id                       = rsh.seq_revenue_id       "
			+ "  AND inv.seq_member_id                        = demo.seq_member_id       "
			+ "  AND (inv.INVOICE_STATUS                     != 'V')                     "
			+ " AND demo.term_date                           > sysdate                   "
			+ " AND demo.subscriber_id ='%s'                                      "
			+ "  AND TO_CHAR(inv.revenue_start_date,'MM/DD/YYYY') = '%s'                "
			// +" AND TO_CHAR(inv.revenue_end_date,'MM/DD/YYYY') = '07/31/2017'
			// "
			+ "                                                                          "
			+ " UNION ALL                                                                "
			+ "SELECT                                                                    "
			+ "                                                                          "
			+ "   demo.subscriber_id     AS mem_subscriber_id,                           "
			+ "                                                                          "
			+ "   TO_CHAR(inv.revenue_start_date,'MM/dd/yyyy') AS revenue_start_date,    "
			+ "   TO_CHAR(inv.revenue_end_date,'MM/dd/yyyy')   AS revenue_end_date,      "
			+ "      inv.USER_DEFINED_1     AS plan_code,                                "
			+ "   rsh.revenue_type,                                                      "
			+ "   inv.reconciliation_key AS recon_key,                                   "
			+ "    TO_CHAR(demo.date_of_birth,'MM/dd/yyyy') AS date_of_birth,            "
			+ "    inv.county_code,                                                      "
			+ "       inv.invoice_amount,                                                "
			+ "    (SELECT SUBSTR(code_desc, 0, 3)                                       "
			+ "   FROM ram_code_master cm                                                "
			+ "   WHERE cm.code_value = inv.error_code                                   "
			+ "   ) AS code_desc,                                                        "
			+ "        TO_CHAR(inv.insert_datetime,'MM/dd/yyyy') insert_datetime,         "
			+ "inv.seq_invoice_detail_id" + "                                                                          "
			+ " FROM ram_invoice_archive inv,                                            "
			+ "   ram_member_demographics demo,                                          "
			+ "   ram_revenue_stream rsh                                                 "
			+ " WHERE inv.plan_name                          = '%s'                   "
			+ " AND inv.plan_name                            = demo.plan_name            "
			+ " AND inv.seq_member_id                        = demo.seq_member_id        "
			+ " AND (rsh.seq_revenue_id                      = '%s'                  "
			+ " OR rsh.base_seq_revenue_id                   = '%s')                 "
			+ " AND inv.seq_revenue_id                       = rsh.seq_revenue_id        "
			+ " AND (inv.INVOICE_STATUS                     != 'V')                      "
			+ " AND demo.term_date                           > sysdate                   "
			+"AND demo.subscriber_id='%s' "
			+ " )                                                                        "
			+ "ORDER BY seq_invoice_detail_id DESC";

	public static final String PAYMENT_MEMBERDETAIL = "SELECT 	                "
			+ "  demo.subscriber_id,                                                     "
			+ "  TO_CHAR(paym.payment_start_date,'MM/dd/yyyy') AS payment_start_date,    "
			+ "  TO_CHAR(paym.payment_end_date,'MM/dd/yyyy')   AS payment_end_date,      "
			+ "  rsh.revenue_type,                                                       "
			+ "  paym.risk_group,                                                        "
			+ "   paym.reconciliation_key AS recon_key ,                                 "
			+ "   paym.county,                                                           "
			+ "     paym.payment_amount,                                                 "
			+ "     (SELECT SUBSTR(code_desc, 0, 3)                                      "
			+ "  FROM ram_code_master cm                                                 "
			+ "  WHERE cm.code_value = paym.error_code                                   "
			+ "  ) AS code_desc ,                                                        "
			+ "TO_CHAR(paym.insert_datetime,'MM/dd/yyyy') insert_datetime               "

			+ "FROM ram_member_demographics demo,                                        "
			+ "  ram_payment_detail paym,                                                "
			+ "  ram_revenue_stream rsh                                                  "
			+ "WHERE paym.plan_name                          = '%s'                   "
			+ "AND paym.plan_name                            = demo.plan_name            "
			+ "AND paym.seq_member_id                        = demo.seq_member_id        "
			+ "AND demo.term_date                            > sysdate                   "
			+ "AND (rsh.seq_revenue_id                       = '%s'                  "
			+ "OR rsh.base_seq_revenue_id                    = '%s')                 "
			+ "AND paym.seq_revenue_id                       = rsh.seq_revenue_id        "
			+ "AND paym.status                               ='P'                        "
			+ "AND (paym.status                             != 'V'                       "
			+ "OR paym.status                               IS NULL)                     "
			+ "AND payment_start_date=to_date('%s','MM/dd/yyyy')                         "
			+ "UNION                                                                     "
			+ "SELECT                                                                    "
			+ "   '' subscriber_id,                                                      "
			+ "     TO_CHAR(paym.payment_start_date,'MM/dd/yyyy') AS payment_start_date, "
			+ "      TO_CHAR(paym.payment_end_date,'MM/dd/yyyy')   AS payment_end_date,  "
			+ "        rsh.revenue_type,                                                 "
			+ "  paym.risk_group,                                                        "
			+ "    paym.reconciliation_key AS recon_key ,                                "
			+ "      paym.county,                                                        "
			+ "       paym.payment_amount,                                               "
			+ "      (SELECT SUBSTR(code_desc, 0, 3)                                     "
			+ "  FROM ram_code_master cm                                                 "
			+ "  WHERE cm.code_value = paym.error_code                                   "
			+ "  ) AS code_desc,                                                         "
			+ "  TO_CHAR(paym.insert_datetime,'MM/dd/yyyy') insert_datetime             "

			+ "                                                                          "
			+ "FROM ram_payment_detail paym,                                             "
			+ "  ram_revenue_stream rsh                                                  "
			+ "WHERE paym.plan_name                          = '%s'                   "
			+ "AND paym.seq_member_id                       IS NULL                      "
			+ "AND paym.medicaid_id                          = '%s'            "
			+ "AND (rsh.seq_revenue_id                       = '%s'                  "
			+ "OR rsh.base_seq_revenue_id                    = '%s')                 "
			+ "AND paym.seq_revenue_id                       = rsh.seq_revenue_id        "
			+ "AND paym.status                               ='P'                        "
			+ "AND (paym.status                             != 'V'                       "
			+ "OR paym.status                               IS NULL)                     "
			+ "UNION ALL                                                                 "
			+ "                                                                          "
			+ "SELECT '' subscriber_id,                                                  "
			+ "     TO_CHAR(paym.payment_start_date,'MM/dd/yyyy') AS payment_start_date, "
			+ "      TO_CHAR(paym.payment_end_date,'MM/dd/yyyy')  AS payment_end_date,   "
			+ "        rsh.revenue_type,                                                 "
			+ "  paym.risk_group,                                                        "
			+ "    paym.reconciliation_key AS recon_key ,                                "
			+ "      paym.county,                                                        "
			+ "       paym.payment_amount,                                               "
			+ "      (SELECT SUBSTR(code_desc, 0, 3)                                     "
			+ "  FROM ram_code_master cm                                                 "
			+ "  WHERE cm.code_value = paym.error_code                                   "
			+ "  ) AS code_desc,                                                         "
			+ "  TO_CHAR(paym.insert_datetime,'MM/dd/yyyy') insert_datetime             "
			+ "FROM ram_member_demographics demo,                                        "
			+ "  ram_payment_archive paym,                                               "
			+ "  ram_revenue_stream rsh                                                  "
			+ "WHERE paym.plan_name                          = '%s'                   "
			+ "AND paym.plan_name                            = demo.plan_name            "
			+ "AND paym.seq_member_id                        = demo.seq_member_id        "
			+ "AND demo.term_date                            > sysdate                   "
			+ "AND (rsh.seq_revenue_id                       = '%s'                  "
			+ "OR rsh.base_seq_revenue_id                    = '%s')                 "
			+ "AND paym.seq_revenue_id                       = rsh.seq_revenue_id        "
			+ "AND paym.status                               ='P'                        "
			+ "AND (paym.status                             != 'V'                       "
			+ "OR paym.status                               IS NULL)                     "
			+ "UNION                                                                     "
			+ "SELECT                                                                    "
			+ "  '' subscriber_id,                                                       "
			+ "  TO_CHAR(paym.payment_start_date,'MM/dd/yyyy') AS payment_start_date,    "
			+ "  TO_CHAR(paym.payment_end_date,'MM/dd/yyyy')   AS payment_end_date,      "
			+ "  rsh.revenue_type,                                                       "
			+ "  paym.risk_group,                                                        "
			+ "   paym.reconciliation_key AS recon_key ,                                 "
			+ "   paym.county,                                                           "
			+ "     paym.payment_amount,                                                 "
			+ "     (SELECT SUBSTR(code_desc, 0, 3)                                      "
			+ "  FROM ram_code_master cm                                                 "
			+ "  WHERE cm.code_value = paym.error_code                                   "
			+ "  ) AS code_desc ,                                                        "
			+ "TO_CHAR(paym.insert_datetime,'MM/dd/yyyy') insert_datetime               "

			+ "                                                                          "
			+ "                                                                          "
			+ "FROM ram_payment_archive paym,                                            "
			+ "  ram_revenue_stream rsh                                                  "
			+ "WHERE paym.plan_name                          = '%s'                   "
			+ "AND paym.seq_member_id                       IS NULL                      "
			+ "AND paym.medicaid_id                          = '%s'            "
			+ "AND (rsh.seq_revenue_id                       = '%s'                  "
			+ "OR rsh.base_seq_revenue_id                    = '%s')                 "
			+ "AND paym.seq_revenue_id                       = rsh.seq_revenue_id        "
			+ "AND paym.status                               ='P'                        "
			+ "AND (paym.status                             != 'V'                       "
			+ "OR paym.status                               IS NULL)                  ";
	public static final String TRACKING_DETAIL_VAL="select sum(tr.CLOSED_RECORDS) CLOSED_RECORDS ,sum(tr.OPEN_RECORDS) OPEN_RECORDS, 											"
			+" sum(tr.WORKED_RECORDS) WORKED_RECORDS ,sum(tr.INVOICED_AMOUNT) INVOICED_AMOUNT, sum(tr.PAYMENT_AMOUNT) PAYMENT_AMOUNT,                                       "
			+" tr.system_status from ram_tracking_report tr,ram_code_master cm where seq_revenue_id='%s' and system_status='%s'and tr.seq_revenue_id= SEQ_REVENUE_ID   "
			+" and tr.revenue_startdate between TO_DATE('%s','MM/DD/YYYY') and TO_DATE('%s','MM/DD/YYYY')                                                   "
			+" and cm.code_value= tr.system_status group by tr.system_status,code_desc order by cm.code_desc ";
	public static final String COMPANY_CODE="select company_code  from ram_revenue_stream_history where plan_name='%s' and revenue_type='%s' and term_date is null";
	public static final String RATEFILE_BACKOUT="delete from ram_rate_upload_header where company_code='%s'";
	public static void validateBulkUploadErrorDataInFile(String tableName, String planName)
			throws SQLException {
		Statement statement = ConnectionHelper.sqliteConnection.createStatement();
		ResultSet resultSet = statement.executeQuery("SELECT * FROM "+tableName);
		
		while (resultSet.next()) {
			String error_reason = resultSet.getString("ERROR_REASON");
			if(error_reason != null && error_reason.contains("USER_COMMENTS")){
				String userComments = resultSet.getString("USER_COMMENTS");
				boolean flag = false;
				if(userComments == null || userComments.length() == 0){
					flag = true;
				}
				Assert.assertTrue(flag, "USER_COMMENTS Coulmn value is not null or empty. ");
			}else if(error_reason != null && error_reason.contains("PAYMENT_AMOUNT")){
				String paymentAmount = resultSet.getString("PAYMENT_AMOUNT");
				boolean flag = false;
				if(paymentAmount == null || paymentAmount.length() == 0){
					flag = true;
				}
				Assert.assertTrue(flag, "PAYMENT_AMOUNT Coulmn value is not null or empty. ");
			}
			else if(error_reason != null && error_reason.contains("INVOICE_AMOUNT")){
				String invoiceAmount = resultSet.getString("INVOICE_AMOUNT");
				boolean flag = false;
				if(invoiceAmount == null || invoiceAmount.length() == 0){
					flag = true;
				}
				Assert.assertTrue(flag, "INVOICE_AMOUNT Coulmn value is not null or empty. ");
			}
			else if(error_reason != null && error_reason.contains("REVENUE_START_DATE")){
				String revenueStartDt = resultSet.getString("REVENUE_START_DATE");
				boolean flag = false;
				if(revenueStartDt == null || revenueStartDt.length() == 0){
					flag = true;
				}
				Assert.assertTrue(flag, "REVENUE_START_DATE Coulmn value is not null or empty. ");
			}
			else if(error_reason != null && error_reason.contains("MEMBER KEY MISSING")){
				String medicaidId = resultSet.getString("MEDICAID_ID");
				boolean flag = false;
				if(medicaidId == null || medicaidId.length() == 0){
					flag = true;
				}
				Assert.assertTrue(flag, "MEMBER KEY MISSING Coulmn value is not null or empty. ");
			}
			
		}
		// validating the Data against Data base.
		ResultSet resultSet1 = statement.executeQuery("SELECT * FROM "+tableName);
		while (resultSet1.next()) {
			String error_reason = resultSet.getString("ERROR_REASON");
			String userComments = resultSet.getString("USER_COMMENTS");
			String paymentAmt = resultSet.getString("PAYMENT_AMOUNT");
			String invoiceAmt = resultSet.getString("INVOICE_AMOUNT");
			String revenueStartDt = resultSet.getString("REVENUE_START_DATE");
			String medicaidId = resultSet.getString("MEDICAID_ID");
			String subscriberId = resultSet.getString("SUBSCRIBER_ID");
			if(error_reason != null && error_reason.contains("USER_COMMENTS")){								 
				String query = "SELECT USER_COMMENTS FROM RAM_BULK_UPDATE_DETAIL WHERE PLAN_NAME = '"+planName+"' "
								+"AND medicaid_id "+addQueryCondition(medicaidId)+" "
						        +"AND subscriber_id "+addQueryCondition(subscriberId)+" "
								+"AND revenue_start_date "+addQueryCondition(revenueStartDt)+" "
								+"AND INVOICE_AMOUNT "+addQueryCondition(invoiceAmt)+" "
								+"AND payment_amount "+addQueryCondition(paymentAmt)+" ";
				System.out.println(" QUERY ===>>> "+query);
				String userCommentsFromDB = DatabaseProcessor.getStringReturnedByFacetsQuery(query);
				if(userCommentsFromDB == null){
					userCommentsFromDB = "";
				}
				Assert.assertEquals(userCommentsFromDB, userComments);
			}else if(error_reason != null && error_reason.contains("PAYMENT_AMOUNT")){
				String query = "SELECT payment_amount FROM RAM_BULK_UPDATE_DETAIL WHERE PLAN_NAME = '"+planName+"' "
						+"AND medicaid_id "+addQueryCondition(medicaidId)+" "
				        +"AND subscriber_id "+addQueryCondition(subscriberId)+" "
						+"AND revenue_start_date "+addQueryCondition(revenueStartDt)+" "
						+"AND INVOICE_AMOUNT "+addQueryCondition(invoiceAmt)+" "
						+"AND USER_COMMENTS "+addQueryCondition(userComments)+" ";
				System.out.println(" QUERY ===>>> "+query);
				String paymentAmtFromDB = DatabaseProcessor.getStringReturnedByFacetsQuery(query);
				if(paymentAmtFromDB == null){
					paymentAmtFromDB = "";
				}
				Assert.assertEquals(paymentAmtFromDB, paymentAmt);
			}else if(error_reason != null && error_reason.contains("INVOICE_AMOUNT")){
				String query = "SELECT INVOICE_AMOUNT FROM RAM_BULK_UPDATE_DETAIL WHERE PLAN_NAME = '"+planName+"' "
						+"AND medicaid_id "+addQueryCondition(medicaidId)+" "
				        +"AND subscriber_id "+addQueryCondition(subscriberId)+" "
						+"AND revenue_start_date "+addQueryCondition(revenueStartDt)+" "
						+"AND payment_amount "+addQueryCondition(paymentAmt)+" "
						+"AND USER_COMMENTS "+addQueryCondition(userComments)+" ";
				System.out.println(" QUERY ===>>> "+query);
				String invoiceAmtFromDB = DatabaseProcessor.getStringReturnedByFacetsQuery(query);
				if(invoiceAmtFromDB == null){
					invoiceAmtFromDB = "";
				}
				Assert.assertEquals(invoiceAmtFromDB, invoiceAmt);
			}else if(error_reason != null && error_reason.contains("REVENUE_START_DATE")){
				String query = "SELECT revenue_start_date FROM RAM_BULK_UPDATE_DETAIL WHERE PLAN_NAME = '"+planName+"' "
						+"AND medicaid_id "+addQueryCondition(medicaidId)+" "
				        +"AND subscriber_id "+addQueryCondition(subscriberId)+" "
						+"AND INVOICE_AMOUNT "+addQueryCondition(invoiceAmt)+" "
						+"AND payment_amount "+addQueryCondition(paymentAmt)+" "
						+"AND USER_COMMENTS "+addQueryCondition(userComments)+" ";
				System.out.println(" QUERY ===>>> "+query);
				String revenueStartDtFromDB = DatabaseProcessor.getStringReturnedByFacetsQuery(query);
				if(revenueStartDtFromDB == null){
					revenueStartDtFromDB = "";
				}
				Assert.assertEquals(revenueStartDtFromDB, revenueStartDt);
			}else if(error_reason != null && error_reason.contains("MEMBER KEY MISSING")){
				String query = "SELECT medicaid_id FROM RAM_BULK_UPDATE_DETAIL WHERE PLAN_NAME = '"+planName+"' "
						+"AND revenue_start_date "+addQueryCondition(revenueStartDt)+" "
				        +"AND subscriber_id "+addQueryCondition(subscriberId)+" "
						+"AND INVOICE_AMOUNT "+addQueryCondition(invoiceAmt)+" "
						+"AND payment_amount "+addQueryCondition(paymentAmt)+" "
						+"AND USER_COMMENTS "+addQueryCondition(userComments)+" ";
				System.out.println(" QUERY ===>>> "+query);
				String medicaidIdFromDB = DatabaseProcessor.getStringReturnedByFacetsQuery(query);
				if(medicaidIdFromDB == null){
					medicaidIdFromDB = "";
				}
				Assert.assertEquals(medicaidIdFromDB, medicaidId);
			}
		}
	}
	
	private static String addQueryCondition(String value){
		if(value == null || value.length() == 0){
			return " IS NULL ";
		}else{
			return " = '"+value+"' ";
		}
	}
	//Added by ksushman
	public static String VIEWRATES_VAL="SELECT rate_desc ,		"
			+ "risk_group,							                           "									   			
			+" TO_CHAR(effective_date,'MM/DD/YYYY'),							"		
			+" TO_CHAR(term_date, 'MM/DD/YYYY'),                                "
			+" (SELECT NVL(TRIM(SUM(rate)),0.00)                                "
			+" FROM ram_rate_categ_matrix rrcm                                  "
			+" WHERE rrcm.effective_date         = rrc.effective_date           "
			+" AND rrcm.seq_revenue_id           = rrc.seq_revenue_id           "
			+" AND rrcm.term_date                = rrc.term_date                "
			+" AND rrcm.risk_group               = rrc.risk_group               "
			+" AND (rrcm.age_from               IS NULL                         "
			+" OR rrcm.age_from                  = rrc.age_from)                "
			+" AND (rrcm.age_to                 IS NULL                         "
			+" OR rrcm.age_to                    = rrc.age_to )                 "
			+" AND (rrcm.county                 IS NULL                         "
			+" OR rrcm.county                    = rrc.county)                  "
			+" AND (rrcm.gender                 IS NULL                         "
			+" OR rrcm.gender                    = rrc.gender)                  "
			+" AND (rrcm.category_of_assistance IS NULL                         "
			+" OR rrcm.category_of_assistance    = rrc.category_of_assistance)  "
			+" AND (rrcm.gl_product             IS NULL                         "
			+" OR rrcm.gl_product                = rrc.gl_product)              "
			+" AND (rrcm.proration_formula      IS NULL                         "
			+" OR rrcm.proration_formula         = rrc.proration_formula)       "
			+" AND (rrcm.product_code           IS NULL                         "
			+" OR rrcm.product_code              = rrc.product_code)            "
			+" AND (rrcm.status                 IS NULL                         "
			+" OR rrcm.status                    = rrc.status)                  "
			+" AND (rrcm.user_defined_1         IS NULL                         "
			+" OR rrcm.user_defined_1            = rrc.user_defined_1)          "
			+" AND (rrcm.user_defined_2         IS NULL                         "
			+" OR rrcm.user_defined_2            = rrc.user_defined_2)          "
			+" )"
			+ "rate,"
			+ " gender,                                                        "
			+" county,                                                          "
			+" TO_CHAR(AGE_FROM),                                               "
			+" TO_CHAR(AGE_TO),                                                 "
			+" TO_CHAR(GL_PRODUCT),                                             "
			+" TRIM(CATEGORY_OF_ASSISTANCE),                                    "
			+" TRIM(PROGRAM_STATUS_CODE),                                       "
			+" TRIM(PRODUCT_CODE),                                              "
			+" CASE                                                             "
			+"   WHEN STATUS='Y'                                                "
			+"   THEN 'Active'                                                  "
			+"   WHEN STATUS='V'                                                "
			+"   THEN 'VOIDED'                                                  "
			+" END STATUS,                                                      "
			+" PRORATION_FORMULA                                                "
			+"FROM ram_rate_categ_matrix rrc                                    "
			+"WHERE RISK_GROUP          IN ('%s')                               "
			+"AND (COMPOSITE_REVENUE_ID IS NULL                                 "
			+"OR seq_revenue_id          = COMPOSITE_REVENUE_ID)                "
			+"ORDER BY effective_date DESC,                                     "
			+"RISK_GROUP ASC                                                    ";
				
				public static String RATES_REVENUETYPE="select distinct revenue_type from ram_rate_categ_matrix where company_code='%s'";
				
				public static String VIEWRATEMATRIX= "SELECT   PLAN_CODE,												"
			+"  RISK_GROUP,                                                                                                      "
			+"  RISK_GROUP,                                                                                                      "
			+"  REVENUE_TYPE,                                                                                                    "
			+"  TO_CHAR (effective_date, 'MM/DD/YYYY') AS EFFECTIVE_DATE,                                                        "
			+"  TO_CHAR (term_date, 'MM/DD/YYYY')           AS TERM_DATE,                                                        "
			+"   GENDER,                                                                                                         "
			+"  TRIM(COUNTY),                                                                                                    "
			+"  AGE_FROM,                                                                                                        "
			+"  AGE_TO,                                                                                                          "
			+"  GL_PRODUCT,                                                                                                      "
			+"  PRODUCT_CODE,                                                                                                    "
			+"  CATEGORY_OF_ASSISTANCE,                                                                                          "
			+"  TRIM(program_status_code),                                                                                       "
			+"   CASE                                                                                                            "
			+"   WHEN STATUS='Y'                                                                                                 "
			+"   THEN 'Active'                                                                                                   "
			+"   WHEN STATUS='V'                                                                                                 "
			+"   THEN 'VOIDED'                                                                                                   "
			+"   END STATUS,                                                                                                     "
			+"   proration_formula,                                                                                              "
			+"  MAX(DECODE(REVENUE_TYPE,'%s', RATE)) RATE_AMOUNT_CAP,                                                           "
			+"  MAX(DECODE(REVENUE_TYPE,'PASS', RATE)) RATE_AMOUNT_PASS,                                                         "
			+"  MAX(DECODE(REVENUE_TYPE,'PPA', RATE)) RATE_AMOUNT_PPA                                                            "
			+"FROM RAM_RATE_MATRIX                                                                                               "
			+" WHERE RISK_GROUP      IN ('%s') "
			+"AND (seq_revenue_id    = '%s'                                                                                  "
			+"OR base_seq_revenue_id = '110054' )                                                                                "
			+"AND STATUS             = 'Y'                                                                                       "
			+"GROUP BY                                                                                                           "
			+"  CATEGORY_OF_ASSISTANCE,                                                                                          "
			+"EFFECTIVE_DATE,                                                                                                    "
			+"  TERM_DATE,                                                                                                       "
			+"  PLAN_CODE,                                                                                                       "
			+"  AGE_FROM,                                                                                                        "
			+"  AGE_TO,                                                                                                          "
			+"  RISK_GROUP,                                                                                                      "
			+"  GENDER,                                                                                                          "
			+"  COUNTY,                                                                                                          "
			+"  GL_PRODUCT,                                                                                                      "
			+"  PRODUCT_CODE,                                                                                                    "                                                                                                
			+"  proration_formula,                                                                                               "
			+"  program_status_code,                                                                                             "
			+"  STATUS,"
			+"  REVENUE_TYPE";
				
				public static String PLANCODES_RISKGROUP="SELECT 																									"
			+"  plan_code,                                                                                              "
			+"  risk_group,                                                                                             "
			+"  rate_desc,                                                                                              "
			+"  revenue_type,                                                                                           "
			+"  TO_CHAR (effective_date, 'MM/DD/YYYY') AS effective_date,                                               "
			+"  TO_CHAR (term_date, 'MM/DD/YYYY')      AS term_date,                                                    "
			+"  rate,                                                                                                   "
			+"  gender,                                                                                                 "
			+"  county,                                                                                                 "
			+"  age_from,                                                                                               "
			+"  age_to,                                                                                                 "
			+"  gl_product,                                                                                             "
			+"   CATEGORY_OF_ASSISTANCE,                                                                                "
			+"     PROGRAM_STATUS_CODE,                                                                                 "
			+"     product_code,                                                                                        "
			+"     case                                                                                                 "
			+"     when status='Y' then 'Active'                                                                        "
			+"     when status='V' then 'Voided'                                                                        "
			+"     END status,                                                                                          "
			+"  PRORATION_FORMULA                                                                                       "
			+"FROM ram_rate_matrix                                                                                      "
			+"WHERE                                                                                                     "
			+" RISK_GROUP  IN ('%s') "
			+"AND (seq_revenue_id    = '%s'                                                                         "
			+"OR base_seq_revenue_id = '%s')                                                                        "
			+"ORDER BY effective_date DESC,seq_revenue_id                                                            ";
				public static String RAM_RATE_CATEG_BACKOUT="delete from ram_rate_categ_matrix where company_code='%s' and risk_group='%s'";
				public static String RAM_RATE_MATRIX_BACKOUT="delete from ram_rate_matrix where company_code='%s' and risk_group='%s'";
				

}
