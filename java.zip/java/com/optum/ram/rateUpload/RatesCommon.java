package com.optum.ram.rateUpload;

import com.optum.ram.atdd.common.utils.CSPPropertyReader;
import com.optum.ram.atdd.common.utils.UnixUtilityHelper;
import com.optum.ram.invoice.InvoiceConstants;

public class RatesCommon {
	private static String SPACE = " ";
	/**
	 * @param plan
	 * @param revId
	 * @param seqRevId
	 * @return Reusable method to trigger Invoice job
	 */
	public boolean triggerRateUploadJob(String company_code,String revenueType) {
		UnixUtilityHelper unixUtilObj;
		boolean jobStatus = false;
		try {
			unixUtilObj = new UnixUtilityHelper();
			jobStatus = unixUtilObj.execute_unix_job_jsch(
					CSPPropertyReader.getRateUploadJob()+SPACE+company_code+SPACE+ revenueType,
					CSPPropertyReader.getUnixServer(), CSPPropertyReader.getUnixUsername(),
					CSPPropertyReader.getUnixPassword());
			System.out.println(InvoiceConstants.JOB_FEATURE_STATUS + jobStatus);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jobStatus;

	}
	
	public boolean triggerInvoiceJobWhenFlagisHold(String planName,String revenueType,String seqRevenueId) {
		UnixUtilityHelper unixUtilObj;
		boolean jobStatus = false;
		try {
			unixUtilObj = new UnixUtilityHelper();
			
			jobStatus = unixUtilObj.holdFlagsJob(
					CSPPropertyReader.getInvoiceJob()+SPACE+planName+SPACE+ revenueType+SPACE+seqRevenueId,
					CSPPropertyReader.getUnixServer(), CSPPropertyReader.getUnixUsername(),
					CSPPropertyReader.getUnixPassword(),revenueType,seqRevenueId);
			System.out.println("\n"+ InvoiceConstants.JOB_FEATURE_STATUS+ jobStatus);
			System.out.println("\n THE JOB STATUS IS:"+jobStatus);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jobStatus;

	}
	
	

}
