package com.optum.ram.rateUpload;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;
import org.testng.annotations.BeforeClass;

import com.optum.facets.atdd.common.utils.ConnectionHelper;
import com.optum.facets.atdd.common.utils.FlatFileProcessor;
import com.optum.ram.atdd.common.utils.CSPCommonTestBase;
import com.optum.ram.atdd.common.utils.CSPPropertyReader;
import com.optum.ram.atdd.common.utils.DbQueryHelper;
import com.optum.ram.atdd.common.utils.RAMCommonDBQuires;
import com.optum.ram.atdd.common.utils.SafeActions;
import com.optum.ram.atdd.common.utils.UnixUtilityHelper;
import com.optum.ram.invoice.InvoiceConstants;
import com.optum.ram.ramui.BaseSetup;
import com.optum.ram.ramui.PageModules;
import com.optum.ram.ramui.RatesTab;
import com.optum.ram.ramui.RevenueStreamTab;
import com.optum.ram.ramui.ServiceTab;
import com.optum.ram.recon.ReconCommon;

import au.com.bytecode.opencsv.CSVReader;
import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/*@CucumberOptions(features = "src/main/resources/rates/feature_files",
plugin = {"pretty","html:target/cucumber-html-reports", "json:target/cucumber-html-reports/cucumber.json" },tags={"@TC067"})*/
@CucumberOptions(features = "src/main/resources/rates/feature_files", format = {
		"json:target/test_results/rateUpload.json"}, tags={"@TC012"}, snippets = SnippetType.CAMELCASE)
public class RateuploadRunner extends CSPCommonTestBase {

	
	public static String inputFileName = "";
	public static String eligiblityUploadExtractTDFilePath = "src/main/resources/eligibilityUpload/testdata/EligibilityUpload_TestData.xls";
	public static String eligiblityUploadExtractTDConfigTable = "ELIGIBILITY_UPLOAD_TEST_DATA_CONFIG_TABLE";
	public static String eligiblityUploadExtractTDActualTable = "ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE";
	public static String autoItexecutableFilePath = "src\\main\\resources\\common\\drivers\\DownloadFile.exe";
	public static String downloadedFilePath = "src\\main\\resources\\eligibilityUpload\\";
	
	static SafeActions safeActionsobj = new SafeActions(BaseSetup.driver);

	@BeforeClass
	public void setUpClass()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException, IOException {
		super.setUpClass();
		try {

			ConnectionHelper.sqliteConnection = ConnectionHelper
					.openSqliteConnection("src/main/resources/eligibilityUpload/db_file/eligibilityUpload.db");
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String strcolnames = FlatFileProcessor.getExcelColumn(eligiblityUploadExtractTDFilePath, "Global");
		FlatFileProcessor.createConfigTable(eligiblityUploadExtractTDConfigTable, strcolnames);
		List myList;
		try {

			myList = FlatFileProcessor.readExcelData(eligiblityUploadExtractTDFilePath, "Global");
			FlatFileProcessor.createAndPopulateDetailsTableFromDataFile(myList, eligiblityUploadExtractTDConfigTable,
					eligiblityUploadExtractTDActualTable, 1, myList.size(), true);
			System.out.println("The list is" + myList);
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Given("^The user should be on the RAM homepage and select the corresponding revenue stream from the left side pane \"([^\"]*)\"$")
	public void loginSelectRevenueStream(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		PageModules pageModulesobj = new PageModules();
		DbQueryHelper dbhelper = new DbQueryHelper();
		try {
//			RateuploadRunner obj=new RateuploadRunner();
//			obj.setUpClass();
			tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
			pageModulesobj.navigateToRAMUI();
			pageModulesobj.enterCredentials();
			String companyCode = dbhelper.getMultipleValues(
					String.format(RateUploadDBqueries.COMPANY_CODE, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
			System.out.println(" ==========>> companyCode "+companyCode);
			pageModulesobj.selectRevenueStream(companyCode, tdMap.get("REVENUETYPE"));
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Unable to select the Revenue Stream from UI" + e);
		}

	}

	@When("^click on the view rates link,select the rates from leftpane to right pane and click on the search button$")
	public void performSearchOnViewRatesScreen() throws Throwable {
		RatesTab rateTabobj=new RatesTab();
		rateTabobj.clickonRatesTab();
		rateTabobj.navigateToViewRatesAndPerformSearch();
	}

	@Then("^validate the search results are displayed in the view  rates screen as per the search criteria or not \"([^\"]*)\"$")
	public void verifyTheSearchResutsWithDb(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		DbQueryHelper dbhelper = new DbQueryHelper();
		RatesTab rateTabobj=new RatesTab();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		PageModules pageModulesobj = new PageModules();
		String companyCode = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.COMPANY_CODE, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		rateTabobj.validateSearchResultWithDb(companyCode);
		pageModulesobj.signout();
	}

	@When("^click on the TrackingOVerall link, enter the from and To dates and click on report button \"([^\"]*)\"$")
	public void performSearchOnTrackingOVerallPage(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		ServiceTab ServiceTabobj = new ServiceTab();
		ServiceTabobj.clickonServiceTab();
		ServiceTabobj.clickOnTrackingOverallPageLink();
		ServiceTabobj.typeFromAndToDate(tdMap.get("FROM_DATE"), tdMap.get("TO_DATE"));

	}

	@Then("^User would be able to view the number of open, closed and worked member for each system assigned status  \"([^\"]*)\"$")
	public void validateUIDataWithDb(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		RAMCommonDBQuires ramCommonDBQueryobj = new RAMCommonDBQuires();
		ServiceTab serviceTabobj = new ServiceTab();
		PageModules pageModulesobj = new PageModules();
		DbQueryHelper dbhelper = new DbQueryHelper();
		tdMap = ramCommonDBQueryobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String seqRevenueId = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.SEQ_REVENUE_ID, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		String companyCode = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.COMPANY_CODE, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		serviceTabobj.verifyTrackingOverallPageWithDbRecords(tdMap.get("PLANNAME"), seqRevenueId,
				tdMap.get("FROM_DATE"), tdMap.get("TO_DATE"),companyCode);
		pageModulesobj.signout();

	}

	@When("^Navigate to the member search screen, enter the medicaid of record and click on search button \"([^\"]*)\"$")
	public void memberSearchWithMedicaid_id(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		ServiceTab serviceTabobj = new ServiceTab();
		RAMCommonDBQuires ramCommonDBQueryobj = new RAMCommonDBQuires();
		tdMap = ramCommonDBQueryobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		serviceTabobj.memberSearchWithMedicaid_id(tdMap.get("MEDICAID_ID"), tdMap.get("REVENUE_MONTH"));

	}

	@Then("^Validate the search results with db, drill down to the memberDetails page,vaildate the demo,Elig,Invoice,payment details of the member with db  \"([^\"]*)\"$")
	public void clickOnMemberDetailsPageVerfiyResultsWithDb(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		PageModules pageModulesobj = new PageModules();
		DbQueryHelper dbhelper = new DbQueryHelper();
		ServiceTab serviceTabobj = new ServiceTab();
		RAMCommonDBQuires ramCommonDBQueryobj = new RAMCommonDBQuires();
		tdMap = ramCommonDBQueryobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String seqRevenueId = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.SEQ_REVENUE_ID, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		serviceTabobj.memberSearchVal("BNP", tdMap.get("PLANNAME"), seqRevenueId, tdMap.get("MEDICAID_ID"),
				tdMap.get("SUBSCRIBER_ID"), tdMap.get("REVENUE_MONTH"), null);
		pageModulesobj.signout();
	
	}

	@Then("^Validate the search results with db, drill down to the memberDetails page,validate that member should not have Invoice entry and have a payment entry and the results should be matched with db  \"([^\"]*)\"$")
	public void pnb_Validation(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		DbQueryHelper dbhelper = new DbQueryHelper();
		ServiceTab serviceTabobj = new ServiceTab();
		PageModules pageModulesobj = new PageModules();
		RAMCommonDBQuires ramCommonDBQueryobj = new RAMCommonDBQuires();
		tdMap = ramCommonDBQueryobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String seqRevenueId = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.SEQ_REVENUE_ID, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		serviceTabobj.memberSearchVal("PNB", tdMap.get("PLANNAME"), seqRevenueId, tdMap.get("MEDICAID_ID"),
				tdMap.get("SUBSCRIBER_ID"), tdMap.get("REVENUE_MONTH"), null);
		pageModulesobj.signout();
		
	}

	@Then("^Validate the search results with db, drill down to the memberDetails page,validate that member should have payment amount greater than the invoice amount and the results should be matched with db  \"([^\"]*)\"$")
	public void pdh_Validation(String testCaseId) throws Throwable {
		// PDH
		Map<String, String> tdMap;
		DbQueryHelper dbhelper = new DbQueryHelper();
		ServiceTab serviceTabobj = new ServiceTab();
		PageModules pageModulesobj = new PageModules();
		RAMCommonDBQuires ramCommonDBQueryobj = new RAMCommonDBQuires();
		tdMap = ramCommonDBQueryobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String seqRevenueId = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.SEQ_REVENUE_ID, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		serviceTabobj.memberSearchVal("PDH", tdMap.get("PLANNAME"), seqRevenueId, tdMap.get("MEDICAID_ID"),
				tdMap.get("SUBSCRIBER_ID"), tdMap.get("REVENUE_MONTH"), null);
		pageModulesobj.signout();
	}

	@Then("^Validate the search results with db, drill down to the memberDetails page,validate that member should have Invoice amount greater than the payment amount and the results should be matched with db  \"([^\"]*)\"$")
	public void pdl_validation(String testCaseId) throws Throwable {
		// PDL
		Map<String, String> tdMap;
		DbQueryHelper dbhelper = new DbQueryHelper();
		ServiceTab serviceTabobj = new ServiceTab();
		PageModules pageModulesobj = new PageModules();
		RAMCommonDBQuires ramCommonDBQueryobj = new RAMCommonDBQuires();
		tdMap = ramCommonDBQueryobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String seqRevenueId = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.SEQ_REVENUE_ID, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		serviceTabobj.memberSearchVal("PDL", tdMap.get("PLANNAME"), seqRevenueId, tdMap.get("MEDICAID_ID"),
				tdMap.get("SUBSCRIBER_ID"), tdMap.get("REVENUE_MONTH"), null);
		pageModulesobj.signout();
	}

	@Then("^Validate the search results with db, drill down to the memberDetails page,validate that member should same Invoice and payment amounts and the results should be matched with db  \"([^\"]*)\"$")
	public void validatePSA(String testCaseId) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Map<String, String> tdMap;
		DbQueryHelper dbhelper = new DbQueryHelper();
		ServiceTab serviceTabobj = new ServiceTab();
		PageModules pageModulesobj = new PageModules();
		RAMCommonDBQuires ramCommonDBQueryobj = new RAMCommonDBQuires();
		tdMap = ramCommonDBQueryobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String seqRevenueId = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.SEQ_REVENUE_ID, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		serviceTabobj.memberSearchVal("PSA", tdMap.get("PLANNAME"), seqRevenueId, tdMap.get("MEDICAID_ID"),
				tdMap.get("SUBSCRIBER_ID"), tdMap.get("REVENUE_MONTH"), null);
		pageModulesobj.signout();
	}

	@When("^click on the TrackingDetail link, enter the from and To dates and click on report button \"([^\"]*)\"$")
	public void navigateToTrackingDetailPage(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		RAMCommonDBQuires ramCommonDBQueryobj = new RAMCommonDBQuires();
		ServiceTab serviceTabobj = new ServiceTab();
		tdMap = ramCommonDBQueryobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		serviceTabobj.clickonServiceTab();
		serviceTabobj.clickOnTrackingDetailPageLink();
		serviceTabobj.enterDates(tdMap.get("FROM_DATE"), tdMap.get("TO_DATE"));

	}

	@Then("^User would be able to view the systemStatus for all members in the System \"([^\"]*)\"$")
	public void validateTrackingDetailPage(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		ServiceTab serviceTabobj = new ServiceTab();
		PageModules pageModulesobj = new PageModules();
		DbQueryHelper dbhelper = new DbQueryHelper();
		RAMCommonDBQuires ramCommonDBQueryobj = new RAMCommonDBQuires();
		tdMap = ramCommonDBQueryobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String seqRevenueId = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.SEQ_REVENUE_ID, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		serviceTabobj.trackingDetailVerify(tdMap.get("PLANNAME"), seqRevenueId, tdMap.get("FROM_DATE"), tdMap.get("TO_DATE"));
		pageModulesobj.signout();
	}

	@Then("^Validate the search results with db, drill down to the memberDetails page,verify that member should be errorout with Invoice Error as Duplicate Member Identifier\\[DMI\\] \"([^\"]*)\"$")
	public void validateInvoiceErrorDMI(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		ServiceTab serviceTabobj = new ServiceTab();
		PageModules pageModulesobj = new PageModules();
		DbQueryHelper dbhelper = new DbQueryHelper();
		RAMCommonDBQuires ramCommonDBQueryobj = new RAMCommonDBQuires();
		tdMap = ramCommonDBQueryobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String seqRevenueId = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.SEQ_REVENUE_ID, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		serviceTabobj.memberSearchVal(tdMap.get("RECON_STATUS"), tdMap.get("PLANNAME"), seqRevenueId,
				tdMap.get("MEDICAID_ID"), tdMap.get("SUBSCRIBER_ID"), tdMap.get("REVENUE_MONTH"),
				tdMap.get("INVOICE_ERROR"));
		pageModulesobj.signout();
	}

	@Then("^Validate the search results with db, drill down to the memberDetails page,verify that member should be errorout with Invoice Error as Invoice Key Missing\\[IKM\\] \"([^\"]*)\"$")
	public void validateInvoiceErrorIKM(String testCaseId) throws Throwable {

		Map<String, String> tdMap;
		ServiceTab serviceTabobj = new ServiceTab();
		PageModules pageModulesobj = new PageModules();
		DbQueryHelper dbhelper = new DbQueryHelper();
		RAMCommonDBQuires ramCommonDBQueryobj = new RAMCommonDBQuires();
		tdMap = ramCommonDBQueryobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String seqRevenueId = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.SEQ_REVENUE_ID, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		serviceTabobj.memberSearchVal(tdMap.get("RECON_STATUS"), tdMap.get("PLANNAME"), seqRevenueId,
				tdMap.get("MEDICAID_ID"), tdMap.get("SUBSCRIBER_ID"), "06/01/2016", tdMap.get("INVOICE_ERROR"));
		pageModulesobj.signout();
	}

	@Then("^Validate the search results with db, drill down to the memberDetails page,verify that member should be errorout with Invoice Error as No Rates Found\\[NRF\\] \"([^\"]*)\"$")
	public void validateInvoiceErrorNRF(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		ServiceTab serviceTabobj = new ServiceTab();
		PageModules pageModulesobj = new PageModules();
		DbQueryHelper dbhelper = new DbQueryHelper();
		RAMCommonDBQuires ramCommonDBQueryobj = new RAMCommonDBQuires();
		tdMap = ramCommonDBQueryobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String seqRevenueId = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.SEQ_REVENUE_ID, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		serviceTabobj.memberSearchVal(tdMap.get("RECON_STATUS"), tdMap.get("PLANNAME"), seqRevenueId,
				tdMap.get("MEDICAID_ID"), tdMap.get("SUBSCRIBER_ID"), tdMap.get("REVENUE_MONTH"),
				tdMap.get("INVOICE_ERROR"));
		pageModulesobj.signout();

	}

	@Then("^Validate the search results with db, drill down to the memberDetails page,verify that member should be errorout with Invoice Error as Multiple Rates Found\\[MRF\\] \"([^\"]*)\"$")
	public void validateInvoiceErrorMRF(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		ServiceTab serviceTabobj = new ServiceTab();
		PageModules pageModulesobj = new PageModules();
		DbQueryHelper dbhelper = new DbQueryHelper();
		RAMCommonDBQuires ramCommonDBQueryobj = new RAMCommonDBQuires();
		tdMap = ramCommonDBQueryobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String seqRevenueId = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.SEQ_REVENUE_ID, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		serviceTabobj.memberSearchVal(tdMap.get("RECON_STATUS"), tdMap.get("PLANNAME"), seqRevenueId,
				tdMap.get("MEDICAID_ID"), tdMap.get("SUBSCRIBER_ID"), tdMap.get("REVENUE_MONTH"),
				tdMap.get("INVOICE_ERROR"));
		pageModulesobj.signout();

	}

	@Then("^Validate the search results with db, drill down to the memberDetails page,verify that member should be errorout with Invoice Error as Missing Member Key\\[MKM\\] \"([^\"]*)\"$")
	public void validateInvoiceErrorMKM(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		ServiceTab serviceTabobj = new ServiceTab();
		PageModules pageModulesobj = new PageModules();
		DbQueryHelper dbhelper = new DbQueryHelper();
		RAMCommonDBQuires ramCommonDBQueryobj = new RAMCommonDBQuires();
		tdMap = ramCommonDBQueryobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String seqRevenueId = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.SEQ_REVENUE_ID, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		serviceTabobj.memberSearchVal(tdMap.get("RECON_STATUS"), tdMap.get("PLANNAME"), seqRevenueId,
				tdMap.get("MEDICAID_ID"), tdMap.get("SUBSCRIBER_ID"), tdMap.get("REVENUE_MONTH"),
				tdMap.get("INVOICE_ERROR"));
		pageModulesobj.signout();

	}

	@Given("^The bulkUpdate file should be present in the testdata folder \"([^\"]*)\"$")
	public void verifyBulkUpdateFileInTestdataFolder(String testCaseId) throws Throwable {
		RateuploadRunner obj1 = new RateuploadRunner();
		obj1.setUpClass();
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		Map<String, String> tdMap;
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);

		inputFileName = tdMap.get("PATHNAME") + "/" + tdMap.get("FILENAME");
		File file = new File(inputFileName);
		if (!file.exists()) {
			Assert.fail("\n BulkUpdate upload date file " + tdMap.get("FILENAME") + " does not exist at : "
					+ tdMap.get("PATHNAME") + "\n" + "for test case " + testCaseId);
		} else {
			System.out.println("\n BulkUpdate data file " + tdMap.get("FILENAME") + " exist at : "
					+ tdMap.get("PATHNAME") + "\n" + "for test case " + testCaseId);
		}

	}

	@When("^The user should navigate to the bulk update screen  \"([^\"]*)\"$")
	public void navigateToBulkUpdateScreen(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		PageModules pageModulesobj = new PageModules();
		ServiceTab serviceTabobj = new ServiceTab();
		pageModulesobj.navigateToRAMUI();
		pageModulesobj.enterCredentials();
		pageModulesobj.selectRevenueStream(tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE"));
		serviceTabobj.clickonServiceTab();

	}

	@Then("^Upload the bulkUpdate file present in the testdata folder,validate the  file upload success message,Upload fileName on the screen with the Status as Uploaded \"([^\"]*)\"$")
	public void validateTheUploadedFile(String testCaseId) throws Throwable {
		ServiceTab serviceTabobj = new ServiceTab();
		Map<String, String> tdMap;
		RAMCommonDBQuires ramCmnDBobj = new RAMCommonDBQuires();
		PageModules pageModulesobj = new PageModules();
		tdMap = ramCmnDBobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String bulkUpdateFilepath = tdMap.get("PATHNAME").replace("/", "\\");
		inputFileName = System.getProperty("user.dir") + "\\" + bulkUpdateFilepath + "\\" + tdMap.get("FILENAME");
		serviceTabobj.bulkUpdate(inputFileName, tdMap.get("FILENAME"));
		pageModulesobj.signout();
		
	}
	
	@When("^Download the Demographic and Eligibility Error file \"([^\"]*)\"$")
	public void download_the_Demographic_and_Eligibility_Error_file(String testCaseId) throws Throwable {
		RAMCommonDBQuires commonDBQuires = new RAMCommonDBQuires();
		Map<String, String> tdMap = commonDBQuires.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		PageModules pageModulesobj = new PageModules();
		String planName = tdMap.get("PLANNAME");
		if(planName == null || planName.length() == 0){
			pageModulesobj.signout();
			Assert.fail(testCaseId + " Mandatory field is missing in Test data Sheet, field Name is : Plan Name");
		}
		String revenueType = tdMap.get("REVENUETYPE");
		if(revenueType == null || revenueType.length() == 0){
			pageModulesobj.signout();
			Assert.fail(testCaseId + " Mandatory field is missing in Test data Sheet, field Name is : Revenue Type");
		}
		String companyCode = tdMap.get("COMPANYCODE");
		if(companyCode == null || companyCode.length() == 0){
			pageModulesobj.signout();
			Assert.fail(testCaseId + " Mandatory field is missing in Test data Sheet, field Name is : Company Code");
		}
		String fileName = tdMap.get("FILENAME");
		if(fileName == null || fileName.length() == 0){
			pageModulesobj.signout();
			Assert.fail(testCaseId + " Mandatory field is missing in Test data Sheet, field Name is : File Name");
		}
		String pathName = tdMap.get("PATHNAME");
		if(pathName == null || pathName.length() == 0){
			pageModulesobj.signout();
			Assert.fail(testCaseId + " Mandatory field is missing in Test data Sheet, field Name is : File Path Name");
		}
		ServiceTab serviceTab = new ServiceTab();
		serviceTab.clickonServiceTab();
		serviceTab.batchReportScreen("Membership Error Reports");
		serviceTab.membershipErrorFileDownLoad(autoItexecutableFilePath, downloadedFilePath, tdMap.get("FILENAME"));
		
		pageModulesobj.signout();
	}

	@Then("^validate the Membership Demographic and Eligibility Error Report \"([^\"]*)\"$")
	public void validate_the_Membership_Demographic_and_Eligibility_Error_Report(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		RAMCommonDBQuires RAMCommonDBQuiresobj = new RAMCommonDBQuires();
		tdMap = RAMCommonDBQuiresobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE",testCaseId);
		Long numberOfLinesInTextFile;
		Long bodyRowStart;
		Long bodyRowEnd;
		List<String> linesInTextFile = null;
		CSVReader csvreader;
		
		
    	File file = new File(downloadedFilePath+tdMap.get("FILENAME"));
    	
    	if(file != null && file.exists()){
    		csvreader = new CSVReader(new FileReader(downloadedFilePath+tdMap.get("FILENAME")), ',', '"');
    		linesInTextFile = csvreader.readAll();
            numberOfLinesInTextFile = (long) linesInTextFile.size();
            bodyRowStart = (long) 2;
            bodyRowEnd = numberOfLinesInTextFile;
            csvreader.close();
            tdMap.get("FILENAME");
            if(tdMap.get("FILENAME") != null && tdMap.get("FILENAME").contains("DEMO")){
            FlatFileProcessor.createAndPopulateDetailsTableFromDataFile(linesInTextFile, "MEMBERSHIP_DEMOERROR_CONFIG","MEMBERSHIP_DEMOERROR_ACTUAL", bodyRowStart, bodyRowEnd, true);
            FlatFileProcessor.createAndPopulateDetailsTableFromFacets(linesInTextFile, "MEMBERSHIP_DEMOERROR_CONFIG", "MEMBERSHIP_DEMOERROR_KEY_DEFINITION","MEMBERSHIP_DEMOERROR_EXPECTED", bodyRowStart, bodyRowEnd, true);
            FlatFileProcessor.compareTableData("MEMBERSHIP_DEMOERROR_ACTUAL", "MEMBERSHIP_DEMOERROR_EXPECTED");
            }else if(tdMap.get("FILENAME") != null && tdMap.get("FILENAME").contains("ELIG")){
            	
            	FlatFileProcessor.createAndPopulateDetailsTableFromDataFile(linesInTextFile, "MEMBERSHIP_ELIGERROR_CONFIG","MEMBERSHIP_ELIGERROR_ACTUAL", bodyRowStart, bodyRowEnd, true);
            	FlatFileProcessor.createAndPopulateDetailsTableFromFacets(linesInTextFile, "MEMBERSHIP_ELIGERROR_CONFIG", "MEMBERSHIP_ELIGERROR_KEY_DEFINITION","MEMBERSHIP_ELIGERROR_EXPECTED", bodyRowStart, bodyRowEnd, true);
            	FlatFileProcessor.compareTableData("MEMBERSHIP_ELIGERROR_ACTUAL", "MEMBERSHIP_ELIGERROR_EXPECTED");
            }
    	}else{
    		Assert.fail(testCaseId + " "+ tdMap.get("FILENAME") +" does not exist at location "+downloadedFilePath);
    	}
	}
	
	@When("^Download the Bulk Update Error file \"([^\"]*)\"$")
	public void download_the_Bulk_Update_Error_file(String testCaseId) throws Throwable {
		RAMCommonDBQuires commonDBQuires = new RAMCommonDBQuires();
		Map<String, String> tdMap = commonDBQuires.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		PageModules pageModulesobj = new PageModules();
		String planName = tdMap.get("PLANNAME");
		if(planName == null || planName.length() == 0){
			pageModulesobj.signout();
			Assert.fail(testCaseId + " Mandatory field is missing in Test data Sheet, field Name is : Plan Name");
		}
		String revenueType = tdMap.get("REVENUETYPE");
		if(revenueType == null || revenueType.length() == 0){
			pageModulesobj.signout();
			Assert.fail(testCaseId + " Mandatory field is missing in Test data Sheet, field Name is : Revenue Type");
		}
		String companyCode = tdMap.get("COMPANYCODE");
		if(companyCode == null || companyCode.length() == 0){
			pageModulesobj.signout();
			Assert.fail(testCaseId + " Mandatory field is missing in Test data Sheet, field Name is : Company Code");
		}
		String fileName = tdMap.get("FILENAME");
		if(fileName == null || fileName.length() == 0){
			pageModulesobj.signout();
			Assert.fail(testCaseId + " Mandatory field is missing in Test data Sheet, field Name is : File Name");
		}
		String pathName = tdMap.get("PATHNAME");
		if(pathName == null || pathName.length() == 0){
			pageModulesobj.signout();
			Assert.fail(testCaseId + " Mandatory field is missing in Test data Sheet, field Name is : File Path Name");
		}
		ServiceTab serviceTab = new ServiceTab();
		serviceTab.clickonServiceTab();
		serviceTab.batchReportScreen("Bulk Update Error Files");
		serviceTab.bulkUpdateErrorFileDownLoad(autoItexecutableFilePath, downloadedFilePath, tdMap.get("FILENAME"));

		pageModulesobj.signout();
	}

	@Then("^validate the Bulk Update Error File Report \"([^\"]*)\"$")
	public void validate_the_Bulk_Update_Error_File_Report(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		RAMCommonDBQuires RAMCommonDBQuiresobj = new RAMCommonDBQuires();
		tdMap = RAMCommonDBQuiresobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE",testCaseId);
		
		List<String> linesInTextFile = null;
		File file = new File(downloadedFilePath+tdMap.get("FILENAME"));
    	
    	if(file != null && file.exists()){
    		linesInTextFile = FlatFileProcessor.readExcelData(downloadedFilePath+tdMap.get("FILENAME"), "Sheet0");
    		FlatFileProcessor.createAndPopulateDetailsTableFromDataFile(linesInTextFile, "BULK_UPLOADERROR_CONFIG", "BULK_UPLOADERROR_ACTUAL", 1, linesInTextFile.size(), true);
    		RateUploadDBqueries.validateBulkUploadErrorDataInFile("BULK_UPLOADERROR_ACTUAL", tdMap.get("PLANNAME"));
    		
    	}else{
    		Assert.fail(testCaseId + " "+ tdMap.get("FILENAME") +" does not exist at location "+downloadedFilePath);
    	}
	}
	
	@Then("^verify and validate Add Revenue Stream Screen \"([^\"]*)\"$")
	public void verifyAndValidateAddRevenueStreamScreen(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		RAMCommonDBQuires RAMCommonDBQuiresobj = new RAMCommonDBQuires();
		tdMap = RAMCommonDBQuiresobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE",testCaseId);
		RevenueStreamTab.clickOnRevStreamTab();
		RevenueStreamTab.clickOnAddRevenueStreamLink();
		RevenueStreamTab.populateRevenueStreamDataForm(tdMap, testCaseId);
	}
	
	@Then("^verify and validate update Revenue Stream Screen \"([^\"]*)\"$")
	public void verifyAndValidateUpdateRevenueStreamScreen(String testCaseId) throws Throwable {
		RAMCommonDBQuires RAMCommonDBQuiresobj = new RAMCommonDBQuires();
		Map<String, String> tdMap = RAMCommonDBQuiresobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE",testCaseId);
		String planName = tdMap.get("PLANNAME");
		if(planName == null || planName.length() == 0){
			Assert.fail(testCaseId + " Mandatory field is missing in Test data Sheet, field Name is : Plan Name");
		}
		String revenueType = tdMap.get("REVENUETYPE");
		if(revenueType == null || revenueType.length() == 0){
			Assert.fail(testCaseId + " Mandatory field is missing in Test data Sheet, field Name is : Revenue Type");
		}
		String configEffectiveDt = tdMap.get("CONFIGURATIONEFFECTIVEDATE");
		if(configEffectiveDt == null || configEffectiveDt.length() == 0){
			Assert.fail(testCaseId + " Mandatory field is missing in Test data Sheet, field Name is : Configuration Effective Date");
		}
		RevenueStreamTab.clickOnRevStreamTab();
		RevenueStreamTab.clickOnUpdateRevenueStreamLink();
		boolean isRowPresent = RevenueStreamTab.validateRevenueDetails(tdMap);
		if(isRowPresent == true){
			RevenueStreamTab.updateRevenueStreamDetails(tdMap, testCaseId);
		}else{
			Assert.fail(testCaseId + " No such Record found with given test parameters to update the Revenue Stream.");
		}
		
		
	}
	
	@Then("^verify and validate view Revenue Stream Screen \"([^\"]*)\"$")
	public void verifyAndValidateViewRevenueStreamScreen(String testCaseId) throws Throwable {
		RAMCommonDBQuires RAMCommonDBQuiresobj = new RAMCommonDBQuires();
		Map<String, String> tdMap = RAMCommonDBQuiresobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE",testCaseId);
		RevenueStreamTab.clickOnRevStreamTab();
		RevenueStreamTab.clickOnViewRevenueStreamLink();
		String planName = tdMap.get("PLANNAME");
		if(planName == null || planName.length() == 0){
			Assert.fail(testCaseId + " Mandatory field is missing in Test data Sheet, field Name is : PLANNAME");
		}
		String revenueType = tdMap.get("REVENUETYPE");
		if(revenueType == null || revenueType.length() == 0){
			Assert.fail(testCaseId + " Mandatory field is missing in Test data Sheet, field Name is : REVENUETYPE");
		}
		String configEffectiveDt = tdMap.get("CONFIGURATIONEFFECTIVEDATE");
		if(configEffectiveDt == null || configEffectiveDt.length() == 0){
			Assert.fail(testCaseId + " Mandatory field is missing in Test data Sheet, field Name is : Configuration Effective Date");
		}
		boolean isRowPresent = RevenueStreamTab.validateRevenueDetails(tdMap);
		if(isRowPresent == true){
			RevenueStreamTab.validateViewRevenueHistory(tdMap, testCaseId);
		}else{
			Assert.fail(testCaseId + " No such Record found with given test parameters to update the Revenue Stream.");
		}
	}

//Added by ksushman merging Issue

	@Given("^The rateUpload file should be present in the testdata rates folder \"([^\"]*)\"$")
	public void rateFileValidationInTestDataFolder(String testCaseId) throws Throwable {
		// RateuploadRunner obj1 = new RateuploadRunner();
		// obj1.setUpClass();
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		Map<String, String> tdMap;
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);

		inputFileName = tdMap.get("PATHNAME") + "/" + tdMap.get("FILENAME");
		File file = new File(inputFileName);
		if (!file.exists()) {
			Assert.fail("\n Rate upload date file " + tdMap.get("FILENAME") + " does not exist at : "
					+ tdMap.get("PATHNAME") + "\n" + "for test case " + testCaseId);
		} else {
			System.out.println("\n Rate upload data file " + tdMap.get("FILENAME") + " exist at : "
					+ tdMap.get("PATHNAME") + "\n" + "for test case " + testCaseId);
		}
	}
	@When("^Upload the rate file in the testdata folder for \"([^\"]*)\"$")
	public void uploadRateFileInBulkRatesScreen(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		RatesTab rateTabobj=new RatesTab();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String rateFilepath = tdMap.get("PATHNAME").replace("/", "\\");
		inputFileName = System.getProperty("user.dir") + "\\" + rateFilepath + "\\" + tdMap.get("FILENAME");
		System.out.println("THE INPUT FILENAME IS:" + inputFileName);
		rateTabobj.uploadRatefile(inputFileName, tdMap.get("FILENAME"));

	}
	@When("^The user should navigate to the Bulk Rates upload screen  \"([^\"]*)\"$")
	public void clickOnRatesTab(String testCaseId) throws Throwable {
		RateuploadRunner obj1 = new RateuploadRunner();
		obj1.setUpClass();
		Map<String, String> tdMap;
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		DbQueryHelper dbhelper = new DbQueryHelper();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		PageModules pageModulesobj = new PageModules();
		RatesTab rateTabobj=new RatesTab();

		String companyCode = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.COMPANY_CODE, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.RATEFILE_BACKOUT,companyCode));
		pageModulesobj.navigateToRAMUI();
		pageModulesobj.enterCredentials();
		pageModulesobj.selectRevenueStream(companyCode, tdMap.get("REVENUETYPE"));
		rateTabobj.clickonRatesTab();

	}
	@Then("^validate the rate file upload success message on the screen,Inserted into rate_upload_header table with status as 'U' for  \"([^\"]*)\" \\.$")
	public void ratefileValidation(String testCaseId) throws Throwable {
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		DbQueryHelper dbhelper = new DbQueryHelper();
		PageModules pageModulesobj = new PageModules();
		Map<String, String> tdMap;
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String companyCode = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.COMPANY_CODE, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		String statusRatesDb = dbhelper
				.getMultipleValues(String.format(RateUploadDBqueries.RATE_UPLOAD_STATUS, companyCode,tdMap.get("FILENAME")));
		if (statusRatesDb.equals("U")) {
			System.out.println("The Status column in the rate_upload_header is inserted successfully as Uploaded:"
					+ statusRatesDb);
		} else {
			Assert.fail("The Status column in the rate_upload_header is wrong" + statusRatesDb);
		}
		pageModulesobj.signout();
	}

	@Given("^The RateUpload file should be uploaded from the RAM UI \"([^\"]*)\"$")
	public void validateUploadedRateFileStatus(String testCaseId) throws Throwable {
		//RateuploadRunner obj1 = new RateuploadRunner();
		//obj1.setUpClass();// --------------------------------------------Comment
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		DbQueryHelper dbhelper = new DbQueryHelper();
		Map<String, String> tdMap;
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String companyCode = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.COMPANY_CODE, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		String statusRatesDb = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.RATE_UPLOAD_STATUS, companyCode, tdMap.get("FILENAME")));
		if (statusRatesDb.equals("U")) {
			System.out.println("The Status column in the rate_upload_header is inserted successfully as Uploaded:"
					+ statusRatesDb);
		} else {
			Assert.fail("The Status column in the rate_upload_header is wrong" + statusRatesDb
					+ "Clear the Db and Load the file Again");
		}

	}

	@When("^The RateUpload Job Should run with out any errors for plan \"([^\"]*)\"$")
	public void triggerRatesBatchJob(String testCaseId) throws Throwable {
		boolean jobStatus;
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		RatesCommon common = new RatesCommon();
		DbQueryHelper dbhelper = new DbQueryHelper();
		Map<String, String> tdMap;
		try {
			tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
			String companyCode = dbhelper.getMultipleValues(
					String.format(RateUploadDBqueries.COMPANY_CODE, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));

			jobStatus = common.triggerRateUploadJob(companyCode, tdMap.get("REVENUETYPE"));
			if (!jobStatus) {
				Assert.fail(InvoiceConstants.INVOICE_JOB_FAIL);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("The Shell Job does not triggered properly due to the " + e.getMessage() + "Exception");
		}

	}

	@Then("^Verify the InvoiceFlag in the RAM UI and uncheck the Invoice Flag  \"([^\"]*)\"$")
	public void checkTheInvoiceFlagStatusAndUncheckTheFlag(String arg1) throws Throwable {
		RatesTab rateTabobj = new RatesTab();
		rateTabobj.clickOnHoldReconLink();
		rateTabobj.CheckTheStatusOfholdInvoiceFlag();
	}

	@Then("^Validate the data in the RAM UI with Db \"([^\"]*)\"$")
	public void ValidateTheDataInRAmUIwithDb(String arg1) throws Throwable {
		RatesTab rateTabobj = new RatesTab();
		rateTabobj.viewRatesValiadtion();

	}

	@When("^click on the View rates link,select the rates from leftpane to right pane and click on the search button  \"([^\"]*)\"$")
	public void perfomSearchViewRatesScreen(String testCaseId) throws Throwable {
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		Map<String, String> tdMap;
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		RatesTab rateTabobj = new RatesTab();
		rateTabobj.clickonRatesTab();
		rateTabobj.navigateToViewRatesSearchonlytheSelectedRiskGroup(tdMap.get("RATECELL"), tdMap.get("TERMDATE"));

	}

	@Then("^Validate that the termdate of the plancodes under a riskGroup should have the same termdate as riskgroup \"([^\"]*)\"$")
	public void termDateValidationForPlanCode(String testCaseId) throws Throwable {
		RatesTab rateTabobj = new RatesTab();
		PageModules pageModulesobj = new PageModules();
		rateTabobj.termDateValidation();
		pageModulesobj.signout();

	}

	@When("^click on the Insert rates link,Enter all the required fields anc click on Add button \"([^\"]*)\"$")
	public void enterDetailsInsertRateScreen(String testCaseId) throws Throwable {
		RatesTab rateTabobj = new RatesTab();
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		Map<String, String> tdMap;
		DbQueryHelper dbhelper = new DbQueryHelper();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String companyCode = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.COMPANY_CODE, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		rateTabobj.clickonRatesTab();
		rateTabobj.insertRateField(tdMap.get("RATECELL"), companyCode, tdMap.get("TERMDATE"));
	}

	@Then("^Rate should be inserted into the RAM system\"([^\"]*)\"$")
	public void verifyTheInsertedRate(String testCaseId) throws Throwable {
		RatesTab rateTabobj = new RatesTab();
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		PageModules pageModulesobj = new PageModules();
		Map<String, String> tdMap;
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		rateTabobj.clickonRatesTab();
		rateTabobj.navigateToViewRatesSearchonlytheSelectedRiskGroup(tdMap.get("RATECELL"),tdMap.get("STATUSOFRECORD"));
		pageModulesobj.signout();

	}

	@When("^click on the Update rates link,select the rates from leftpane to right pane and click on the search button\"([^\"]*)\"$")
	public void updateRatesPerformSearch(String testCaseId) throws Throwable {
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		Map<String, String> tdMap;
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		RatesTab rateTabobj = new RatesTab();
		rateTabobj.clickonRatesTab();
		rateTabobj.perfromSearchOnUpdateRateScreen(tdMap.get("RATECELL"));

	}

	@Then("^Update the termdate of the riskgroup and Ensure that the rateUpdate success message should be displayed on the screen \"([^\"]*)\"$")
	public void updateTheTermDate(String testCaseId) throws Throwable {
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		RatesTab rateTabobj = new RatesTab();
		PageModules pageModulesobj = new PageModules();
		Map<String, String> tdMap;
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		rateTabobj.updateTheTermDate(tdMap.get("TERMDATE"));
		rateTabobj.clickonRatesTab();
		rateTabobj.navigateToViewRatesSearchonlytheSelectedRiskGroup(tdMap.get("RATECELL"), tdMap.get("TERMDATE"));
		pageModulesobj.signout();
	}

	@When("^click on the Update rates link,select the rates from leftpane to right pane and click on the search button  \"([^\"]*)\"$")
	public void performSearchOnUpdateRateScreen(String testCaseId) throws Throwable {
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		Map<String, String> tdMap;
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		RatesTab rateTabobj = new RatesTab();
		rateTabobj.clickonRatesTab();
		rateTabobj.perfromSearchOnUpdateRateScreen(tdMap.get("RATECELL"));
	}

	@When("^click on the  Update rates link,select the rates from leftpane to right pane and click on the search button  \"([^\"]*)\"$")
	public void performSearchOnupdateRates(String testCaseId) throws Throwable {
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		Map<String, String> tdMap;
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		RatesTab rateTabobj = new RatesTab();
		rateTabobj.clickonRatesTab();
		rateTabobj.perfromSearchOnUpdateRateScreen(tdMap.get("RATECELL"));
	}

	@Then("^select the VoidRate Checkbox of the riskgroup, click on save button and Ensure that the rateUpdate success message should be displayed on the screen \"([^\"]*)\"$")
	public void voidRate(String testCaseId) throws Throwable {
		RatesTab rateTabobj = new RatesTab();
		Map<String, String> tdMap;
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		PageModules pageModulesobj = new PageModules();
		DbQueryHelper dbhelper = new DbQueryHelper();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String companyCode = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.COMPANY_CODE, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		rateTabobj.voidRate();
		rateTabobj.clickonRatesTab();
		rateTabobj.navigateToViewRatesSearchonlytheSelectedRiskGroup(tdMap.get("RATECELL"),tdMap.get("STATUSOFRECORD"));
		 dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.RAM_RATE_CATEG_BACKOUT,companyCode, tdMap.get("RATECELL")));
		 dbhelper.getMultipleValues(
					String.format(RateUploadDBqueries.RAM_RATE_MATRIX_BACKOUT,companyCode,tdMap.get("RATECELL")));
		pageModulesobj.signout();
	}

	@When("^click on the Add planCode Screen and enter the plancode name under the required riskGroup and click on Add button\"([^\"]*)\"$")
	public void addPlanCodeScreen(String testCaseId) throws Throwable {
		RatesTab rateTabobj = new RatesTab();
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		Map<String, String> tdMap;
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		rateTabobj.clickonRatesTab();
		rateTabobj.addPlanCodes(tdMap.get("RATECELL"), tdMap.get("PLANCODE"));

	}

	@Then("^The plancode should be added successfully under the selected riskgroup\"([^\"]*)\"$")
	public void verifyTheAddedPlancode(String testCaseId) throws Throwable {
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		Map<String, String> tdMap;
		RatesTab rateTabobj = new RatesTab();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		rateTabobj.clickonRatesTab();
		rateTabobj.navigateToViewRatesSearchonlytheSelectedRiskGroup(tdMap.get("RATECELL"), tdMap.get("TERMDATE"));

	}

	@Then("^click on the ratecell link ,The rates for all the revenue types should be diplayed for risk group \"([^\"]*)\"$")
	public void rateAssociatedToAllRevenueType(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		RatesTab rateTabobj = new RatesTab();
		DbQueryHelper dbhelper = new DbQueryHelper();
		PageModules pageModulesobj = new PageModules();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String seqRevenueId = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.SEQ_REVENUE_ID, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		rateTabobj.plancodeMappingToRiskGroup(tdMap.get("RATECELL"), seqRevenueId);
		pageModulesobj.signout();
	}

	@When("^click on the Rate Matrix link,select the rates from leftpane to right pane and click on the search button  \"([^\"]*)\"$")
	public void click_on_the_Rate_Matrix_link_select_the_rates_from_leftpane_to_right_pane_and_click_on_the_search_button(
			String testCaseId) throws Throwable {
		RatesTab rateTabobj = new RatesTab();
		rateTabobj.clickonRatesTab();
	}

	@Then("^validate the displayed search results \"([^\"]*)\"$")
	public void validate_the_displayed_search_results(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		RatesTab rateTabobj = new RatesTab();
		PageModules pageModulesobj = new PageModules();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		rateTabobj.navigateToViewRatesSearchonlytheSelectedRiskGroup(tdMap.get("RATECELL"), tdMap.get("TERMDATE"));
		pageModulesobj.signout();
	}

	@When("^check the Invoice Flag checkbox in Hold reconciliation screen$")
	public void navigateTo() throws Throwable {
		RatesTab rateTabobj = new RatesTab();
		rateTabobj.clickOnHoldReconLink();
		rateTabobj.holdInvoiceBatch();
	}

	@Then("^Trigger the Invoice batch job in the unix system \"([^\"]*)\"$")
	public void triggerInvoiceBath(String testCaseId) throws Throwable {
		RatesCommon ratesCommonobj = new RatesCommon();
		DbQueryHelper dbhelper = new DbQueryHelper();
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		PageModules pageModulesobj = new PageModules();
		Map<String, String> tdMap;
		boolean jobStatus = false;
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String seqRevenueId = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.SEQ_REVENUE_ID, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		ratesCommonobj.triggerInvoiceJobWhenFlagisHold(tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE"), seqRevenueId);

		if (!jobStatus) {
			Assert.fail("The Invoice process is not equalheld on Hold");
		}
		pageModulesobj.signout();
	}
	
	@Then("^verify and validate for Force Close with Insert Comments \"([^\"]*)\"$")
	public void verifyAndValidateForForceCloseWithInsertComments(String testCaseId) throws Throwable {
		RAMCommonDBQuires RAMCommonDBQuiresobj = new RAMCommonDBQuires();
		Map<String, String> tdMap = RAMCommonDBQuiresobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE",testCaseId);
		ServiceTab serviceTab = new ServiceTab();
		serviceTab.clickonServiceTab();
		serviceTab.clickOnTrackingOverallPageLink();
		serviceTab.submitFieldsAndValidate(tdMap);
	}
	
	@Then("^verify and validate Verify the Bulk update process \"([^\"]*)\"$")
	public void verifyAndValidateVerifyTheBulkUpdateProcess(String testCaseId) throws Throwable {
		RAMCommonDBQuires RAMCommonDBQuiresobj = new RAMCommonDBQuires();
		Map<String, String> tdMap = RAMCommonDBQuiresobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE",testCaseId);
		ServiceTab serviceTab = new ServiceTab();
		String fileName = tdMap.get("FILENAME");
		boolean isFilePresentInUI = false;
		if(fileName != null && fileName.length()>0){		
		serviceTab.clickonServiceTab();
		List<Map<String, String>> list = serviceTab.validateBulkUpdateProcess();				
		if(list != null){
			for(Map<String, String> map : list){
				if(fileName.equalsIgnoreCase(map.get("fileName"))){
					isFilePresentInUI = true;
				}
				
			}
		}
		
		}else{
			Assert.fail("In Test Data Sheat there is no file to Validate, for Test Case "+testCaseId);
		}
		if(isFilePresentInUI == true){
			// Run Bulk Update Process Job then
			String JobName = CSPPropertyReader.getBulkupdateJob();
			String UnixHost = CSPPropertyReader.getUnixServer();
			String UnixUser = CSPPropertyReader.getUnixUsername();
			String UnixPass = CSPPropertyReader.getUnixPassword();
			String planName = tdMap.get("PLANNAME");
			String revenueType = tdMap.get("REVENUETYPE");
			String companyCode = tdMap.get("COMPANYCODE");
			String seqRevenueId = "100021";//tdMap.get("SEQ_REVENUE_ID");
			String finalJobName = JobName+" "+companyCode+" "+planName+" "+seqRevenueId+" "+revenueType;
			System.out.println(" finalJobName == "+finalJobName);
			boolean isBulkUpdateJobExecuted = UnixUtilityHelper.execute_unix_BulkUpdatejob(finalJobName, UnixHost, UnixUser, UnixPass);
			System.out.println("isBulkUpdateJobExecuted === "+isBulkUpdateJobExecuted);
			if(isBulkUpdateJobExecuted == false){
				Assert.fail("Batch Job "+finalJobName+" , is not completed Successfully for , Test Case "+testCaseId);
			}
		}else{
			Assert.fail("In Bulk Update UI "+fileName+" , given File is not Present for, Test Case "+testCaseId);
		}
	}

	@Then("^Validate the Member from Search Screen \"([^\"]*)\"$")
	public void validateTheMemberFromSearchScreen(String testCaseId) throws Throwable {
		RAMCommonDBQuires RAMCommonDBQuiresobj = new RAMCommonDBQuires();
		Map<String, String> tdMap = RAMCommonDBQuiresobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE",testCaseId);
		ServiceTab serviceTab = new ServiceTab();
		PageModules pageModulesobj = new PageModules();
		pageModulesobj.enterCredentials();
		pageModulesobj.selectRevenueStream(tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE"));
		serviceTab.validateMemberForBulkUpdate(tdMap);
		pageModulesobj.signout();
	}
	@When("^check the reconciliation Flag checkbox in Hold reconciliation screen$")
	public void checkOnRecoFlagStatus() throws Throwable {
		RatesTab rateTabobj = new RatesTab();
		PageModules pageModulesobj = new PageModules();
		rateTabobj.clickOnHoldReconLink();
		rateTabobj.holdReconBatch();
		pageModulesobj.signout();
		
	}

	@Then("^Trigger the Reconciliation batch job in the unix system \"([^\"]*)\"$")
	public void runTheReconJob(String testCaseId) throws Throwable {
		
		DbQueryHelper dbhelper = new DbQueryHelper();
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		ReconCommon reconCommonobj=new ReconCommon();
		Map<String, String> tdMap;
		boolean jobStatus;
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		System.out.println("The JOB Name is:"+String.format(CSPPropertyReader.getReconJob(),tdMap.get("PLANNAME")));
		String seqRevenueId = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.SEQ_REVENUE_ID, tdMap.get("PLANNAME"), tdMap.get("REVENUETYPE")));
		jobStatus=reconCommonobj.reconJobHold(String.format(CSPPropertyReader.getReconJob(),tdMap.get("PLANNAME")),CSPPropertyReader.getUnixServer(), CSPPropertyReader.getUnixUsername(),CSPPropertyReader.getUnixPassword(),tdMap.get("PLANNAME"),seqRevenueId);
		if (!jobStatus) {
			System.out.println("The Status of the Floag is:"+jobStatus);
			Assert.fail("The Reconciliation process has run sucessfully even the Flag is on Hold:"+jobStatus);
		}
	}
	
	@When("^Click on the Service Tab and navigate to the Aging Report Screen$")
	public void click_on_the_Service_Tab_and_navigate_to_the_Aging_Report_Screen() throws Throwable {
		ServiceTab serviceTabobj=new ServiceTab();
		serviceTabobj.clickonServiceTab();
		serviceTabobj.agingReport();
	  
	}

	@Then("^The Aging Report should be displayed on the Screen$")
	public void the_Aging_Report_should_be_displayed_on_the_Screen() throws Throwable {
		ServiceTab serviceTabobj=new ServiceTab();
		PageModules pageModulesobj = new PageModules();
		serviceTabobj.agingReport();
		pageModulesobj.signout();
	
	}

}
 
