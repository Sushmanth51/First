package com.optum.ram.invoice;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

import com.optum.facets.atdd.common.utils.ConnectionHelper;
import com.optum.facets.atdd.common.utils.FlatFileProcessor;
import com.optum.ram.atdd.common.utils.CSPCommonTestBase;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@CucumberOptions(features = InvoiceConstants.INVOICE_FEATURES, format = {
		InvoiceConstants.INVOICE_RESULT_FORMAT }, snippets = SnippetType.CAMELCASE)
public class InvoiceRunner extends CSPCommonTestBase{
	public static String eligiblityUploadExtractTDFilePath = "src/main/resources/eligibilityUpload/testdata/EligibilityUpload_TestData.xls";
	public static String eligiblityUploadExtractTDConfigTable = "ELIGIBILITY_UPLOAD_TEST_DATA_CONFIG_TABLE";
	public static String eligiblityUploadExtractTDActualTable = "ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE";
	static boolean jobStatus = false;
	
	/*public static void main(String[] args) throws Exception {
		InvoiceRunner invoiceRunner = new InvoiceRunner();
	//	invoiceRunner.checkNRFpresence("VAMDN");
		invoiceRunner.verifyNRFresult("VAMDN","110057");		
	}*/
	
	@BeforeClass
	public void setUpClass()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException, IOException {
		super.setUpClass();
		try {

			ConnectionHelper.sqliteConnection = ConnectionHelper
					.openSqliteConnection("src/main/resources/eligibilityUpload/db_file/eligibilityUpload.db");
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String strcolnames = FlatFileProcessor.getExcelColumn(eligiblityUploadExtractTDFilePath, "Global");
		FlatFileProcessor.createConfigTable(eligiblityUploadExtractTDConfigTable, strcolnames);
		List myList;
		try {

			myList = FlatFileProcessor.readExcelData(eligiblityUploadExtractTDFilePath, "Global");
			FlatFileProcessor.createAndPopulateDetailsTableFromDataFile(myList, eligiblityUploadExtractTDConfigTable,
					eligiblityUploadExtractTDActualTable, 1, myList.size(), true);
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * TC036
	 * @param plan
	 * Method to check whether Membership info is available or not
	 * @throws IOException 
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	@Given("^Membership information should be available in sytem for plan \"([^\"]*)\"$")
	public void checkMemberDataPresence(String plan) throws ClassNotFoundException, SQLException, IOException {
		boolean checkStatus = false;
		InvoiceCommon common = new InvoiceCommon();
		try {
			checkStatus = common.checkMemberDataPresence(plan);
			if (!checkStatus) {
				Assert.fail(String.format(InvoiceConstants.NO_MEM_DATA,plan));
			}
		} catch (Exception e) {
			Assert.fail(String.format(InvoiceConstants.NO_MEM_DATA,plan)+e.getMessage());
		}
	}

	/**
	 * TC036
	 * @param plan
	 * @param revId
	 * @param seqRevId
	 */
	@When("^The Invoice Job Should run with out any errors for plan \"([^\"]*)\" and revType \"([^\"]*)\" and seqRevId \"([^\"]*)\"$")
	public void checkBatchSuccessStatus(String plan, String revType, String seqRevId) {
		InvoiceCommon common = new InvoiceCommon();
		jobStatus = common.triggerInvoiceJob(plan, revType, seqRevId);
		if (!jobStatus) {
			Assert.fail(InvoiceConstants.INVOICE_JOB_FAIL);
		}
	}

	/**
	 * TC036
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 */
	@Then("^Verify status of the Invoice batch execution$")
	public void verifyBatchStatus() {
		if (!jobStatus) {
			Assert.fail(InvoiceConstants.INVOICE_JOB_FAIL);
		}
	}
	
	/**
	 * TC037
	 * @param seqRevId
	 * Method to check the presence of INVOICE HEADER data
	 * @throws SQLException 
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	@When("^Verify Header information available in the system for seqRevId \"([^\"]*)\"$")
	public void checkHeaderInfoPresence(String seqRevId) throws ClassNotFoundException, IOException, SQLException{
		boolean checkStatus = false;
		InvoiceCommon common = new InvoiceCommon();
		try {
			checkStatus = common.verifyHeaderInfoPresence(seqRevId);
			if (!checkStatus) {
				Assert.fail(String.format(InvoiceConstants.NO_INVOICE_HEADER_DATA,seqRevId));
			}
		} catch (Exception e) {
			Assert.fail(String.format(InvoiceConstants.NO_INVOICE_HEADER_DATA,seqRevId)+e.getMessage());
		}
	}

	/**
	 * TC037
	 * @param seqRevId
	 * Method to validate the presence of INVOICE HEADER parent records w.r.t DETAIL records
	 * @throws SQLException 
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	@Then("^Verify Header information whether file level parent records inserted properly for plan \"([^\"]*)\" and seqRevId \"([^\"]*)\"$")
	public void validateHeaderData(String plan, String seqRevId) throws ClassNotFoundException, IOException, SQLException{
		boolean checkStatus = false;
		InvoiceCommon common = new InvoiceCommon();
		try {
			checkStatus = common.validateHeaderData(plan, seqRevId);
			if (!checkStatus) {
				Assert.fail(String.format(InvoiceConstants.IN_COMPATABLE_HEADER_DATA,plan,seqRevId));
			}
		} catch (Exception e) {
			Assert.fail(String.format(InvoiceConstants.IN_COMPATABLE_HEADER_DATA,plan,seqRevId)+e.getMessage());
		}
	}
	
	/**
	 * TC038
	 * @param plan
	 * @param seqRevId
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check the RATES availability in system
	 */
	@When("^Availability of RATES for the plan \"([^\"]*)\" and seqRevId \"([^\"]*)\" to calculate Invoice amount$")
	public void checkRatesAvailablity(String plan, String seqRevId) throws ClassNotFoundException, IOException, SQLException{
		boolean checkStatus = false;
		InvoiceCommon common = new InvoiceCommon();
		String companyCode = common.getCompanyCode(plan);
		try {
			checkStatus = common.checkRates(plan, seqRevId);
			if (!checkStatus) {
				Assert.fail(String.format(InvoiceConstants.NO_RATES_AVAILABLE,companyCode,seqRevId));
			}
		} catch (Exception e) {
			Assert.fail(String.format(InvoiceConstants.NO_RATES_AVAILABLE,companyCode,seqRevId)+e.getMessage());
		}
	}
	
	/**
	 * TC038A
	 * @param plan
	 * @param seqRevId
	 * Method to validate Invoice data
	 * @throws SQLException 
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 * Method to validate Invoice Data
	 */
	@Then("^Verification of Invoice amount and Plan codes against the RATES for plan \"([^\"]*)\" seqRevId \"([^\"]*)\"$")
	public void validationOfInvoiceData(String plan, String seqRevId) throws ClassNotFoundException, IOException, SQLException{
		InvoiceCommon common = new InvoiceCommon();
		StringBuffer InvoiceDetailIds = new StringBuffer();
		String proration = common.getProrationData(plan, seqRevId);
		try {
			if(proration.isEmpty()){
				Assert.fail(String.format(InvoiceConstants.NO_PRORATION_DATA, plan, seqRevId));
			}
			boolean compositeInd = common.ifComposite(plan, seqRevId);
			InvoiceDetailIds = common.validateInvoiceData(plan, seqRevId, proration, compositeInd);
			if (!InvoiceDetailIds.toString().isEmpty()) {
				Assert.fail(String.format(InvoiceConstants.INVOICE_VALIDATION_FAILED, plan, seqRevId, InvoiceDetailIds));
			}
		} catch (Exception e) {
			Assert.fail(String.format(InvoiceConstants.INVOICE_VALIDATION_FAILED, plan, seqRevId, InvoiceDetailIds)+e.getMessage());
		}
	}
	
	/**
	 * TC039
	 * @param plan
	 * @param seqRevId
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check DMI error presence
	 */
	@When("^If Invoice Error DMI 110 available in INVOICE Details for the plan \"([^\"]*)\"$")
	public void checkDMIpresence(String plan) throws ClassNotFoundException, IOException, SQLException{
		boolean checkStatus = false;
		InvoiceCommon common = new InvoiceCommon();
		try {
			checkStatus = common.checkDMIPresence(plan);
			if (!checkStatus) {
				Assert.fail(String.format(InvoiceConstants.NO_DMI_RECORDS, plan));
			}
		} catch (Exception e) {
			Assert.fail(String.format(InvoiceConstants.NO_DMI_RECORDS, plan)+e.getMessage());
		}
	}
	
	/**
	 * TC039
	 * @param plan
	 * @param seqRevId
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to verify the DMI results in Invoice records
	 */
	@Then("^Verify such records persisited due to duplicate MEMBER KEY for the plan \"([^\"]*)\" and seqRevId \"([^\"]*)\"$")
	public void verifyDMIresult(String plan, String seqRevId) throws ClassNotFoundException, IOException, SQLException {
		boolean checkStatus = false;
		InvoiceCommon common = new InvoiceCommon();
		try {
			String memberKey = common.getMemberKey(plan, seqRevId);
			if (!memberKey.isEmpty() || null != memberKey) {
				checkStatus = common.verifyDMIresult(plan, memberKey);
			} 
			if (!checkStatus) {
				Assert.fail(String.format(InvoiceConstants.FALSE_DMI, plan));
			}
		} catch (Exception e) {
			Assert.fail(String.format(InvoiceConstants.FALSE_DMI, plan)+e.getMessage());
		}
	}
	
	/**
	 * TC040
	 * @param plan
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check IKM error presence in Invoice records
	 */
	@When("^If Invoice Error IKM 114 available in INVOICE Details for the plan \"([^\"]*)\"$")
	public void checkIKMpresence(String plan) throws ClassNotFoundException, IOException, SQLException{
		boolean checkStatus = false;
		InvoiceCommon common = new InvoiceCommon();
		try {
			checkStatus = common.checkIKMPresence(plan);
			if (!checkStatus) {
				Assert.fail(String.format(InvoiceConstants.NO_DMI_RECORDS, plan));
			}
		} catch (Exception e) {
			Assert.fail(String.format(InvoiceConstants.NO_DMI_RECORDS, plan)+e.getMessage());
		}
	}
	
	/**
	 * TC040
	 * @param plan
	 * @param seqRevId
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to verify the IKM results in Invoice records
	 */
	@Then("^Verify such records persisited due to INVOICE PARAMETER missing for member for the plan \"([^\"]*)\" and seqRevId \"([^\"]*)\"$")
	public void verifyIKMresult(String plan, String seqRevId) throws ClassNotFoundException, IOException, SQLException {
		boolean checkStatus = false;
		InvoiceCommon common = new InvoiceCommon();
		String seqMemberId = "";
		String invoiceParam;
		try {
			seqMemberId = common.getseqMemIdForInvoiceError(plan, seqRevId, "114");
			invoiceParam = common.getInvoiceParamy(plan, seqRevId);
			if (!invoiceParam.isEmpty() || null != invoiceParam) {
				checkStatus = common.verifyIKMresult(plan, invoiceParam, seqMemberId);
			} 
			if (!checkStatus) {
				Assert.fail(String.format(InvoiceConstants.FALSE_IKM, plan, seqMemberId));
			}
		} catch (Exception e) {
			Assert.fail(String.format(InvoiceConstants.FALSE_IKM, plan, seqMemberId)+e.getMessage());
		}
	}
	
	/**
	 * TC041
	 * @param plan
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check MKM error presence in Invoice records
	 */
	@When("^If Invoice Error MKM 115 available in INVOICE Details for the plan \"([^\"]*)\"$")
	public void checkMKMpresence(String plan) throws ClassNotFoundException, IOException, SQLException{
		boolean checkStatus = false;
		InvoiceCommon common = new InvoiceCommon();
		try {
			checkStatus = common.checkMKMPresence(plan);
			if (!checkStatus) {
				Assert.fail(String.format(InvoiceConstants.NO_MKM_RECORDS, plan));
			}
		} catch (Exception e) {
			Assert.fail(String.format(InvoiceConstants.NO_MKM_RECORDS, plan)+e.getMessage());
		}
	}
	
	/**
	 * TC041
	 * @param plan
	 * @param seqRevId
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to verify the MKM results in Invoice records
	 */
	@Then("^Verify such records persisited due to MEMBER KEY missing for member for the plan \"([^\"]*)\" and seqRevId \"([^\"]*)\"$")
	public void verifyMKMresult(String plan, String seqRevId) throws ClassNotFoundException, IOException, SQLException {
		boolean checkStatus = false;
		InvoiceCommon common = new InvoiceCommon();
		String seqMemberId = common.getseqMemIdForInvoiceError(plan, seqRevId, "115");
		String memKey = common.getMemberKey(plan, seqRevId);
		try {
			if (!memKey.isEmpty() || null != memKey) {
				checkStatus = common.verifyMKMresult(plan, memKey, seqMemberId);
			} 
			if (!checkStatus) {
				Assert.fail(String.format(InvoiceConstants.FALSE_MKM, plan, seqMemberId));
			}
		} catch (Exception e) {
			Assert.fail(String.format(InvoiceConstants.FALSE_MKM, plan, seqMemberId)+e.getMessage());
		}
	}
	
	/**
	 * TC041
	 * @param plan
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check NRF error presence in Invoice records
	 */
	@When("^If Invoice Error NRF 100 available in INVOICE Details for the plan \"([^\"]*)\"$")
	public void checkNRFpresence(String plan) throws ClassNotFoundException, IOException, SQLException{
		boolean checkStatus = false;
		InvoiceCommon common = new InvoiceCommon();
		checkStatus = common.checkNRFPresence(plan);
		try {
			if (!checkStatus) {
				Assert.fail(String.format(InvoiceConstants.NO_NRF_RECORDS, plan));
			}
		} catch (Exception e) {
			Assert.fail(String.format(InvoiceConstants.NO_NRF_RECORDS, plan)+e.getMessage());
		}
	}
	
	/**
	 * TC041
	 * @param plan
	 * @param seqRevId
	 * @throws Exception 
	 * Method to verify NRF result
	 */
	@Then("^Verify such records persisited due to NO RATE FOUND for member for the plan \"([^\"]*)\" and seqRevId \"([^\"]*)\"$")
	public void verifyNRFresult(String plan, String seqRevId) throws Exception {
		String rateError = "";
		InvoiceCommon common = new InvoiceCommon();
		String seqMemberId = common.getseqMemIdForInvoiceError(plan, seqRevId, "100");
		String invoiceParam = common.getInvoiceParamy(plan, seqRevId);
		try {
			if (!invoiceParam.isEmpty() || null != invoiceParam) {
				rateError = common.verifyNRFandMRFresult(plan, seqRevId, invoiceParam, seqMemberId, "100");
			} 
			if (!rateError.equalsIgnoreCase("100")) {
				Assert.fail(String.format(InvoiceConstants.FALSE_NRF, plan, seqMemberId));
			}
		} catch (Exception e) {
			Assert.fail(String.format(InvoiceConstants.FALSE_NRF, plan, seqMemberId)+e.getMessage());
		}
	}
	
	/**
	 * TC042
	 * @param plan
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check MRF error presence in Invoice records
	 */
	@When("^If Invoice Error MRF 101 available in INVOICE Details for the plan \"([^\"]*)\"$")
	public void checkMRFpresence(String plan) throws ClassNotFoundException, IOException, SQLException{
		boolean checkStatus = false;
		InvoiceCommon common = new InvoiceCommon();
		try {
			checkStatus = common.checkMRFPresence(plan);
			if (!checkStatus) {
				Assert.fail(String.format(InvoiceConstants.NO_MRF_RECORDS, plan));
			}
		} catch (Exception e) {
			Assert.fail(String.format(InvoiceConstants.NO_MRF_RECORDS, plan)+e.getMessage());
		}
	}
	
	/**
	 * TC042
	 * @param plan
	 * @param seqRevId
	 * @throws Exception 
	 */
	@Then("^Verify such records persisited due to MULTIPLE RATE FOUND for member for the plan \"([^\"]*)\" and seqRevId \"([^\"]*)\"$")
	public void verifyMRFresult(String plan, String seqRevId) throws Exception {
		String rateError = "";
		InvoiceCommon common = new InvoiceCommon();
		String seqMemberId = common.getseqMemIdForInvoiceError(plan, seqRevId, "101");
		String invoiceParam = common.getInvoiceParamy(plan, seqRevId);
		try {
			if (!invoiceParam.isEmpty() || null != invoiceParam) {
				rateError = common.verifyNRFandMRFresult(plan, seqRevId, invoiceParam, seqMemberId, "101");
			} 
			if (!rateError.equalsIgnoreCase("101")) {
				Assert.fail(String.format(InvoiceConstants.FALSE_MRF, plan, seqMemberId));
			}
		} catch (Exception e) {
			Assert.fail(String.format(InvoiceConstants.FALSE_MRF, plan, seqMemberId)+e.getMessage());
		}
	}

}
