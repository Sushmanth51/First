package com.optum.ram.invoice;

public class InvoiceDBqueries {
	
	public static final String CHECK_MEM_DATA = "SELECT 1 FROM RAM_MEMBER_DEMOGRAPHICS WHERE PLAN_NAME = '%s' AND rownum =1 INTERSECT SELECT 1 FROM RAM_MEMBER_ELIGIBILITY WHERE PLAN_NAME = '%s' AND ELIG_STATUS = 'Y' AND ROWNUM =1";
	
	public static final String CHECK_INVOICE_HEADER_DATA = "select COUNT(1) from RAM_INVOICE_HEADER where SEQ_REVENUE_ID = '%s' AND INVOICE_DATE IS NOT NULL";
	
	public static final String VALIDATE_HEADER_DATA = "SELECT COUNT(1) FROM (SELECT H.INVOICE_DATE, H.SEQ_INVOICE_HEADER_ID, H.SEQ_REVENUE_ID, "
			+ "SUM(H.TOTAL_INVOICE_AMOUNT) TOTAL_INVOICE_AMOUNT FROM RAM_INVOICE_HEADER H WHERE H.SEQ_REVENUE_ID = '%s' "
			+ "GROUP BY H.INVOICE_DATE, H.seq_invoice_header_id, H.SEQ_REVENUE_ID) H, (SELECT D.REVENUE_START_DATE, D.SEQ_INVOICE_HEADER_ID, "
			+ "D.SEQ_REVENUE_ID, SUM(D.INVOICE_AMOUNT) INVOICE_AMOUNT FROM RAM_INVOICE_DETAIL D WHERE D.SEQ_REVENUE_ID = '%s' "
			+ "AND D.PLAN_NAME  = '%s' GROUP BY D.REVENUE_START_DATE, D.SEQ_INVOICE_HEADER_ID, D.SEQ_REVENUE_ID )D "
			+ "WHERE H.SEQ_REVENUE_ID    = D.SEQ_REVENUE_ID AND H.INVOICE_DATE          = D.REVENUE_START_DATE AND "
			+ "H.SEQ_INVOICE_HEADER_ID = D.SEQ_INVOICE_HEADER_ID AND H.TOTAL_INVOICE_AMOUNT <> D.INVOICE_AMOUNT";
	
	public static final String CHECK_RATES_AVAILABILITY = "SELECT COUNT(1) FROM RAM_RATE_MATRIX WHERE COMPANY_CODE = '%s' AND SEQ_REVENUE_ID = '%s' AND STATUS <> 'V'";
	
	public static final String GET_COMPANY_CODE = "SELECT COMPANY_CODE FROM RAM_REVENUE_STREAM_HISTORY WHERE PLAN_NAME = '%s' AND (TERM_DATE IS NULL OR TERM_DATE > SYSDATE) AND ROWNUM =1";

	public static final String GET_PRORATION = "SELECT rsh.PRORATION FROM ram_revenue_stream_history rsh,  "
			+ "RAM_REVENUE_STREAM RS WHERE rsh.seq_revenue_id = '%s' AND RS.SEQ_REVENUE_ID    = RSH.SEQ_REVENUE_ID AND "
			+ "rsh.plan_name  = '%s' AND TRUNC(sysdate, 'DD') "
			+ "BETWEEN RSH.EFFECTIVE_DATE AND NVL(rsh.term_date, to_date('12/31/9999', 'MM/DD/YYYY'))";
	
	/*public static final String CALC_INVOICE_NON_PRORATED = "select SEQ_INVOICE_DETAIL_ID from  (select RINV.SEQ_INVOICE_DETAIL_ID,    "
			+ "RINV.INVOICE_AMOUNT ACTUAL_INVOICE,    NVL(    (select RATE    from RAM_RATE_MATRIX RRM    "
			+ "where RRM.SEQ_RATE_ID  = RINV.SEQ_RATE_ID    and RRM.SEQ_REVENUE_ID = RINV.SEQ_REVENUE_ID ), 0) CALC_INVOICE  "
			+ "from RAM_INVOICE_DETAIL RINV  where RINV.SEQ_RATE_ID is not null  and RINV.PLAN_NAME      = '%s'  "
			+ "and RINV.SEQ_REVENUE_ID = '%s'  ) where ACTUAL_INVOICE <> CALC_INVOICE";*/

	public static final String GET_PRORATION_FORMULA = "SELECT nvl(rsh.proration_formula,'YEAR') FROM ram_revenue_stream_history rsh,  "
			+ "RAM_REVENUE_STREAM RS WHERE rsh.seq_revenue_id = '%s' AND RS.SEQ_REVENUE_ID    = RSH.SEQ_REVENUE_ID AND "
			+ "rsh.plan_name  = '%s' AND TRUNC(sysdate, 'DD') "
			+ "BETWEEN RSH.EFFECTIVE_DATE AND NVL(rsh.term_date, to_date('12/31/9999', 'MM/DD/YYYY'))";

	/*public static final String CALC_INVOICE_PRORATED = "select SEQ_INVOICE_DETAIL_ID from( SELECT RINV.SEQ_INVOICE_DETAIL_ID, "
			+ "RINV.INVOICE_AMOUNT ACTUAL_INVOICE,  NVL( (SELECT  case  WHEN '%s' = 'YEAR' THEN NVL((RATE * (RINV.ACTIVE_DAYS * 12 / 365)), 0) "
			+ "ELSE NVL((RATE * (RINV.ACTIVE_DAYS / extract(DAY FROM LAST_DAY(RINV.REVENUE_START_DATE)))), 0) END RATE  "
			+ "FROM RAM_RATE_MATRIX RRM WHERE RRM.SEQ_RATE_ID  = RINV.SEQ_RATE_ID AND RRM.SEQ_REVENUE_ID = RINV.SEQ_REVENUE_ID), 0) CALC_INVOICE "
			+ "FROM RAM_INVOICE_DETAIL RINV where RINV.SEQ_RATE_ID is not null AND RINV.PLAN_NAME      = '%s' "
			+ "AND RINV.SEQ_REVENUE_ID = '%s') WHERE ACTUAL_INVOICE <> CALC_INVOICE";*/

	public static final String IF_COMPOSITE = "SELECT COUNT(1) from RAM_REVENUE_STREAM where PLAN_NAME = '%s' and BASE_SEQ_REVENUE_ID = '%s' AND seq_revenue_id != '%s'";
	
	public static final String GET_INVOICE_PARAM = "SELECT rsh.invoice_parameters FROM ram_revenue_stream_history rsh,  "
			+ "RAM_REVENUE_STREAM RS WHERE rsh.seq_revenue_id = '%s' AND RS.SEQ_REVENUE_ID    = RSH.SEQ_REVENUE_ID AND "
			+ "rsh.plan_name  = '%s' AND TRUNC(sysdate, 'DD') "
			+ "BETWEEN RSH.EFFECTIVE_DATE AND NVL(rsh.term_date, to_date('12/31/9999', 'MM/DD/YYYY'))";
	
	
	public static final String CALC_INVOICE_1 = "SELECT SEQ_INVOICE_DETAIL_ID "
			+ "FROM "
			+ "( ";
	
	public static final String CALC_INVOICE_WITH =  " WITH ELIG AS "
			+ "(SELECT DET.PLAN_NAME, "
			+ "DET.SEQ_INVOICE_DETAIL_ID, "
			+ "DEMO.GENDER, "
			+ "CASE "
			+ "WHEN DEMO.PLAN_NAME = 'UHGMI' "
			+ "THEN "
			+ "CASE "
			+ "WHEN SIGN(DET.revenue_start_date + 14 - date_of_birth) = -1 "
			+ "THEN 0 "
			+ "WHEN MONTHS_BETWEEN(DET.REVENUE_START_DATE             + 14, DATE_OF_BIRTH) >= 12 "
			+ "THEN FLOOR(MONTHS_BETWEEN(DET.REVENUE_START_DATE       + 14, DATE_OF_BIRTH) / 12) "
			+ " WHEN MONTHS_BETWEEN(DET.REVENUE_START_DATE             + 14, DATE_OF_BIRTH) < 12 "
			+ "THEN ROUND(TRUNC(months_between(DET.revenue_start_date + 14, date_of_birth)) / 12, 2) "
			+ "END "
			+ "WHEN INSTR('%s', 'AGE_MONTHS') > 0 "
			+ "THEN ROUND(TRUNC(MONTHS_BETWEEN(DET.REVENUE_START_DATE, TRUNC(DATE_OF_BIRTH, 'mm'))) / 12, 2) "
			+ "ELSE TRUNC(MONTHS_BETWEEN(DET.REVENUE_START_DATE,DATE_OF_BIRTH)                      /12) "
			+ "END AGE, "
			+ "elig.plan_code "
			+ "FROM ram_member_demographics DEMO, "
			+ "RAM_INVOICE_DETAIL DET, " 
			+ "ram_member_eligibility ELIG "
			+ "WHERE DET.SEQ_MEMBER_ID = DEMO.SEQ_MEMBER_ID "
			+ "AND DET.PLAN_NAME       = DEMO.PLAN_NAME "
			+ "AND ELIG.SEQ_MEMBER_ID  = DEMO.SEQ_MEMBER_ID "
			+ "AND ELIG.PLAN_NAME      = DEMO.PLAN_NAME "
			+ "AND ELIG.ELIG_STATUS    = 'Y' " 
			+ "AND TRUNC(DET.REVENUE_START_DATE,'MM') BETWEEN TRUNC(ELIG.EFFECTIVE_DATE,'MM') AND LAST_DAY(ELIG.TERM_DATE) "
			+ "AND (DEMO.term_date   IS NULL "
			+ "OR DEMO.term_date     >= TRUNC(sysdate)) "
			+ "AND DEMO.PLAN_NAME     = '%s' "
			+ "AND DET.SEQ_REVENUE_ID = '%s' "
			+ "AND DET.INVOICE_STATUS = 'Y' "
			+ ") ";
	
			public static final String CALC_INVOICE_2 = " SELECT rid.SEQ_INVOICE_DETAIL_ID, "
			+ "(SELECT rm.rate "
			+ "FROM ram_rate_matrix rm "
			+ "WHERE rm.seq_revenue_id = rid.seq_revenue_id "
			+ "AND rm.effective_date  <= rid.revenue_start_date "
			+ "AND RM.TERM_DATE       >= RID.REVENUE_END_DATE "
			+ "AND RM.STATUS           = 'Y' "
			+ "AND rm.plan_code        = ELIG.plan_code ";
			
			public static final String CALC_INVOICE_PRORATED_2 = " SELECT rid.SEQ_INVOICE_DETAIL_ID, "
					+ "(SELECT "
					+ "CASE WHEN '%s' = 'YEAR' "
					+ "THEN NVL((rm.rate * (rid.ACTIVE_DAYS * 12 / 365)), 0) "
					+ "else NVL((rm.rate * (rid.ACTIVE_DAYS / extract(day from LAST_DAY(rid.REVENUE_START_DATE)))), 0) "
					+ "END "
					+ "FROM ram_rate_matrix rm "
					+ "WHERE rm.seq_revenue_id = rid.seq_revenue_id "
					+ "AND rm.effective_date  <= rid.revenue_start_date "
					+ "AND RM.TERM_DATE       >= RID.REVENUE_END_DATE "
					+ "AND RM.STATUS           = 'Y' "
					+ "AND rm.plan_code        = ELIG.plan_code ";
	
	
	public static final String CALC_INVOICE_3 = " AND 1 = "
			+ "(SELECT COUNT(1) "
			+ "FROM ram_rate_matrix rrm "
			+ "WHERE rrm.status        = 'Y' "
			+ "AND rrm.seq_revenue_id  = rid.seq_revenue_id "
			+ "AND RRM.EFFECTIVE_DATE <= RID.REVENUE_START_DATE "
			+ "AND rrm.term_date      >= rid.revenue_end_date "
			+ "AND rrm.plan_code       = ELIG.plan_code ";
	
	public static final String CALC_INVOICE_4 = ") "
			+ ") AS CALC_INVOICE, "
			+ " RID.INVOICE_AMOUNT ACTUAL_INVOICE "
			+ "FROM RAM_INVOICE_DETAIL RID, "
			+ "ELIG ELIG "
			+ "WHERE RID.PLAN_NAME           = ELIG.PLAN_NAME "
			+ "AND RID.SEQ_INVOICE_DETAIL_ID = ELIG.SEQ_INVOICE_DETAIL_ID "
			+ "AND RID.PLAN_NAME             = '%s' "
			+ "AND RID.SEQ_REVENUE_ID        = '%s' "
			+ "AND RID.INVOICE_STATUS = 'Y' "
			+ ") "
			+ "WHERE ACTUAL_INVOICE <> CALC_INVOICE ";
	
	public static final String GET_SUB_REV_TYPES = "SELECT seq_revenue_id from RAM_REVENUE_STREAM where PLAN_NAME = '%s' and BASE_SEQ_REVENUE_ID = '%s' AND seq_revenue_id != '%s'";

	public static final String GET_GROUP_ID = "select LISTAGG(ELIG_PLAN_NAME,',') within group (order by ELIG_PLAN_NAME) ELIG_PLAN_NAME FROM RAM_PLAN_NAME_XWALK where PLAN_NAME = '%s'";
	
	public static final String GET_MEMBER_KEY = "SELECT MEMBER_KEY FROM ram_revenue_stream_history rsh,  "
			+ "RAM_REVENUE_STREAM RS WHERE rsh.seq_revenue_id = '%s' AND RS.SEQ_REVENUE_ID    = RSH.SEQ_REVENUE_ID AND "
			+ "rsh.plan_name  = '%s' AND TRUNC(sysdate, 'DD') "
			+ "BETWEEN RSH.EFFECTIVE_DATE AND NVL(rsh.term_date, to_date('12/31/9999', 'MM/DD/YYYY'))";

	public static final String CHECK_INVOICE_ERROR = "SELECT COUNT(1) FROM RAM_INVOICE_DETAIL WHERE PLAN_NAME = '%s' AND INVOICE_STATUS = 'E' AND ERROR_CODE = '%s'";
	
	public static final String CHECK_DMI = "SELECT COUNT(1)	FROM (SELECT %s FROM RAM_MEMBER_DEMOGRAPHICS WHERE plan_name = '%s' GROUP BY %s HAVING COUNT(SUBSCRIBER_ID) >1)";
	
	public static final String GET_SEQ_MEM_ID_IKM = "select SEQ_MEMBER_ID from RAM_INVOICE_DETAIL where plan_name = '%s' and SEQ_REVENUE_ID = '%s' and ERROR_CODE = '%s' AND ROWNUM = 1";
	
	public static final String CHECK_ELIG_IKM = "select COUNT(1) from RAM_MEMBER_ELIGIBILITY where plan_name = '%s' and SEQ_MEMBER_ID = '%s' AND %s IS NULL";
	
	public static final String CHECK_DEMO_IKM = "select count(1) from RAM_MEMBER_DEMOGRAPHICS where plan_name = '%s' AND SEQ_MEMBER_ID = '%s' AND %s IS NULL";
	
	public static final String CHECK_MKM = "select count(1) from RAM_MEMBER_DEMOGRAPHICS where plan_name = '%s' AND SEQ_MEMBER_ID = '%s' AND (%s IS NULL OR UPPER(%s) = 'UNKNOWN')";
	
	public static final String CALC_NRF_MRF1 = "SELECT DECODE ( "
			+ "(SELECT COUNT(1) FROM ram_rate_matrix rrm WHERE rrm.status = 'Y' "
			+ "AND rrm.seq_revenue_id                                     = rid.seq_revenue_id "
			+ "AND rrm.effective_date                                    <= rid.revenue_start_date "
			+ "AND RRM.TERM_DATE                                         >= RID.REVENUE_END_DATE  ";
	
	public static final String CALC_NRF_MRF2 = " ) , 0,'100', 1, '0', '101' ) AS ERROR_CODE from RAM_INVOICE_DETAIL RID "
			+ "where SEQ_REVENUE_ID = '%s' and PLAN_NAME        = '%s' and SEQ_MEMBER_ID = '%s' "
			+ "and ERROR_CODE      is not null and rownum =1 ";
	
	public static final String GET_ELIG_NRF_MRF = "SELECT  DEMO.GENDER,   CASE   WHEN DEMO.PLAN_NAME = 'UHGMI' "
			+ "  THEN    CASE     WHEN SIGN(DET.revenue_start_date + 14 - date_of_birth) = -1 "
			+ "   THEN 0   WHEN MONTHS_BETWEEN(DET.REVENUE_START_DATE             + 14, DATE_OF_BIRTH) >= 12 "
			+ " THEN FLOOR(MONTHS_BETWEEN(DET.REVENUE_START_DATE       + 14, DATE_OF_BIRTH) / 12) "
			+ " WHEN MONTHS_BETWEEN(DET.REVENUE_START_DATE             + 14, DATE_OF_BIRTH) < 12 "
			+ " THEN ROUND(TRUNC(months_between(DET.revenue_start_date + 14, date_of_birth)) / 12, 2)  END "
			+ " WHEN INSTR('%s', 'AGE_MONTHS') > 0 "
			+ " THEN ROUND(TRUNC(MONTHS_BETWEEN(DET.REVENUE_START_DATE, TRUNC(DATE_OF_BIRTH, 'mm'))) / 12, 2) "
			+ " ELSE TRUNC(MONTHS_BETWEEN(DET.REVENUE_START_DATE,DATE_OF_BIRTH)                      /12) "
			+ " END AGE,  ELIG.PLAN_CODE,  ELIG.COUNTY_CODE  FROM ram_member_demographics DEMO, "
			+ "  RAM_INVOICE_DETAIL DET,  ram_member_eligibility ELIG  "
			+ " WHERE DET.SEQ_MEMBER_ID = DEMO.SEQ_MEMBER_ID  AND DET.PLAN_NAME       = DEMO.PLAN_NAME "
			+ " AND ELIG.SEQ_MEMBER_ID  = DEMO.SEQ_MEMBER_ID  AND ELIG.PLAN_NAME      = DEMO.PLAN_NAME "
			+ " AND ELIG.ELIG_STATUS    = 'Y' "
			+ " AND TRUNC(DET.REVENUE_START_DATE,'MM') BETWEEN TRUNC(ELIG.EFFECTIVE_DATE,'MM') AND LAST_DAY(ELIG.TERM_DATE) "
			+ " AND (DEMO.term_date   IS NULL  or DEMO.TERM_DATE     >= TRUNC(sysdate)) "
			+ " and DEMO.PLAN_NAME     = '%s'   and DET.SEQ_REVENUE_ID = '%s' "
			+ " and DET.SEQ_MEMBER_ID = '%s'  and DET.ERROR_CODE = '%s' "
			+ " and DET.INVOICE_STATUS = 'E'   AND ROWNUM =1 ";
	/*SELECT SEQ_INVOICE_DETAIL_ID
	FROM
	  (SELECT rid.SEQ_INVOICE_DETAIL_ID,
	    (SELECT rm.rate
	    FROM ram_rate_matrix rm
	    WHERE rm.seq_revenue_id = rid.seq_revenue_id
	    AND rm.effective_date  <= rid.revenue_start_date
	    AND RM.TERM_DATE       >= RID.REVENUE_END_DATE
	    and RM.STATUS           = 'Y'
	      and rm.plan_code = rid.plan_code and (rm.gender = rid.gender or rm.gender = 'B') and rid.age between nvl(rm.age_from, 500) and nvl(rm.age_to, 500)
	    AND 1 =
	      (SELECT COUNT(1)
	      FROM ram_rate_matrix rrm
	      WHERE rrm.status        = 'Y'
	      AND rrm.seq_revenue_id  = rid.seq_revenue_id
	      AND RRM.EFFECTIVE_DATE <= RID.REVENUE_START_DATE
	      AND rrm.term_date      >= rid.revenue_end_date
	        and rrm.plan_code = rid.plan_code and (rrm.gender = rid.gender or rrm.gender = 'B') and rid.age between nvl(rrm.age_from, 500) and nvl(rrm.age_to, 500)
	      )
	    ) AS CALC_INVOICE,
	    rid.INVOICE_AMOUNT ACTUAL_INVOICE
	  FROM RAM_INVOICE_DETAIL RID
	  WHERE PLAN_NAME    = :G_PLAN_NAME
	  AND seq_revenue_id = :v_revenue_id
	  )
	WHERE ACTUAL_INVOICE <> CALC_INVOICE;*/

	
	
	/*SELECT SEQ_INVOICE_DETAIL_ID
FROM
  ( WITH ELIG AS
  (SELECT DET.PLAN_NAME,
    DET.SEQ_INVOICE_DETAIL_ID,
    DEMO.GENDER,
    CASE
      WHEN DEMO.PLAN_NAME = 'UHGMI'
      THEN
        CASE
          WHEN SIGN(DET.revenue_start_date + 14 - date_of_birth) = -1
          THEN 0
          WHEN MONTHS_BETWEEN(DET.REVENUE_START_DATE             + 14, DATE_OF_BIRTH) >= 12
          THEN FLOOR(MONTHS_BETWEEN(DET.REVENUE_START_DATE       + 14, DATE_OF_BIRTH) / 12)
          WHEN MONTHS_BETWEEN(DET.REVENUE_START_DATE             + 14, DATE_OF_BIRTH) < 12
          THEN ROUND(TRUNC(months_between(DET.revenue_start_date + 14, date_of_birth)) / 12, 2)
        END
      WHEN INSTR(:G_INVOICE_PARAM, 'AGE_MONTHS') > 0
      THEN ROUND(TRUNC(MONTHS_BETWEEN(DET.REVENUE_START_DATE, TRUNC(DATE_OF_BIRTH, 'mm'))) / 12, 2)
      ELSE TRUNC(MONTHS_BETWEEN(DET.REVENUE_START_DATE,DATE_OF_BIRTH)                      /12)
    END AGE,
    elig.plan_code
  FROM ram_member_demographics DEMO,
    RAM_INVOICE_DETAIL DET,
    ram_member_eligibility ELIG
  WHERE DET.SEQ_MEMBER_ID = DEMO.SEQ_MEMBER_ID
  AND DET.PLAN_NAME       = DEMO.PLAN_NAME
  AND ELIG.SEQ_MEMBER_ID  = DEMO.SEQ_MEMBER_ID
  AND ELIG.PLAN_NAME      = DEMO.PLAN_NAME
  AND ELIG.ELIG_STATUS    = 'Y'
  AND TRUNC(DET.REVENUE_START_DATE,'MM') BETWEEN TRUNC(ELIG.EFFECTIVE_DATE,'MM') AND LAST_DAY(ELIG.TERM_DATE)
  AND (DEMO.term_date   IS NULL
  OR DEMO.term_date     >= TRUNC(sysdate))
  AND DEMO.PLAN_NAME     = :G_PLAN_NAME
  AND DET.SEQ_REVENUE_ID = :G_REVENUE_ID
  AND DET.INVOICE_STATUS = 'Y'
  )
SELECT rid.SEQ_INVOICE_DETAIL_ID,
  (SELECT rm.rate
  FROM ram_rate_matrix rm
  WHERE rm.seq_revenue_id = rid.seq_revenue_id
  AND rm.effective_date  <= rid.revenue_start_date
  AND RM.TERM_DATE       >= RID.REVENUE_END_DATE
  AND RM.STATUS           = 'Y'
  AND rm.plan_code        = ELIG.plan_code
  AND (rm.gender          = ELIG.gender
  OR rm.gender            = 'B')
  AND ELIG.age BETWEEN NVL(rm.age_from, 500) AND NVL(rm.age_to, 500)
  AND 1 =
    (SELECT COUNT(1)
    FROM ram_rate_matrix rrm
    WHERE rrm.status        = 'Y'
    AND rrm.seq_revenue_id  = rid.seq_revenue_id
    AND RRM.EFFECTIVE_DATE <= RID.REVENUE_START_DATE
    AND rrm.term_date      >= rid.revenue_end_date
    AND rrm.plan_code       = ELIG.plan_code
    AND (rrm.gender         = ELIG.gender
    OR rrm.gender           = 'B')
    AND ELIG.age BETWEEN NVL(rrm.age_from, 500) AND NVL(rrm.age_to, 500)
    )
  ) AS CALC_INVOICE,
  RID.INVOICE_AMOUNT ACTUAL_INVOICE
FROM RAM_INVOICE_DETAIL RID,
  ELIG ELIG
WHERE RID.PLAN_NAME           = ELIG.PLAN_NAME
AND RID.SEQ_INVOICE_DETAIL_ID = ELIG.SEQ_INVOICE_DETAIL_ID
AND RID.PLAN_NAME             = :G_PLAN_NAME
AND RID.SEQ_REVENUE_ID        = :G_REVENUE_ID
  )
WHERE ACTUAL_INVOICE <> CALC_INVOICE;
*/
	
}
