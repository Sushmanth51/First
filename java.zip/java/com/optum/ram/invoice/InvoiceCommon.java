package com.optum.ram.invoice;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mvel2.sh.Main;

import com.optum.facets.atdd.common.utils.DatabaseProcessor;
import com.optum.ram.atdd.common.utils.CSPCommonTestBase;
import com.optum.ram.atdd.common.utils.CSPPropertyReader;
import com.optum.ram.atdd.common.utils.RAMCommonDBQuires;
import com.optum.ram.atdd.common.utils.UnixUtilityHelper;

public class InvoiceCommon extends CSPCommonTestBase{

	private static String SPACE = " ";
	
	/**
	 * @param plan
	 * @param revId
	 * @param seqRevId
	 * @return Reusable method to trigger Invoice job
	 */
	public boolean triggerInvoiceJob(String plan, String revId, String seqRevId) {
		UnixUtilityHelper unixUtilObj;
		boolean jobStatus = false;
		try {
			unixUtilObj = new UnixUtilityHelper();
			jobStatus = unixUtilObj.execute_unix_job_jsch(
					CSPPropertyReader.getInvoiceJob() + SPACE + plan + SPACE + revId + SPACE + seqRevId,
					CSPPropertyReader.getUnixServer(), CSPPropertyReader.getUnixUsername(),
					CSPPropertyReader.getUnixPassword());
			System.out.println(InvoiceConstants.JOB_FEATURE_STATUS + jobStatus);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jobStatus;

	}
	
	/**
	 * @param plan
	 * @return boolean
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * Method to check whether Membership info is available or not
	 */
	public boolean checkMemberDataPresence(String plan) throws SQLException, ClassNotFoundException, IOException {
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		return qry.booleanForString(String.format(InvoiceDBqueries.CHECK_MEM_DATA, plan, plan));
	}

	/**
	 * @param seqRevId
	 * @return boolean
	 * Method to check the presence of INVOICE HEADER data
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public boolean verifyHeaderInfoPresence(String seqRevId) throws ClassNotFoundException, IOException, SQLException {	
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		return qry.booleanForString(String.format(InvoiceDBqueries.CHECK_INVOICE_HEADER_DATA, seqRevId));
	}
	
	/**
	 * @param plan
	 * @param seqRevId
	 * @return boolean
	 * Method to validate the presence of INVOICE HEADER parent records w.r.t DETAIL records
	 * @throws SQLException 
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	public boolean validateHeaderData(String plan, String seqRevId) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		if(qry.booleanForString(String.format(InvoiceDBqueries.VALIDATE_HEADER_DATA, seqRevId, seqRevId, plan))){
			return false;
		}else{
			return true;
		}
	}
	
	/**
	 * @param plan
	 * @param seqRevId
	 * @return boolean
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check the RATES availability in system
	 */
	public boolean checkRates(String plan, String seqRevId) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		return qry.booleanForString(String.format(InvoiceDBqueries.CHECK_RATES_AVAILABILITY, plan, seqRevId));
	}

	/**InvoiceDBqueries
	 * @param plan
	 * @return String
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLExceptionInvoiceDBqueries
	 * Method to return Company code for the Plan
	 */
	public String getCompanyCode(String plan) throws ClassNotFoundException, IOException, SQLException {	
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		return qry.getSingleResult(String.format(InvoiceDBqueries.GET_COMPANY_CODE, plan));			
	}
	

	/**
	 * @param plan
	 * @param seqRevId
	 * @return String
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to get Proration data for the plan
	 */
	public String getProrationData(String plan, String seqRevId) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		return qry.getSingleResult(String.format(InvoiceDBqueries.GET_PRORATION, seqRevId, plan));		
	}
	
	/**
	 * @param plan
	 * @param seqRevId
	 * @param proration
	 * @param compositeInd 
	 * @return StringBuffer
	 * Method to validate Invoice Data
	 * @throws SQLException 
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	public StringBuffer validateInvoiceData(String plan, String seqRevId, String proration, boolean compositeInd)
			throws SQLException, ClassNotFoundException, IOException {

		String invoiceParam;
		StringBuffer InvoiceDetailIds = new StringBuffer();
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		invoiceParam = qry.getSingleResult(String.format(InvoiceDBqueries.GET_INVOICE_PARAM, seqRevId, plan));
		if (proration.equals("N")) {
			if (!compositeInd) {
				InvoiceDetailIds = checkInvoiceforNONProratedPlan(invoiceParam, plan, seqRevId);
			} else {
				List<String> subRevTypes = new ArrayList<String>();	
				subRevTypes = getSubRevTypes(plan, seqRevId);
				subRevTypes.add(seqRevId);
				
				for(String seqRevIdElement : subRevTypes){
					InvoiceDetailIds = checkInvoiceforNONProratedPlan(invoiceParam, plan, seqRevIdElement);
				}
			}
		} else {
			String prorationFormula = getProrationFormula(plan, seqRevId);
			if (!compositeInd) {
				InvoiceDetailIds = checkInvoiceforProratedPlan(invoiceParam, plan, seqRevId, prorationFormula);
			} else {
				List<String> subRevTypes = new ArrayList<String>();	
				subRevTypes = getSubRevTypes(plan, seqRevId);
				subRevTypes.add(seqRevId);
				
				for(String seqRevIdElement : subRevTypes){
					InvoiceDetailIds = checkInvoiceforProratedPlan(invoiceParam, plan, seqRevIdElement, prorationFormula);
				}
			}
		}
		return InvoiceDetailIds;
	}
	
	/**
	 * @param plan
	 * @param seqRevId
	 * @return List<String>
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to return sub revenue types for a plan
	 */
	private List<String> getSubRevTypes(String plan, String seqRevId) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		return qry.getSingleColumnListforQuery(String.format(InvoiceDBqueries.GET_SUB_REV_TYPES, plan, seqRevId, seqRevId));		
	}

	/**
	 * @param invoiceParam
	 * @param plan
	 * @param seqRevId
	 * @param prorationFormula
	 * @return StringBuffer
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * Method to check Invoice for proprated plans
	 */
	private StringBuffer checkInvoiceforProratedPlan(String invoiceParam, String plan, String seqRevId,
			String prorationFormula) throws SQLException, ClassNotFoundException, IOException {

		ResultSet result = null;
		StringBuffer InvoiceDetailIds = new StringBuffer();
		Statement statement = null;

		String checkInvoice = InvoiceDBqueries.CALC_INVOICE_1 + InvoiceDBqueries.CALC_INVOICE_WITH
				+ InvoiceDBqueries.CALC_INVOICE_PRORATED_2 + getRateInvoiceParamQryHelper("O", invoiceParam)
				+ InvoiceDBqueries.CALC_INVOICE_3 + getRateInvoiceParamQryHelper("I", invoiceParam)
				+ InvoiceDBqueries.CALC_INVOICE_4;
		try {
			statement = getConnection();
			result = DatabaseProcessor.executeSqlQuery(statement,
					String.format(checkInvoice, invoiceParam, plan, seqRevId, prorationFormula, plan, seqRevId));
			while (result.next()) {
				InvoiceDetailIds.append(result.getString(1)).append(",");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			InvoiceDetailIds.append(e.getMessage());
		} finally {
			statement.close();
			result.close();
		}
		return InvoiceDetailIds;
	}

	/**
	 * @param invoiceParam
	 * @param plan
	 * @param seqRevId
	 * @return StringBuffer
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check Invoice for non-proprated plans
	 */
	private StringBuffer checkInvoiceforNONProratedPlan(String invoiceParam, String plan, String seqRevId)
			throws ClassNotFoundException, IOException, SQLException {

		ResultSet result = null;
		StringBuffer InvoiceDetailIds = new StringBuffer();
		Statement statement = null;

		String checkInvoice = InvoiceDBqueries.CALC_INVOICE_1 + InvoiceDBqueries.CALC_INVOICE_WITH
				+ InvoiceDBqueries.CALC_INVOICE_2 + getRateInvoiceParamQryHelper("O", invoiceParam)
				+ InvoiceDBqueries.CALC_INVOICE_3 + getRateInvoiceParamQryHelper("I", invoiceParam)
				+ InvoiceDBqueries.CALC_INVOICE_4;
		try {
			statement = getConnection();
			result = DatabaseProcessor.executeSqlQuery(statement,
					String.format(checkInvoice, invoiceParam, plan, seqRevId, plan, seqRevId));
			while (result.next()) {
				InvoiceDetailIds.append(result.getString(1)).append(",");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			InvoiceDetailIds.append(e.getMessage());
		} finally {
			statement.close();
			result.close();
		}
		return InvoiceDetailIds;

	}

	/**
	 * @param s
	 * @param invoiceParam 
	 * @return String
	 * Method to form a Query in calculation of Invoice Amount
	 */
	private String getRateInvoiceParamQryHelper(String s, String invoiceParam) {
		StringBuffer qryHelper = new StringBuffer();
		if(s.equalsIgnoreCase("O")){
			if(invoiceParam.contains("PLAN_CODE")){
				qryHelper.append(" and rm.plan_code = ELIG.plan_code");
			}
			if(invoiceParam.contains("GENDER")){
				qryHelper.append(" and (rm.gender = ELIG.gender or rm.gender = 'B')");
			}
			if(invoiceParam.contains("COUNTY_CODE")|| invoiceParam.contains("COUNTY")){
				qryHelper.append(" and rm.county = rid.county_code");
			}
			if(invoiceParam.contains("AGE")){
				qryHelper.append(" and ELIG.age between nvl(rm.age_from, 500) and nvl(rm.age_to, 500)");
			}
		}else{
			if(invoiceParam.contains("PLAN_CODE")){
				qryHelper.append(" and rrm.plan_code = ELIG.plan_code");
			}
			if(invoiceParam.contains("GENDER")){
				qryHelper.append(" and (rrm.gender = ELIG.gender or rrm.gender = 'B')");
			}
			if(invoiceParam.contains("COUNTY_CODE")|| invoiceParam.contains("COUNTY")){
				qryHelper.append(" and rrm.county = rid.county_code");
			}
			if(invoiceParam.contains("AGE")){
				qryHelper.append(" and ELIG.age between nvl(rrm.age_from, 500) and nvl(rrm.age_to, 500)");
			}
		}		
		return qryHelper.toString();
	}

	/**
	 * @param plan
	 * @param seqRevId
	 * @return String
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to get the Proration formula for the plan
	 */
	public String getProrationFormula(String plan, String seqRevId) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		return qry.getSingleResult(String.format(InvoiceDBqueries.GET_PRORATION_FORMULA, seqRevId, plan));		
	}

	/**
	 * @param plan
	 * @param seqRevId
	 * @return boolean
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check if plan is Composite
	 */
	public boolean ifComposite(String plan, String seqRevId) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		return qry.booleanForString(String.format(InvoiceDBqueries.IF_COMPOSITE, plan, seqRevId, seqRevId));
	}

	/**
	 * @param plan
	 * @return String
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to get Group Id for a plan
	 */
	public String getGroupId(String plan) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		return qry.getSingleResult(String.format(InvoiceDBqueries.GET_GROUP_ID,plan));
	}

	/**
	 * @param plan
	 * @param seqRevId
	 * @return String
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to get Member key for plan and seq_rev_id
	 */
	public String getMemberKey(String plan, String seqRevId) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		return qry.getSingleResult(String.format(InvoiceDBqueries.GET_MEMBER_KEY, seqRevId, plan));
	}

	/**
	 * @param plan
	 * @param seqRevId
	 * @return String
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to get Invoice parameter for plan and seq_rev_id
	 */
	public String getInvoiceParamy(String plan, String seqRevId) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		return qry.getSingleResult(String.format(InvoiceDBqueries.GET_INVOICE_PARAM, seqRevId, plan));
	}

	/**
	 * @param plan
	 * @return boolean
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check DMI error presence in Invoice records
	 */
	public boolean checkDMIPresence(String plan) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		return qry.booleanForString(String.format(InvoiceDBqueries.CHECK_INVOICE_ERROR, plan, "110"));
	}

	/**
	 * @param plan
	 * @param memberKey
	 * @return boolean
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to validate the DMI records in Invoice details
	 */
	public boolean verifyDMIresult(String plan, String memberKey) throws ClassNotFoundException, IOException, SQLException {
		boolean chkFlag = false;
		String[] memberKeys = memberKey.split("\\|\\|");
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		for (int i = 0; i < memberKeys.length; i++) {
			if(!chkFlag && qry.booleanForString(String.format(InvoiceDBqueries.CHECK_DMI, memberKeys[i], plan, memberKeys[i]))){
				chkFlag = true;
			}
		}		
		return chkFlag;
	}

	/**
	 * @param plan
	 * @return boolean
	 * @throws SQLException 
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 *  Method to check IKM error presence in Invoice records
	 */
	public boolean checkIKMPresence(String plan) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		return qry.booleanForString(String.format(InvoiceDBqueries.CHECK_INVOICE_ERROR, plan, "114"));
	}

	
	/**
	 * @param plan
	 * @param seqMemberId 
	 * @param seqMemberId2 
	 * @param seqRevId
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to verify the IKM results in Invoice records
	 */
	public boolean verifyIKMresult(String plan, String invoiceParam, String seqMemberId) throws ClassNotFoundException, IOException, SQLException {
		boolean chkFlag = false;
		String[] invoiceParams = invoiceParam.split(",");
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		for (int i = 0; i < invoiceParams.length; i++) {

			if (invoiceParams[i].equalsIgnoreCase("PLAN_CODE") || invoiceParams[i].equalsIgnoreCase("COUNTY")) {
				if (!chkFlag && qry.booleanForString(
						String.format(InvoiceDBqueries.CHECK_ELIG_IKM, plan, seqMemberId, invoiceParams[i].equalsIgnoreCase("COUNTY")?"COUNTY_CODE":invoiceParams[i]))) {
					chkFlag = true;
				}
			} else if (invoiceParams[i].equalsIgnoreCase("GENDER") || invoiceParams[i].equalsIgnoreCase("AGE")) {
				if (!chkFlag && qry.booleanForString(
						String.format(InvoiceDBqueries.CHECK_DEMO_IKM, plan, seqMemberId, invoiceParams[i].equalsIgnoreCase("AGE")?"DATE_OF_BIRTH":invoiceParams[i]))) {
					chkFlag = true;
				}
			}
		}
		return chkFlag;
	}

	public String getseqMemIdForInvoiceError(String plan, String seqRevId, String errorCode) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		return qry.getSingleResult(String.format(InvoiceDBqueries.GET_SEQ_MEM_ID_IKM, plan, seqRevId, errorCode));
	}

	/**
	 * @param plan
	 * @return
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check MKM error presence in Invoice records
	 */
	public boolean checkMKMPresence(String plan) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		return qry.booleanForString(String.format(InvoiceDBqueries.CHECK_INVOICE_ERROR, plan, "115"));
	}

	/**
	 * @param plan
	 * @param memKey
	 * @param seqMemberId
	 * @return
	 * Method to verify the MKM results in Invoice records
	 * @throws SQLException 
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	public boolean verifyMKMresult(String plan, String memKey, String seqMemberId) throws ClassNotFoundException, IOException, SQLException {
		boolean chkFlag = false;
		String[] memberKeys = memKey.split("\\|\\|");
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		for (int i = 0; i < memberKeys.length; i++) {
			if(!chkFlag && qry.booleanForString(String.format(InvoiceDBqueries.CHECK_MKM, plan, seqMemberId, memberKeys[i], memberKeys[i]))){
			chkFlag = true;
		}}
		return chkFlag;
	}

	/**
	 * @param plan
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Method to check NRF error presence in Invoice records
	 */
	public boolean checkNRFPresence(String plan) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		return qry.booleanForString(String.format(InvoiceDBqueries.CHECK_INVOICE_ERROR, plan, "100"));
	}

	/**
	 * @param plan
	 * @param invoiceParam
	 * @param seqMemberId
	 * @param errorCode 
	 * @param seqMemberId2 
	 * @return
	 * Method to verify the NRF results in Invoice records
	 * @throws Exception 
	 */
	public String verifyNRFandMRFresult(String plan, String seqRevId, String invoiceParam, String seqMemberId, String errorCode)
			throws Exception {
		String rateError = "";
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
			rateError = qry.getSingleResult(String.format(
					InvoiceDBqueries.CALC_NRF_MRF1 + getSubQryForNRFandMRF(plan, seqRevId, invoiceParam, seqMemberId, errorCode) + InvoiceDBqueries.CALC_NRF_MRF2, seqRevId, plan, seqMemberId));
			if (!rateError.equalsIgnoreCase("0")) {
				return rateError;
			}


		return rateError;
	}

	private String getSubQryForNRFandMRF(String plan, String seqRevId, String invoiceParam, String seqMemberId, String errorCode) throws Exception {
		StringBuffer qry = new StringBuffer();
		Map<String, String> eligData = getEligDataForNRFandMRF(plan, seqRevId, seqMemberId, errorCode, invoiceParam);
		if(!eligData.isEmpty()){
			
			if(invoiceParam.contains("PLAN_CODE")){
				qry.append(" and rrm.plan_code = '"+eligData.get("PLAN_CODE")+"'");
			}
			if(invoiceParam.contains("GENDER")){
				qry.append(" and (rrm.gender = '"+eligData.get("GENDER")+"' or rrm.gender = 'B')");
			}
			if(invoiceParam.contains("COUNTY_CODE")|| invoiceParam.contains("COUNTY")){
				qry.append(" and rrm.county = '"+eligData.get("COUNTY_CODE")+"'");
			}
			if(invoiceParam.contains("AGE")){
				qry.append(" and '"+eligData.get("AGE")+"' between nvl(rrm.age_from, 500) and nvl(rrm.age_to, 500)");
			}		 
		}		
		return qry.toString();
	}

	/**
	 * @param plan
	 * @param seqRevId
	 * @param seqMemberId
	 * @param errorCode
	 * @param invoiceParam
	 * @return
	 * @throws Exception
	 * Method to get Eligibility data for NRF and MRF members
	 */
	private Map<String, String> getEligDataForNRFandMRF(String plan, String seqRevId, String seqMemberId, String errorCode, String invoiceParam) throws Exception {
		ResultSet result = null;
		Map<String, String> eligData = new HashMap<String, String>();
		Statement statement = null;
		try {
			statement = getConnection();
			result = DatabaseProcessor.executeSqlQuery(statement,
					String.format(InvoiceDBqueries.GET_ELIG_NRF_MRF, invoiceParam, plan, seqRevId, seqMemberId, errorCode));
			while (result.next()) {
				eligData.put("GENDER", result.getString("GENDER"));
				eligData.put("AGE", result.getString("AGE"));
				eligData.put("PLAN_CODE", result.getString("PLAN_CODE"));
				eligData.put("COUNTY_CODE", result.getString("COUNTY_CODE"));				
			}
		} catch (SQLException e) {
			throw new Exception(e);
		} finally {
			statement.close();
			result.close();
		}
		return eligData;
		
	}

	/**
	 * @param plan
	 * @return
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 *  Method to check MRF error presence in Invoice records
	 */
	public boolean checkMRFPresence(String plan) throws ClassNotFoundException, IOException, SQLException {
		RAMCommonDBQuires qry = new RAMCommonDBQuires();
		return qry.booleanForString(String.format(InvoiceDBqueries.CHECK_INVOICE_ERROR, plan, "101"));
	}
	
}
