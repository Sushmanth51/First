package com.optum.ram.invoice;

public class InvoiceConstants {

	public static final String INVOICE_FEATURES = "src/main/resources/invoice/feature_files";
	
	public static final String INVOICE_RESULT_FORMAT = "json:target/test_results/invoice.json";
	
	public static final String INVOICE_JOB_FAIL = "The Invoice Upload Job was failed.Please check the Server log"; 
	
	public static final String NO_INVOICE_HEADER_DATA = "There is no INVOICE HEADER data available in system for the seqRevId %s"; 
	
	public static final String IN_COMPATABLE_HEADER_DATA = "INVOICE HEADER data is not matched with the INVOICE DETAIL data for plan %s and seqRevId %s"; 
	
	public static final String NO_MEM_DATA = "No MemberShip Data available in system for the plan %s"; 
	
	public static final String JOB_FEATURE_STATUS = "The Job Status Feature file is ";
	
	public static final String NO_INVOICE_HEADER_INFO = "No header info available for INVOICE JOB"; 
	
	public static final String NO_RATES_AVAILABLE = "No Rates are avilable for the company code %s and seq_rev_id %s";

	public static final String NO_PRORATION_DATA = "No proration Data available in system for the plan %s seqRevId %s";

	public static final String INVOICE_VALIDATION_FAILED = "Invoice validation failed for the plan %s seqRevId %s - InvoiceDetailIds: %s";
	
	public static final String NO_DMI_RECORDS = "No DMI[110] records are avilable in INVOICE details for the plan %s";
	
	public static final String FALSE_DMI = "DMI[110] records are not as per the requirement for the plan %s";
	
	public static final String NO_IKM_RECORDS = "No IKM[114] records are avilable in INVOICE details for the plan %s";
	
	public static final String FALSE_IKM = "IKM[114] records are not as per the requirement for the plan %s and seq_mem_id %s";
	
	public static final String NO_MKM_RECORDS = "No MKM[115] records are avilable in INVOICE details for the plan %s";
	
	public static final String FALSE_MKM = "MKM[115] records are not as per the requirement for the plan %s and seq_mem_id %s";
	
	public static final String NO_NRF_RECORDS = "No NRF[100] records are avilable in INVOICE details for the plan %s";
	
	public static final String FALSE_NRF = "NRF[100] records are not as per the requirement for the plan %s and seq_mem_id %s";
	
	public static final String NO_MRF_RECORDS = "No MRF[101] records are avilable in INVOICE details for the plan %s";
	
	public static final String FALSE_MRF = "MRF[101] records are not as per the requirement for the plan %s and seq_mem_id %s";

}
