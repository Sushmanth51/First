package com.optum.ram.atdd.eligibility.eligibilityUpload;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

import com.optum.facets.atdd.common.utils.ConnectionHelper;
import com.optum.facets.atdd.common.utils.DatabaseProcessor;
import com.optum.facets.atdd.common.utils.FlatFileProcessor;
import com.optum.ram.atdd.common.utils.CSPCommonTestBase;
import com.optum.ram.atdd.common.utils.CSPPropertyReader;
import com.optum.ram.atdd.common.utils.DbQueryHelper;
import com.optum.ram.atdd.common.utils.DemoBean;
import com.optum.ram.atdd.common.utils.EligBean;
import com.optum.ram.atdd.common.utils.MappingBeanMembers;
import com.optum.ram.atdd.common.utils.RAMCommonDBQuires;
import com.optum.ram.atdd.common.utils.UnixUtilityHelper;
import com.optum.ram.atdd.common.utils.MembershipMocking;
import com.optum.ram.rateUpload.RateUploadDBqueries;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@CucumberOptions(features = "src/main/resources/eligibilityUpload/feature_files", format = {
		"json:target/test_results/getmemberprefrence.json" }, tags={"@DEMO"}, snippets = SnippetType.CAMELCASE)
public class EligibilityUploadRunner extends CSPCommonTestBase {
	public static String inputFileName = "";
	public static String eligiblityUploadExtractTDFilePath = "src/main/resources/eligibilityUpload/testdata/EligibilityUpload_TestData.xls";
	public static String eligiblityUploadExtractTDConfigTable = "ELIGIBILITY_UPLOAD_TEST_DATA_CONFIG_TABLE";
	public static String eligiblityUploadExtractTDActualTable = "ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE";
	static boolean JobStatus;
	static boolean eligJobStatus_WrongSequence;
	String elig_error_subscriber_id, demo_error_subscriber_id;

	@BeforeClass
	public void setUpClass()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException, IOException {
		super.setUpClass();
		try {

			ConnectionHelper.sqliteConnection = ConnectionHelper
					.openSqliteConnection("src/main/resources/eligibilityUpload/db_file/eligibilityUpload.db");
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String strcolnames = FlatFileProcessor.getExcelColumn(eligiblityUploadExtractTDFilePath, "Global");
		FlatFileProcessor.createConfigTable(eligiblityUploadExtractTDConfigTable, strcolnames);
		List myList;
		try {

			myList = FlatFileProcessor.readExcelData(eligiblityUploadExtractTDFilePath, "Global");
			FlatFileProcessor.createAndPopulateDetailsTableFromDataFile(myList, eligiblityUploadExtractTDConfigTable,
					eligiblityUploadExtractTDActualTable, 1, myList.size(), true);
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Given("^The Eligibility Upload job should be run Successfully$")
	public void theEligibilityUploadJobShouldBeRunSuccessfully() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@Given("^User should have access for the Ram Database,unix server and execute the EligbilityUpload Job$")
	public void User_should_have_access_for_the_Ram_Database_unix_server_and_execute_the_EligbilityUpload_Job()
			throws Throwable {

	}

	@When("^The Csp_Membership file should be transfered to the inbound folder for \"([^\"]*)\"$")
	public void The_Csp_Membership_file_should_be_transfered_to_the_inbound_folder(String testCaseId) throws Exception {
		Map<String, String> tdMap;
		RAMCommonDBQuires rcmnDbobj=new RAMCommonDBQuires();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		try {

			UnixUtilityHelper UnixUtilityHelperObj = new UnixUtilityHelper();
			UnixUtilityHelperObj.filetransfer(tdMap.get("PATHNAME"),
					CSPPropertyReader.getEligUpload_ServerPathInbound(), tdMap.get("FILENAME"));

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("The File was not transfered to inbound folder due to the" + e.getMessage() + "Exception");
		}
	}

	@When("^Clear out the data in the Staging tables for test case \"([^\"]*)\"$")
	public void clear_out_the_data_in_the_Staging_tables(String testCaseId) {
		Map<String, String> tdMap;
		try {
			DbQueryHelper DbQueryHelperobj = new DbQueryHelper();
			Statement statement;
			statement = getConnection();
			RAMCommonDBQuires rcmnDbobj=new RAMCommonDBQuires();
			tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
			DatabaseProcessor.executeSqlUpdate(statement,
					DbQueryHelperobj.backoutTables(tdMap.get("PLANNAME"), tdMap.get("EXTRACT")));
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("The data is not cleared in the db tables due to the" + e.getMessage() + "Exception");
		}
	}

	@When("^Triggered the EligibilityUpload shell job in the bin folder$")
	public void triggered_the_EligibilityUpload_shell_job_in_the_bin_folder() {

		try {
			UnixUtilityHelper UnixUtilityHelperObj = new UnixUtilityHelper();
			JobStatus = UnixUtilityHelperObj.execute_unix_job_jsch(CSPPropertyReader.geteligibilityUploadJob(),
					CSPPropertyReader.getUnixServer(), CSPPropertyReader.getUnixUsername(),
					CSPPropertyReader.getUnixPassword());
			System.out.println("The Job Status Feature file is" + JobStatus);
			System.out.println("The DEMO ERROR FILE IS:"+UnixUtilityHelper.demoFileError+",ELIG_ERRORFILE IS:"+UnixUtilityHelper.eligFileError+"");
		//	EligibilityUploadCommon.insertValuesIntoColumns("batch_cntrl","DEMO_ERROR_FILE,ELIG_ERROR_FILE",""+UnixUtilityHelper.demoFileError+"+,+"+UnixUtilityHelper.eligFileError+"");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("The Shell Job does not triggered properly due to the " + e.getMessage() + "Exception");
		}

	}

	@Then("^The eligibilityUpload shell job should be completed successfully without any Errors$")
	public void the_eligibilityUpload_shell_job_should_be_completed_successfully_without_any_Errors() throws Throwable {

		if (JobStatus) {
			System.out.println("The EligibilityUpload Job ran successfully and the Status is" + JobStatus);
	
		}

		else {
			Assert.fail("The Eligibility Upload Job was failed.Please check the Server log");
		}

	}

	@Given("^The Eligibility Upload process should ran successfully And the data should be loaded into the Staging tables$")
	public void the_Eligibility_Upload_process_should_ran_successfully_And_the_data_should_be_loaded_into_the_Staging_tables()
			throws Throwable {

	}

	/**
	 * Generic method to validate if extract file present of not at specified
	 * location
	 * 
	 * @param fileName
	 * @param filePath
	 * @param testCaseId
	 * @throws Throwable
	 **/
	@When("^The Eligibility Upload extract is present with filename \"([^\"]*)\" at location \"([^\"]*)\" for test case \"([^\"]*)\"$")
	public void theEligibilityUploadExtractIsPresentWithFilenameAtLocationForTestCase(String fileName, String filePath,
			String testCaseId) throws Throwable {

		// Write code here that turns the phrase above into concrete actions

		String filePathData = EligibilityUploadConstants.getResultSetForTestData(eligiblityUploadExtractTDActualTable,
				filePath, testCaseId);
		String fileNameData = EligibilityUploadConstants.getResultSetForTestData(eligiblityUploadExtractTDActualTable,
				fileName, testCaseId);                                            

		inputFileName = filePathData + "/" + fileNameData;
		File file = new File(inputFileName);
		if (!file.exists()) {
			Assert.fail("\nEligibility upload data file " + fileNameData + " does not exist at : " + filePathData + "\n"
					+ "for test case " + testCaseId);
		} else {
			System.out.println("\nEligibility upload data file " + fileNameData + " exist at : " + filePathData + "\n"
					+ "for test case " + testCaseId);
		}

	}  
	

	/**
	 * TC002
	 * 
	 * @param arg1
	 * @throws Throwable
	 **/
	@Then("^Verify Header information from the CSP Membership file should be loaded into the RAM_Membership_file_header table for test case \"([^\"]*)\"$")
	public void verifyHeaderInformationFromTheCSPMembershipFileShouldBeLoadedIntoTheRAM_Membership_file_headerTableForTestCase(
			String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		EligibilityUploadCommon EligCommonObj = new EligibilityUploadCommon();
		List<String> linesInTextFile = null;
		linesInTextFile = Files.readAllLines(Paths.get(inputFileName));

		FlatFileProcessor.createAndPopulateHeaderOrFooterTableFromDataFile(linesInTextFile,
				"ELIGIBILITY_UPLOAD_HEADER_CONFIG_TABLE", "ELIGIBILITY_UPLOAD_HEADER_ACTUAL_TABLE", (long) 1, false);
		EligCommonObj.verifyTheDataInMembershipHeaderTable("RECORDTYPE");

	}

	@When("^Validate the records count between the Membership file  and the ram Staging tables for the test case \"([^\"]*)\"$")
	public void validateCountofRecords(String testCaseId) throws Exception {
		EligibilityUploadCommon EligCommonObj = new EligibilityUploadCommon();
		EligCommonObj.getCountsFromMembershipFile(testCaseId);
		EligCommonObj.compareCounts_File_Db();
		EligCommonObj.storeFileDataCountsInSqliteDb(testCaseId);
	}

	@When("^validate the data from the membership file with database for the testcase \"([^\"]*)\"$")
	public void read_the_data_from_the_membership_file_and_store_that_data_in_the_Map(String testCaseId)
			throws Throwable {
		MappingBeanMembers mpobj = new MappingBeanMembers();
		Map<DemoBean, List<EligBean>> memberInfoGroupID = mpobj.memberShipFileMapping(testCaseId);
		mpobj.verifyRecordInFileWithDbValidation(memberInfoGroupID, testCaseId);
	}

	@When("^Validate whether the ACK file is generated in the server outbound directory or not \"([^\"]*)\"$")
	public void validationOfAckFile(String testcaseId) throws Throwable {
		UnixUtilityHelper UnixUtilityHelperObj = new UnixUtilityHelper();
		boolean flag;
		Map<String, String> tdMap;
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE",testcaseId);
		flag = UnixUtilityHelperObj.download_unix_file_jsch(tdMap.get("OUTBOUND_FILES"));

		if (flag) {
			System.out.println("The ACK file from server outbound are downloaded successfully" + true);
		} else {
			Assert.fail("The ACK files from server outbound are not Downloaded");
		}

		flag = UnixUtilityHelperObj.verifyThePresenceOfDownloadfileInlocal(tdMap.get("OUTBOUND_FILES"));
		if (flag) {
			System.out.println("The ACK files with required format are present in the local directory" + true);
		} else {
			Assert.fail("There are no ACK files in the local directory:" + false);
		}
	}

	@Given("^The ACK file should be created in the outbound folder of unix server \"([^\"]*)\"$")
	public void the_ACK_file_should_be_created_in_the_outbound_folder_of_unix_server(String testCaseId) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		boolean flag;
		UnixUtilityHelper UnixUtilityHelperObj = new UnixUtilityHelper();
		Map<String, String> tdMap;
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		flag = UnixUtilityHelperObj.verifyThePresenceOfDownloadfileInlocal(tdMap.get("OUTBOUND_FILES"));
		if (flag) {
			System.out.println("The ACK files with required format are present in the local directory" + true);
		} else {
			Assert.fail("There are no ACK files in the local directory:" + false);
		}

	}

	@When("^Validate the data in the ACK file with the processed csp membership file by the RAM system for the testcase \"([^\"]*)\"$")
	public void validateTheAckFileDataWithCspMembershipFile(String arg1) throws Throwable {
		Map<String, String> tdMap;
		Map<String, String> headerMap;
		EligibilityUploadCommon EligCommonObj = new EligibilityUploadCommon();
		UnixUtilityHelper UnixUtilityHelperObj = new UnixUtilityHelper();
		RAMCommonDBQuires rcmnDbobj=new RAMCommonDBQuires();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE",arg1);
		EligCommonObj.getCountsFromMembershipFile(arg1);
		headerMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_HEADER_ACTUAL_TABLE", null);
		UnixUtilityHelperObj.readDownloadAckFile(headerMap,tdMap.get("OUTBOUND_FILES"));
		}

	@Given("^The mockdata utility must be run successfully, the data should be inserted into the staging table$")
	public void the_mockdata_utility_must_be_run_successfully_the_data_should_be_inserted_into_the_staging_table()
			throws Throwable {

	}

	@When("^The members with missing situational fields are loaded into the file data tables$")
	public void the_members_with_missing_situational_fields_are_loaded_into_the_file_data_tables() throws Throwable {
		// Mocking up the data
		// MembershipMocking mocking = new MembershipMocking();
		// mocking.createMockDataForMembership(plan, seqRevId,
		// CSPPropertyReader.getcsp_MembeshipFiles());

	}

	@When("^updated as warning: appending to the Error reason column values in staging error tables$")
	public void updated_as_warning_appending_to_the_Error_reason_column_values_in_staging_error_tables()
			throws Throwable {
		EligibilityUploadCommon EligCommonObj = new EligibilityUploadCommon();
		elig_error_subscriber_id = EligCommonObj.situationalFieldsMissingRecords_DbValidation();
		System.out.println("THE ELIG Subscriber_id is" + elig_error_subscriber_id);

	}

	@Then("^Validate the missing situational column values should be null in staging tables$")
	public void validate_the_missing_situational_column_values_should_be_null_in_staging_tables() throws Throwable {
		String flag[] = elig_error_subscriber_id.split(",");
		for (String flagchk : flag) {
			System.out.println("THE CHECK FLAG is:" + flagchk);
			if (flagchk.equals("1")) {
				System.out.println(
						"The No.of ELIG records with WARNING message for subscriber_id: in Elig_File_Error table are matched with the ELIG_FILE_DATA table");
			} else {
				Assert.fail(
						"The No.of ELIG records with WARNING message in Elig_File_Error table NOT matched with the ELIG_FILE_DATA table");
			}
		}
	}

	@When("^The members with missing mandatory fields are moved to the stage error tables with their respective missing coulmn error message$")
	public void mandatoryValuesMissingDbValidation() throws Throwable {
		EligibilityUploadCommon EligCommonObj = new EligibilityUploadCommon();
		EligCommonObj.mandatoryValuesErr_DbValidation();
		demo_error_subscriber_id = EligCommonObj.EligmandatoryValuesErr_DbValidation();
	}

	@Then("^Validate the members with missing mandatory fields should not be present in the staging data tables$")
	public void validate_the_members_with_missing_mandatory_fields_should_not_be_present_in_the_staging_data_tables()
			throws Throwable {
		String flag[] = demo_error_subscriber_id.split(",");
		for (String flagchk : flag) {
			System.out.println("THE CHECK FLAG is:" + flagchk);
			if (flagchk.equals("1")) {
				System.out.println(
						"There are No records in the Staging File data tables when the Mandatory fields are missing with subscriber_id:");
			}

			else {
				Assert.fail(
						"There are records in the Staging File data tables when the Mandatory fields are missing with subscriber_id:");
			}
		}

	}

	@When("^Trigger the EligibilityUpload shell job for wrong Sequence number file for \"([^\"]*)\"$")
	public void trigger_the_EligibilityUpload_shell_job_for_wrong_Sequence_number_file(String testCaseId)
			throws Throwable {
		UnixUtilityHelper UnixUtilityHelperObj = new UnixUtilityHelper();
		RAMCommonDBQuires rcmnDbobj=new RAMCommonDBQuires();
		Map<String, String> tdMap;
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		eligJobStatus_WrongSequence = UnixUtilityHelperObj.execute_unix_job_seqNumber(
				CSPPropertyReader.geteligibilityUploadJob(), CSPPropertyReader.getUnixServer(),
				CSPPropertyReader.getUnixUsername(), CSPPropertyReader.getUnixPassword(), tdMap.get("FILENAME"));

	}

	@Then("^The eligibilityUpload shell job should be failed with the proper message\\.$")
	public void the_eligibilityUpload_shell_job_should_be_failed_with_the_proper_message() throws Throwable {
		if (eligJobStatus_WrongSequence) {
			System.out.println(
					"When the membership file is not in Sequence,the EligibilityUpload Job got Status is Failed :"
							+ JobStatus);
		}

		else {
			Assert.fail(
					"When the membership file is not in Sequence,the EligibilityUpload Job got Status Passed.Please check the Server log");
		}

	}
	
	@Given("^The User should place the CSP_Membership file in the desire location \"([^\"]*)\"$")
	public void membershipFileShouldbePresentInTestDataFolder(String testCaseId) throws Throwable {
		 Map<String, String> tdMap;
			RAMCommonDBQuires ramCommonDBQueryobj = new RAMCommonDBQuires();
			tdMap = ramCommonDBQueryobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
			inputFileName = tdMap.get("PATHNAME") + "/" +tdMap.get("FILENAME");
			File file = new File(inputFileName);
			if (!file.exists()) {
				Assert.fail("\nEligibility upload data file " + tdMap.get("fileName") + " does not exist at : " + tdMap.get("pathName") + "\n"
						+ "for test case " + testCaseId);
			} else {
				System.out.println("\nEligibility upload data file " + tdMap.get("fileName") + " exist at : " +  tdMap.get("pathName") + "\n"
						+ "for test case " + testCaseId);
			}
	}

	@When("^The mockup utility should be invoked and mock the file by removing the mandatory,situational fields in the membership file \"([^\"]*)\"$")
	public void mockUtilityInvoked(String testCaseId) throws Throwable {
	   
		DbQueryHelper dbhelper = new DbQueryHelper();
		RAMCommonDBQuires ramCommonDBQueryobj = new RAMCommonDBQuires();

		 Map<String, String> tdMap;
		tdMap = ramCommonDBQueryobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String seqRevenueId = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.SEQ_REVENUE_ID,tdMap.get("PLANNAME"),tdMap.get("REVENUETYPE")));
		 MembershipMocking mocking = new MembershipMocking();
		 mocking.createMockDataForMembership(tdMap.get("PLANNAME"), seqRevenueId,CSPPropertyReader.getcsp_MembeshipFiles(),false);
	}

	@Then("^The mockfile should be created with the fileName as incrementing one number in Sequence to the original file \"([^\"]*)\"$")
	public void mokedFileshouldBeCreated(String testCaseId) throws Throwable {
		 Map<String, String> tdMap;
			RAMCommonDBQuires ramCommonDBQueryobj = new RAMCommonDBQuires();
			tdMap = ramCommonDBQueryobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
			inputFileName = tdMap.get("PATHNAME") + "/" +tdMap.get("FILENAME");
			File file = new File(inputFileName);
			if (!file.exists()) {
				Assert.fail("\nEligibility upload data file " + tdMap.get("fileName") + " does not exist at : " + tdMap.get("pathName") + "\n"
						+ "for test case " + testCaseId);
			} else {
				System.out.println("\nEligibility upload data file " + tdMap.get("fileName") + " exist at : " +  tdMap.get("pathName") + "\n"
						+ "for test case " + testCaseId);
			}
	}

	}
