package com.optum.ram.atdd.eligibility.eligibilityUpload;

public class EligibilityDBqueries {

	public static final String STAGING_DEMO_TOTAL_COUNTS = "SELECT COUNT(*)	"
			+ "FROM                                   " + "  (SELECT subscriber_id"
			+ "  FROM ram_demographics_file_data DD   " + "  WHERE DD.plan_name IN ('%s' )"
			+ "  UNION                                " + "  SELECT subscriber_id  "
			+ "  FROM ram_demographics_file_error DE  " + "  WHERE DE.plan_name IN ('%s') )";

	public static final String STAGING_ELIG_TOTAL_COUNTS = "select count(*) "
			+ "from           "
			+ "(select subscriber_id from  Ram_Eligibility_File_data where plan_name='%s'  "
			+ "UNION ALL  "
			+ "select subscriber_id from  Ram_Eligibility_File_error  where plan_name='%s' and "
			+ "(substr(ERROR_REASON,0,21)<>'WARNING: Invalid Demo' or ERROR_REASON='Invalid PlanName')) ";
	public static final String TOTAL_CHANGED_MEMBERS = "select total_changed_members from %s";
	public static final String COUNT_OF_RECORDS = "select count(*) from %s where %s";
	public static final String COUNT_OF_RECORDS_FILTER = "select count(*) from %s where %s='%s'";
	public static final String STATUS_MEMBERSHIPHEADER_TABLE = "select STATUS from ram_membership_file_header";
	public static final String DEMO_ERROR_WARNING = "select distinct ERROR_REASON from RAM_DEMOGRAPHICS_FILE_ERROR where substr(ERROR_REASON,0,7)='WARNING'";
	public static final String SUBSCRIBER_ID_DEMOERROR_WARNING = "select subscriber_id from RAM_DEMOGRAPHICS_FILE_ERROR where substr(ERROR_REASON,0,7)='WARNING' and %s  Is null";
	public static final String SUBSCRIBER_ID_DETAIL = "select subscriber_id from RAM_DEMOGRAPHICS_FILE_DATA where SUBSCRIBER_ID IN (%s) and %s  Is null";
	public static final String SUBSCRIBER_ID_ELIG_ERROR_WARN = "SELECT" + " CASE" + "     WHEN act.cnt = err.cnt "
			+ "     THEN 1" + "     ELSE 0 " + "   END check_flag" + " FROM " + "   (SELECT ED.subscriber_id,"
			+ "     COUNT(1) cnt " + "   FROM ram_demographics_file_data DD," + "     ram_eligibility_file_data ED, "
			+ "     ram_demographics_file_error erd" + "   WHERE DD.subscriber_id=ED.subscriber_id"
			+ "   AND Erd.subscriber_id =ed.subscriber_id" + "     AND ED.subscriber_id IN (%s)"
			+ "   GROUP BY ED.subscriber_id" + "   ) act," + "   (SELECT subscriber_id," + "     COUNT(1) cnt "
			+ "   FROM WEB.ram_eligibility_file_error "
			+ "   WHERE ERROR_REASON='WARNING: Invalid Demographics Record' " + "   GROUP BY subscriber_id "
			+ "   ) err" + " WHERE act.subscriber_id = err.subscriber_id";
	public static final String DEMO_ERROR_REASON = "Select ERROR_REASON from Ram_Demographics_File_Error where  substr(ERROR_REASON,0,7) <>'WARNING' and substr(ERROR_REASON,0,26)<>'Invalid Eligibility Record'";
	public static final String SUBSCRIBER_ID_DEMO_ERROR = "Select subscriber_id from Ram_Demographics_File_Error where  substr(ERROR_REASON,0,7) <>'WARNING' and substr(ERROR_REASON,0,26)<>'Invalid Eligibility Record' and %s Is null";

	public static final String SUBSCRIBER_ID_ELIG_ERROR_VAD = "SELECT "
			+ "case  when count(EE.subscriber_id) >0 then 1 else 0" + "end chk_flag                                   "
			+ "FROM Ram_Eligibility_File_error EE,   " + "ram_demographics_file_error DE        "
			+ "WHERE DE.subscriber_id IN (%s)   " + "AND de.subscriber_id =ee.subscriber_id  "
			+ "AND EE.ERROR_REASON ='Invalid Demographics Record'" + "AND NOT EXISTS          "
			+ "  (SELECT *             " + "  FROM ram_demographics_file_data DD," + "    Ram_Eligibility_File_Data ED "
			+ "  WHERE DD.subscriber_id  = DD.subscriber_id" + "  and de.subscriber_id  = DD.subscriber_id"
			+ "  AND ED.subscriber_id IN (%s)" + "  )";
	public static final String ELIG_ERROR_REASON = "select ERROR_REASON from Ram_Eligibility_File_error where  substr(ERROR_REASON,0,21)<>'WARNING: Invalid Demo' and substr(ERROR_REASON,0,27)<>'Invalid Demographics Record'";
	public static final String SUBSCRIBER_ID_ELIG_ERROR = "Select subscriber_id from Ram_Eligibility_File_Error where  substr(ERROR_REASON,0,7) <>'WARNING' and substr(ERROR_REASON,0,27)<>'Invalid Demographics Record' and %s Is null";
	public static final String SUBSCRIBER_ID_DEMO_ERROR_VAD = "SELECT                                                                                       "
			+ "CASE                                                                                     "
			+ "WHEN COUNT(EE.subscriber_id) >0                                                          "
			+ "THEN 1                                                                                   "
			+ "ELSE 0 end chk_flag                                                                      "
			+ "FROM Ram_Eligibility_File_error EE,                                                      "
			+ "  ram_demographics_file_error DE                                                         "
			+ "WHERE DE.subscriber_id IN (%s)                                                    "
			+ "AND de.subscriber_id =ee.subscriber_id AND DE.ERROR_REASON ='Invalid Eligibility Record' "
			+ "AND NOT EXISTS                                                                           "
			+ "  (SELECT *                                                                              "
			+ "  FROM ram_demographics_file_data DD,                                                    "
			+ "    Ram_Eligibility_File_Data ED                                                         "
			+ "  WHERE DD.subscriber_id = DD.subscriber_id                                              "
			+ "  AND de.subscriber_id   = DD.subscriber_id                                              "
			+ "  AND ED.subscriber_id  IN (%s)                                                   " + "  )";

	public static final String SUBSCRIBER_ID_DEMO_ERROR_GROUPID_VAD = "SELECT                                                                                       "
			+ "CASE                                                                                     "
			+ "WHEN COUNT(EE.subscriber_id) >0                                                          "
			+ "THEN 1                                                                                   "
			+ "ELSE 0 end chk_flag                                                                      "
			+ "FROM Ram_Eligibility_File_error EE,                                                      "
			+ "  ram_demographics_file_error DE                                                         "
			+ "WHERE DE.subscriber_id IN (%s)                                                    "
			+ "AND de.subscriber_id =ee.subscriber_id AND DE.ERROR_REASON ='Invalid Eligibility Record with Null PlanName' "
			+ "AND NOT EXISTS                                                                           "
			+ "  (SELECT *                                                                              "
			+ "  FROM ram_demographics_file_data DD,                                                    "
			+ "    Ram_Eligibility_File_Data ED                                                         "
			+ "  WHERE DD.subscriber_id = DD.subscriber_id                                              "
			+ "  AND de.subscriber_id   = DD.subscriber_id                                              "
			+ "  AND ED.subscriber_id  IN (%s)                                                   " + "  )";
	public static final String DEMO_FILEDATA_COUNT="select count(*) from ram_demographics_File_data where plan_name='%s'";
	public static final String ELIG_FILEDATA_COUNT="select count(*) from ram_eligibility_File_data where plan_name='%s'";

}
