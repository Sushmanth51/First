package com.optum.ram.atdd.eligibility.eligibilityUpload;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.Assert;

import com.optum.facets.atdd.common.utils.ConnectionHelper;
import com.optum.facets.atdd.common.utils.DatabaseProcessor;
import com.optum.ram.atdd.common.utils.CSPCommonTestBase;
import com.optum.ram.atdd.common.utils.DbQueryHelper;
import com.optum.ram.atdd.common.utils.RAMCommonDBQuires;

public class EligibilityUploadCommon extends CSPCommonTestBase {
	List<String> linesInTextFile = null;
	DbQueryHelper DbQueryHelperobj = new DbQueryHelper();
	Statement statement;
	ResultSet rs;
	Map<String, String> tdMap = new HashMap<String, String>();
	// EligibilityUploadConstants eligConstantsObj =new
	// EligibilityUploadConstants();
	public static int demoRecordCnt, EligRecordCnt;
	public static String totalRecordCount, detailRecordsCount, membershipFileName;
	



	public Map<String, String> getTestDataBykeycolumn(String tableName, String keycolumn, String value)
			throws Exception {

		ConnectionHelper.sqliteConnection = ConnectionHelper
				.openSqliteConnection("src/main/resources/eligibilityUpload/db_file/eligibilityUpload.db");
		Statement stmt;
		ResultSet rs;
		Map<String, String> rsResults;
		String query;
		try {
			stmt = ConnectionHelper.sqliteConnection.createStatement();
			if (null != keycolumn) {

				query = ("select * FROM " + tableName + " WHERE " + keycolumn + " = '" + value + "' ");
			} else {
				query = "select * FROM " + tableName + "";
			}
			System.out.println("The Query is" + query);
			rs = stmt.executeQuery(query);
			rsResults = new HashMap<String, String>();
			while (rs.next()) {
				ResultSetMetaData rsmd = rs.getMetaData();
				for (int i = 1; i <= rsmd.getColumnCount(); i++) {
					rsResults.put(rsmd.getColumnName(i), rs.getString(rsmd.getColumnName(i)));
				}
			}
			return rsResults;

		} catch (Exception e) {
			throw new Exception(e);
		}

	}

	/**
	 * @purpose:Get the count of Demographics,Eligibility records from the
	 *              Membership File
	 * @param testCaseId
	 * @throws Exception
	 * @author ksushman
	 */
	public void getCountsFromMembershipFile(String testCaseId) throws Exception {
		try {
			RAMCommonDBQuires rcmnDbobj=new RAMCommonDBQuires();
			tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
			inputFileName = tdMap.get("PATHNAME") + "/" + tdMap.get("FILENAME");
			membershipFileName = tdMap.get("FILENAME");
			linesInTextFile = Files.readAllLines(Paths.get(inputFileName));
			for (String line : linesInTextFile) {
				String suffix = line.substring(0, 4);
				switch (suffix) {
				case "DEMO":
					demoRecordCnt++;
					break;
				case "ELIG":
					EligRecordCnt++;
					break;
				case "T000":
					totalRecordCount = (line.substring(2, 16)).replaceFirst("^0+(?!$)", "");
					System.out.println("The totalRecordCount records:" + totalRecordCount);
					detailRecordsCount = (line.substring(17, line.length())).replaceFirst("^0+(?!$)", "");
					System.out.println("The totalRecordCount records:" + totalRecordCount);
					System.out.println("The detailRecordsCount records:" + detailRecordsCount);
					break;
				}
			}
			System.out.println("The DEMO records" + demoRecordCnt);
			System.out.println("The ELIG records" + EligRecordCnt);

		} catch (Exception e) {
			throw new Exception(e);
		}

	}

	/**
	 * @Purpose: Verify Whether the Header record Information from the
	 *           CSP_Membership file is loaded into the
	 *           RAM_Membership_File_Header table
	 * @param hd_Tr
	 * @throws Exception
	 */
	public void verifyTheDataInMembershipHeaderTable(String column) throws Exception {
		tdMap = getTestDataBykeycolumn("ELIGIBILITY_UPLOAD_HEADER_ACTUAL_TABLE", column, "H");
		Statement statement;
		statement = getConnection();

		String STATUS_MEMBERSHIPHEADER = DbQueryHelperobj
				.getMultipleValues(String.format(EligibilityDBqueries.STATUS_MEMBERSHIPHEADER_TABLE));
		if (STATUS_MEMBERSHIPHEADER.equals("C")) {
			String where = "FILE_Source='" + tdMap.get("DESCRIPTION2") + "'" + " and RUN_DATE=(to_date('"
					+ tdMap.get("CURRENT") + "','MMDDYYYY')) and sequence_number='" + tdMap.get("SEQUENCE")
					+ "' and ENVIRONMENT='" + tdMap.get("REGION") + "'" + "and FILE_TYPE='" + tdMap.get("FILE") + "'";

			String dbcount = DbQueryHelperobj.getMultipleValues(
					String.format(EligibilityDBqueries.COUNT_OF_RECORDS, "ram_membership_file_header", where));
			if (dbcount.equals("1")) {
				System.out.println(
						"The Header data in the csp_membership file is matched with the Ram_MembershipfileHeader table");
			} else {
				Assert.fail(
						"The Header data in the csp_membership file is NOT  matched with the Ram_MembershipfileHeader table");
			}
		} else {
			Assert.fail("The Status in the Ram_Membershipfileheader table is:" + STATUS_MEMBERSHIPHEADER);
		}

	}

	/**
	 * @Purpose:Validate the Counts between the MembeshipFile and the RAM
	 *                   staging tables
	 * @throws Exception
	 * @author ksushman
	 */
	public void compareCounts_File_Db() throws Exception {

		String totalDemoRecords_stagingDb = DbQueryHelperobj.getMultipleValues(String
				.format(EligibilityDBqueries.STAGING_DEMO_TOTAL_COUNTS, tdMap.get("PLANNAME"), tdMap.get("PLANNAME")));
		String totalChangedMembers_demoTrailer = DbQueryHelperobj.getMultipleValues(
				String.format(EligibilityDBqueries.TOTAL_CHANGED_MEMBERS, "ram_demographics_file_trailer"));
		String totalEligRecords_stagingDb = DbQueryHelperobj.getMultipleValues(String
				.format(EligibilityDBqueries.STAGING_ELIG_TOTAL_COUNTS, tdMap.get("PLANNAME"), tdMap.get("PLANNAME")));
		String totalChangedMembers_eligTrailer = DbQueryHelperobj.getMultipleValues(
				String.format(EligibilityDBqueries.TOTAL_CHANGED_MEMBERS, "ram_eligibility_file_trailer"));

		try {

			if (Integer.parseInt(totalDemoRecords_stagingDb) == demoRecordCnt) {
				System.out.println("The records in the Membeshipfile:" + demoRecordCnt
						+ " are matched with the Staging table:" + totalDemoRecords_stagingDb + "");
			} else {
				Assert.fail("The records in the Membershipfile:" + demoRecordCnt
						+ " not matched with record in the staging table:" + totalDemoRecords_stagingDb + "");
			}
			if (Integer.parseInt(totalChangedMembers_demoTrailer) == demoRecordCnt) {
				System.out.println("The demo records in the Membeshipfile:" + EligRecordCnt
						+ " are matched with the totalChangedMembers:" + totalChangedMembers_eligTrailer
						+ " in Demo_File_trailer table");
			} else {
				Assert.fail("The Demo records in the Membeshipfile:" + demoRecordCnt
						+ " are NOT matched with the totalChangedMembers:" + totalChangedMembers_demoTrailer
						+ " in Demo_File_trailer table");
			}

			if (Integer.parseInt(totalEligRecords_stagingDb) == EligRecordCnt) {
				System.out.println("The Elig records in the Membeshipfile are matched with the Staging tables");
			} else {
				Assert.fail("The Elig records in the Membershipfile:" + EligRecordCnt
						+ " are not matched with Staging tables:" + totalEligRecords_stagingDb + "");
			}

			if (Integer.parseInt(totalChangedMembers_eligTrailer) == EligRecordCnt) {
				System.out.println("The elig records in the Membeshipfile:" + EligRecordCnt
						+ " are matched with the totalChangedMembers:" + totalChangedMembers_eligTrailer
						+ " in Elig_File_trailer table");
			} else {
				Assert.fail("The Elig records in the Membeshipfile:" + EligRecordCnt
						+ " are NOT matched with the totalChangedMembers:" + totalChangedMembers_eligTrailer
						+ " in Elig_File_trailer table");
			}
		} catch (Exception e) {
			throw new Exception(e);
		} /*finally {
			statement.close();
		}*/

	}

	/**
	 * @Purpose:Method to check whether Membership info with Warning message is
	 *                 available or not
	 * @param plan
	 * @return boolean
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * 
	 */
	public boolean checkMemberDataPresence(String column) throws SQLException, ClassNotFoundException, IOException {
		RAMCommonDBQuires common = new RAMCommonDBQuires();
		return common.booleanForString(String.format(EligibilityDBqueries.DEMO_ERROR_WARNING, column));
	}

	/**
	 * @Purpose:Method to validate whether the Situational fields are present in
	 *                 both stage_Error and stage_detail tables or not
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 * @author ksushman
	 */
	public String situationalFieldsMissingRecords_DbValidation()
			throws ClassNotFoundException, SQLException, IOException {
		statement = getConnection();
		String errorReason_Warning = DbQueryHelperobj
				.getMultipleValues(String.format(EligibilityDBqueries.DEMO_ERROR_WARNING));
		String errorSc[];
		String subscriber_id = null;
		String detail_subscriber_id = null;
		String elig_error_subscriber_id = null;

		errorSc = errorReason_Warning.split(",");
		for (int i = 0; i < errorSc.length; i++) {
			if (errorSc[i].contains("CITY")) {
				subscriber_id = DbQueryHelperobj
						.getMultipleValues(String.format(EligibilityDBqueries.SUBSCRIBER_ID_DEMOERROR_WARNING, "CITY"));
				detail_subscriber_id = DbQueryHelperobj.getMultipleValues(
						String.format(EligibilityDBqueries.SUBSCRIBER_ID_DETAIL, subscriber_id, "CITY"));
				elig_error_subscriber_id = DbQueryHelperobj.getMultipleValues(
						String.format(EligibilityDBqueries.SUBSCRIBER_ID_ELIG_ERROR_WARN, detail_subscriber_id));
				System.out.println("The EIG FLAG is" + elig_error_subscriber_id);
			} else if (errorSc[i].contains("ADDRESS_LINE_1")) {
				subscriber_id = DbQueryHelperobj.getMultipleValues(
						String.format(EligibilityDBqueries.SUBSCRIBER_ID_DEMOERROR_WARNING, "ADDRESS_LINE_1"));
				detail_subscriber_id = DbQueryHelperobj.getMultipleValues(
						String.format(EligibilityDBqueries.SUBSCRIBER_ID_DETAIL, subscriber_id, "ADDRESS_LINE_1"));
				elig_error_subscriber_id = DbQueryHelperobj.getMultipleValues(
						String.format(EligibilityDBqueries.SUBSCRIBER_ID_ELIG_ERROR_WARN, detail_subscriber_id));
				System.out.println("The EIG FLAG is" + elig_error_subscriber_id);
			} else if (errorSc[i].contains("STATE")) {
				subscriber_id = DbQueryHelperobj.getMultipleValues(
						String.format(EligibilityDBqueries.SUBSCRIBER_ID_DEMOERROR_WARNING, "STATE"));
				detail_subscriber_id = DbQueryHelperobj.getMultipleValues(
						String.format(EligibilityDBqueries.SUBSCRIBER_ID_DETAIL, subscriber_id, "STATE"));
				elig_error_subscriber_id = DbQueryHelperobj.getMultipleValues(
						String.format(EligibilityDBqueries.SUBSCRIBER_ID_ELIG_ERROR_WARN, detail_subscriber_id));
				System.out.println("The EIG FLAG is" + elig_error_subscriber_id);
			} else if (errorSc[i].contains("ZIP_CODE")) {
				subscriber_id = DbQueryHelperobj.getMultipleValues(
						String.format(EligibilityDBqueries.SUBSCRIBER_ID_DEMOERROR_WARNING, "ZIP_CODE"));
				detail_subscriber_id = DbQueryHelperobj.getMultipleValues(
						String.format(EligibilityDBqueries.SUBSCRIBER_ID_DETAIL, subscriber_id, "ZIP_CODE"));
				elig_error_subscriber_id = DbQueryHelperobj.getMultipleValues(
						String.format(EligibilityDBqueries.SUBSCRIBER_ID_ELIG_ERROR_WARN, detail_subscriber_id));
				System.out.println("The EIG FLAG is" + elig_error_subscriber_id);
			}
		}

		return elig_error_subscriber_id;
	}

	/**
	 * @purpose: Validates whether the demo records mandatory values are moved
	 *           to Error tables or not
	 * @throws NullPointerException
	 * @throws SQLException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public void mandatoryValuesErr_DbValidation()
			throws NullPointerException, SQLException, ClassNotFoundException, IOException {
		statement = getConnection();
		String errorReason = DbQueryHelperobj
				.getMultipleValues(String.format(EligibilityDBqueries.DEMO_ERROR_REASON, "ERROR_REASON"));
		String errorSc[];
		String subscriber_id = null;
		String elig_error_subscriber_id = null;
		errorSc = errorReason.split(",");
		for (String errorReasons : errorSc) {
			if (errorReasons.contains("FIRST_NAME")) {
				subscriber_id = DbQueryHelperobj
						.getMultipleValues(String.format(EligibilityDBqueries.SUBSCRIBER_ID_DEMO_ERROR, "FIRST_NAME"));
				System.out.println("The Subscriber_is:" + subscriber_id);
				elig_error_subscriber_id = DbQueryHelperobj.getMultipleValues(
						String.format(EligibilityDBqueries.SUBSCRIBER_ID_ELIG_ERROR_VAD, subscriber_id, subscriber_id));
				System.out.println("The Subscriber_is:" + elig_error_subscriber_id);
			}

			else if (errorReasons.contains("LAST_NAME")) {
				subscriber_id = DbQueryHelperobj
						.getMultipleValues(String.format(EligibilityDBqueries.SUBSCRIBER_ID_DEMO_ERROR, "LAST_NAME"));
				System.out.println("The Subscriber_is:" + subscriber_id);
				elig_error_subscriber_id = DbQueryHelperobj.getMultipleValues(
						String.format(EligibilityDBqueries.SUBSCRIBER_ID_ELIG_ERROR_VAD, subscriber_id, subscriber_id));
				System.out.println("The Subscriber_is:" + elig_error_subscriber_id);

			}

			if (elig_error_subscriber_id.equals("1")) {
				System.out.println(
						"There are No records in the Staging File data tables when the Mandatory fields are missing with subscriber_id:"
								+ subscriber_id + " ");
			}

			else {
				Assert.fail(
						"There are records in the Staging File data tables when the Mandatory fields are missing with subscriber_id:"
								+ subscriber_id + "");
			}
		}
	}

	/**
	 * @purpose: Validates whether the Elig records mandatory values are moved
	 *           to Error tables or not
	 * @throws NullPointerException
	 * @throws SQLException
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	public String EligmandatoryValuesErr_DbValidation() throws NullPointerException, SQLException, ClassNotFoundException, IOException {
		String errorReason_elig = DbQueryHelperobj
				.getMultipleValues(String.format(EligibilityDBqueries.ELIG_ERROR_REASON, "ERROR_REASON"));
		String errorSc[];
		String subscriber_id = null;
		String demo_error_subscriber_id = null;
		errorSc = errorReason_elig.split(",");
		for (String errorReasons : errorSc) {
			if (errorReasons.contains("EFFECTIVE_DATE")) {
				subscriber_id = DbQueryHelperobj.getMultipleValues(
						String.format(EligibilityDBqueries.SUBSCRIBER_ID_ELIG_ERROR, "EFFECTIVE_DATE"));
				System.out.println("The Subscriber_is:" + subscriber_id);
				demo_error_subscriber_id = DbQueryHelperobj.getMultipleValues(
						String.format(EligibilityDBqueries.SUBSCRIBER_ID_DEMO_ERROR_VAD, subscriber_id, subscriber_id));
				System.out.println("The Subscriber_is:" + demo_error_subscriber_id);
			} else if (errorReasons.contains("TERM_DATE")) {
				subscriber_id = DbQueryHelperobj
						.getMultipleValues(String.format(EligibilityDBqueries.SUBSCRIBER_ID_ELIG_ERROR, "TERM_DATE"));
				System.out.println("The Subscriber_is:" + subscriber_id);
				demo_error_subscriber_id = DbQueryHelperobj.getMultipleValues(
						String.format(EligibilityDBqueries.SUBSCRIBER_ID_DEMO_ERROR_VAD, subscriber_id, subscriber_id));
				System.out.println("The Subscriber_is:" + demo_error_subscriber_id);

			} else if (errorReasons.contains("Invalid PlanName")) {
				subscriber_id = DbQueryHelperobj
						.getMultipleValues(String.format(EligibilityDBqueries.SUBSCRIBER_ID_ELIG_ERROR, "GROUP_ID"));
				System.out.println("The Subscriber_is:" + subscriber_id);
				demo_error_subscriber_id = DbQueryHelperobj.getMultipleValues(String.format(
						EligibilityDBqueries.SUBSCRIBER_ID_DEMO_ERROR_GROUPID_VAD, subscriber_id, subscriber_id));
				System.out.println("The Subscriber_is:" + demo_error_subscriber_id);
			}
			if (demo_error_subscriber_id.equals("1")) {
				System.out.println(
						"There are No records in the Staging File data tables when the Mandatory fields are missing with subscriber_id:"
								+ subscriber_id + " ");
			}

			else {
				Assert.fail(
						"There are records in the Staging File data tables when the Mandatory fields are missing with subscriber_id:"
								+ subscriber_id + "");
			}

		}
		return demo_error_subscriber_id;

	}
	
	/**
	 * @throws Exception 
	 * @purpose This method used to create table, store the fileData tables detail counts in the Sqlite db
	 */
	public void storeFileDataCountsInSqliteDb(String testCaseId) throws Exception{
		RAMCommonDBQuires rcmnDbobj=new RAMCommonDBQuires();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		DbQueryHelper DbQueryHelperobj = new DbQueryHelper();
		try {

			String demo_fileDataCount = DbQueryHelperobj
					.getMultipleValues(String.format(EligibilityDBqueries.DEMO_FILEDATA_COUNT, tdMap.get("PLANNAME")));
			String elig_fileDataCount = DbQueryHelperobj
					.getMultipleValues(String.format(EligibilityDBqueries.ELIG_FILEDATA_COUNT, tdMap.get("PLANNAME")));
			createTable("batch_cntrl", "demoDetailCounts,eligDetailCounts");
			insertValuesIntoColumns("batch_cntrl", "demoDetailCounts,eligDetailCounts",
					"" + demo_fileDataCount + "," + elig_fileDataCount + "");
		} catch (Exception e) {
			Assert.fail("Unable to Store the filedata  counts in the batch_cntrl table");
		}
	}
	/**@purpose This method is used to create a table in SqlLite Db with provided columns name as input
	 * @param tableName
	 * @param colValues
	 * @throws SQLException
	 */
	public static void createTable(String tableName, String colValues) throws SQLException {
		String createTableStatement;
		StringBuffer colValue = new StringBuffer();
		Statement st = ConnectionHelper.sqliteConnection.createStatement();
		DatabaseProcessor.dropDatabaseTable(tableName, st);
		String[] column = colValues.split(",");
		try {
			for (String value : column) {

				colValue.append(value + "  VARCHAR(10),");
			}
			// create the table
			createTableStatement = "Create table " + tableName + "( " + colValue.substring(0, colValue.length() - 1)
					+ ");";

			DatabaseProcessor.executeSqlUpdate(st, createTableStatement);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @purpose This method is used to insert column values into the Sqlite
	 *          table
	 * @param tableName
	 * @param columns
	 * @param columnValues
	 * @throws SQLException
	 */
	public static void insertValuesIntoColumns(String tableName, String columns, String columnValues)
			throws SQLException {
		Statement st = ConnectionHelper.sqliteConnection.createStatement();
		String insertStm = null;
		try {
			insertStm = "Insert into " + tableName + "(" + columns + ") VALUES(" + columnValues + ")";
			DatabaseProcessor.executeSqlUpdate(st, insertStm);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
