package com.optum.ram.atdd.eligibility.eligibilityUpload;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.xml.datatype.DatatypeConfigurationException;
import com.optum.facets.atdd.common.utils.ConnectionHelper;
import com.optum.facets.atdd.common.utils.DatabaseProcessor;

/**
 * Constant Class
 * 
 * @author rchawdh
 *
 */
public class EligibilityUploadConstants {

	/**
	 * Generic method to get test data from SQLITE table
	 * 
	 * @param tableName
	 * @param columnName
	 * @param testCaseId
	 * @return
	 * @throws SQLException
	 * @throws DatatypeConfigurationException
	 * @throws ClassNotFoundException
	 */
	public static String getResultSetForTestData(String tableName, String columnName, String testCaseId)
			throws SQLException, DatatypeConfigurationException, ClassNotFoundException {
		ConnectionHelper.sqliteConnection = ConnectionHelper
				.openSqliteConnection("src/main/resources/eligibilityUpload/db_file/eligibilityUpload.db");
		Statement stmt = ConnectionHelper.sqliteConnection.createStatement();
		String query = ("select " + columnName + " FROM " + tableName + " WHERE TESTCASEID = '" + testCaseId + "' ");

		// logCapture.captureData("Query", testcaseID, file, query);
		System.out.println(query);
		ResultSet resultSet = DatabaseProcessor.executeSqlQuery(stmt, query);
		String columnData = "";
		if (resultSet.next()) {
			columnData = resultSet.getString(1);
		}
		stmt.close();
		return columnData;
	}

}
