package com.optum.ram.atdd.common.utils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.testng.Assert;
import org.testng.AssertJUnit;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.optum.ram.atdd.eligibility.eligibilityUpload.EligibilityUploadCommon;

public class UnixUtilityHelper extends CSPPropertyReader {

	static boolean flag;
	private static final Log log = LogFactory.getLog(UnixUtilityHelper.class);
	public static String demoFileError=null;
	public static String eligFileError=null;

	/*
	 * Purpose : This method is used to establish the connection to the Unix
	 * host server Parameters: null Return Type: null
	 */

	public void connectToHostServer() throws JSchException, IOException {
		log.info("The connectToHostServer method execution is Started");
		Channel channel = null;
		Session session = null;
		JSch jsch = new JSch();
		OutputStream ops;
		PrintStream ps;
		try {
			session = jsch.getSession(getUnixUsername(), getUnixServer(), 22);
			session.setPassword(CSPPropertyReader.getUnixPassword());
			session.setConfig("StrictHostKeyChecking", "no");
			session.connect();
			channel = session.openChannel("shell");
			ops = channel.getOutputStream();
			ps = new PrintStream(ops, true);
			channel.connect();
			log.info("Connected to Unix Host Successfully" + getUnixServer());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Purpose : This method is used to clear the files in the unix directory
	 * and transfer the file from local system to Unix Host Server Parameters:
	 * localPath(Where the files are kept) ,hostPath(Where the files need to be
	 * moved) Return Type: null
	 */

	public void filetransfer(String localPath, String hostPath, String fileName)
			throws JSchException, SftpException, IOException {
		Session session = null;
		// Channel channel = null;
		String cmd = null;
		JSch jsch = new JSch();
		String cmd1 = null;
		session = jsch.getSession(getUnixUsername(), getUnixServer(), 22);
		session.setPassword(CSPPropertyReader.getUnixPassword());
		session.setConfig("StrictHostKeyChecking", "no");
		session.connect();
		try {
			log.info("The Local file path is : " + localPath + "");
			log.info("The Unix Server path is:" + hostPath);
			cmd = "cd " + getde_intermediateFilesSeverPath() + ";rm -rf *.txt";
			System.out.println("Removed the intermeditate files in:" + getde_intermediateFilesSeverPath() + "" + cmd);

			// If the previous file was not successfully loaded ,temp file
			// remains in the CSP Folder &Cause the Error while loading the
			// nxt membership file.So removing the SplittedELIG&Demo file in CSP
			// folder

			cmd1 = "cd " + hostPath + ";rm -rf *.txt";
			System.out.println("Removed the previous files in the " + hostPath + "" + cmd1);
			ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
			sftpChannel.connect();
			String membershipfile = localPath + "/" + fileName;
			sftpChannel.put(membershipfile, hostPath);
			log.info("Transfered the Files Successfully to the Unix host" + hostPath);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// channel.disconnect();
			session.disconnect();
		}
	}

	/*
	 * Purpose : This method is used to close the connection to the Host Server
	 * Parameters: null Return Type: null
	 */

	// public void close_host_server_connection(){
	// channel.disconnect();
	// log.info("Disconnected to the channel sucessfully");
	// session.disconnect();
	// log.info("Disconnected to the channel sucessfully");
	//
	// }

	/*
	 * Purpose : This method is used to execute the Shell Script jobs for the
	 * RAM application Parameters: JobName,UnixHost,UnixUser,UnixPass Return
	 * Type: flag=true:if the job execution was success;flag=false:The job
	 * execution was failed
	 */

	public boolean execute_unix_job_jsch(String JobName, String UnixHost, String UnixUser, String UnixPass)
			throws Exception {
		execute_unix_job_jsch(JobName, UnixHost, UnixUser, UnixPass, null);
		/*
		 * System.out.println("The JobName is :" + JobName);
		 * 
		 * String JobLog = null; JSch jsch = new JSch(); Channel channel = null;
		 * Session session = null;
		 * 
		 * try { session = jsch.getSession(UnixUser, UnixHost, 22);
		 * session.setPassword(UnixPass);
		 * session.setConfig("StrictHostKeyChecking", "no"); session.connect();
		 * // execute job String cmd = "cd " + "" + getshellJobPath() + ";" +
		 * JobName + " "; channel = session.openChannel("shell"); OutputStream
		 * ops = channel.getOutputStream(); PrintStream ps = new
		 * PrintStream(ops, true); channel.connect(); ps.println(cmd);
		 * InputStream in = channel.getInputStream(); byte[] tmp = new
		 * byte[1024]; while (true) { while (in.available() > 0) { int i =
		 * in.read(tmp, 0, 1024); if (i < 0) break; // System.out.println(new
		 * String(tmp, 0, i)); JobLog += new String(tmp, 0, i);
		 * System.out.println(JobLog); } if (JobLog != null) { if (JobLog.
		 * contains("Process status 'C' is updated in the AUDIT_MASTER table")
		 * || JobLog.
		 * contains("Process status 'F' is updated in the AUDIT_MASTER table")
		 * || JobLog.contains("Recon Process ended")) {
		 * log.info("The Shell Job executed Successfully for " + JobName); flag
		 * = true;
		 * 
		 * if (JobLog.
		 * contains("Process status 'F' is updated in the AUDIT_MASTER table")){
		 * log.error("The Shell Job "
		 * +JobName+" is Failed.Please check the Server Log file for more details"
		 * ); AssertJUnit.fail("The Shell Job "
		 * +JobName+" is Failed.Please check the Server Log file for more details"
		 * ); flag=false;
		 * 
		 * } break;
		 * 
		 * }
		 * 
		 * try { Thread.sleep(1000); } catch (Exception ee) { } } } } catch
		 * (Exception e) { log.error("Error in executing the Job" + e);
		 * e.printStackTrace(); }finally{ channel.disconnect();
		 * session.disconnect(); }
		 */ return flag;

	}

	public boolean execute_unix_job_jsch(String JobName, String UnixHost, String UnixUser, String UnixPass,
			String process) throws Exception {
		System.out.println("The JobName is :" + JobName);

		String JobLog = null;
		JSch jsch = new JSch();
		Channel channel = null;
		Session session = null;

		try {
			session = jsch.getSession(UnixUser, UnixHost, 22);
			session.setPassword(UnixPass);
			session.setConfig("StrictHostKeyChecking", "no");
			session.connect();
			// execute job
			String cmd = "cd " + "" + getshellJobPath() + ";" + JobName + " ";
			channel = session.openChannel("shell");
			OutputStream ops = channel.getOutputStream();
			PrintStream ps = new PrintStream(ops, true);
			channel.connect();
			ps.println(cmd);
			InputStream in = channel.getInputStream();
			byte[] tmp = new byte[1024];
			String row = null;
			while (true) {
				//String row = null;
				while (in.available() > 0) {
					int i = in.read(tmp, 0, 1024);
					if (i < 0)
						break;
					// System.out.println(new String(tmp, 0, i));
					JobLog += new String(tmp, 0, i);
					System.out.println(JobLog);
					 row =new String(tmp, 0, i);
					 JobLog +=row;
				}
				/*if (process == "recon") {
					if (JobLog != null) {
						if (JobLog.contains("Recon Process ended")) {
							log.info("The Shell Job executed Successfully for " + JobName);
							flag = true;

						}
					}

				} */
				//else {
					if (JobLog != null) {
						//
						if(row.contains("Writing to error file")){
							 String errorFile[] = row.split("[\\[\\]]");
							 for(String msg: errorFile){
								 if(msg.contains("DEMOFILEERROR")){
									 demoFileError=msg;	 
									 System.out.println("The DEMO ERROR FILE is:"+demoFileError);
								 }
								 else if(msg.contains("ELIGFILEERROR")){
									 eligFileError=msg;
									 System.out.println("The ELIG ERROR FILE is:"+eligFileError);
								 }
								 
							 }
						}
							//
						if (JobLog.contains("Process status 'C' is updated in the AUDIT_MASTER table")
								|| JobLog.contains("Process status 'F' is updated in the AUDIT_MASTER table")) {
							log.info("The Shell Job executed Successfully for " + JobName);
							flag = true;

							if (JobLog.contains("Process status 'F' is updated in the AUDIT_MASTER table")) {
								log.error("The Shell Job " + JobName
										+ " is Failed.Please check the Server Log file for more details");
								AssertJUnit.fail("The Shell Job " + JobName
										+ " is Failed.Please check the Server Log file for more details");
								flag = false;
							}
							break;

						}

						try {
							Thread.sleep(1000);
						} catch (Exception ee) {
						}
					}
				}
			//}
		} catch (Exception e) {
			log.error("Error in executing the Job" + e);
			e.printStackTrace();
		} finally {
			channel.disconnect();
			session.disconnect();
		}

		return false;

	}

	public boolean execute_unix_job_seqNumber(String JobName, String UnixHost, String UnixUser, String UnixPass,
			String fileName) throws Exception {
		System.out.println("The JobName is :" + JobName);

		String JobLog = null;
		JSch jsch = new JSch();
		Channel channel = null;
		Session session = null;

		try {
			session = jsch.getSession(UnixUser, UnixHost, 22);
			session.setPassword(UnixPass);
			session.setConfig("StrictHostKeyChecking", "no");
			session.connect();
			// execute job
			String cmd = "cd " + "" + getshellJobPath() + ";" + JobName + " ";
			channel = session.openChannel("shell");
			OutputStream ops = channel.getOutputStream();
			PrintStream ps = new PrintStream(ops, true);
			channel.connect();
			ps.println(cmd);
			InputStream in = channel.getInputStream();
			byte[] tmp = new byte[1024];
			while (true) {
				while (in.available() > 0) {
					int i = in.read(tmp, 0, 1024);
					if (i < 0)
						break;
					JobLog += new String(tmp, 0, i);
					System.out.println(JobLog);
				}
				if (JobLog != null) {
					if (JobLog.contains(" [" + fileName + "] is not in sequence")
							|| JobLog.contains("Process status 'F' is updated in the AUDIT_MASTER table")) {
						flag = true;

						if (JobLog.contains("Process status 'C' is updated in the AUDIT_MASTER table")) {
							log.error("The Shell Job " + JobName
									+ " is Passed for wrong seq_number.Please check the Server Log file for more details");
							AssertJUnit.fail("The Shell Job " + JobName
									+ " is Failed.Please check the Server Log file for more details");
							flag = false;

						}
						break;
					}
				}
			}
		} catch (Exception e) {
			log.error("Error in executing the Job" + e);
			e.printStackTrace();
		} finally {
			channel.disconnect();
			session.disconnect();
		}
		System.out.println("The returned Flag for Seq is:" + flag);
		return flag;

	}

	/**
	 * @Purpose:download the files from the unix host to local System
	 * @return
	 * @throws Exception
	 */
	public boolean download_unix_file_jsch(String outboundPath) throws Exception {
		Channel channel = null;
		Session session = null;
		JSch jsch = new JSch();
		try {
			session = jsch.getSession(getUnixUsername(), getUnixServer(), 22);
			session.setPassword(CSPPropertyReader.getUnixPassword());
			session.setConfig("StrictHostKeyChecking", "no");
			session.connect();
			channel = session.openChannel("sftp");
			channel.connect();
			ChannelSftp sftp = (ChannelSftp) channel;
			sftp.cd(getack_Membershipfile());
			File dir = new File(System.getProperty("user.dir") +"\\"+outboundPath);
			if (!dir.exists())
				dir.mkdir();

			Vector<?> filelist = sftp.ls(getack_Membershipfile());
			DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			Date date1 = new Date();
			String formateddate = dateFormat.format(date1);

			for (int i = 0; i < filelist.size(); i++) {
				LsEntry entry = (LsEntry) filelist.get(i);
				if (entry.getFilename().contains("ACK_RAM_" + formateddate + "")) {
					System.out.println("The ACK file is" + entry.getFilename());
					sftp.get(getack_Membershipfile() + entry.getFilename(), dir.toString());
				}
			}

		} catch (Exception e) {
			System.out.println(e.getMessage().toString());
			e.printStackTrace();
			return false;
		} finally {

			channel.disconnect();
			session.disconnect();
		}
		return true;
	}

	/**
	 * @purpose:Verify whether the list downloaded files are present in the
	 *                 directory or not
	 * @return
	 */
	public boolean verifyThePresenceOfDownloadfileInlocal(String filePath) {
		File folder = new File(System.getProperty("user.dir")+"/"+ filePath);
		File[] listOfFiles = folder.listFiles();
		try {
			if (!(listOfFiles.length == 0)) {
				System.out.println("The number of ACK File are:" + listOfFiles.length);
			} else {
				Assert.fail("Error:There are No files downloaded from unix System");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage().toString());
			e.printStackTrace();
			return false;

		}
		return true;
	}

	/**
	 * @purpose:Validate the ACK file data with the Csp Membership file
	 *                   processed by RAM system
	 * @param headerMap
	 * @throws IOException
	 */
	public void readDownloadAckFile(Map<String, String> headerMap,String ackFilepath) throws IOException {
		File folder = new File(System.getProperty("user.dir") +"\\"+ackFilepath);
		File[] listOfFiles = folder.listFiles();
		List<String> linesInTextFile = null;
		boolean chkFlag = false;
		boolean overAllProcess = false;
		String ExpectedRecordCount = EligibilityUploadCommon.detailRecordsCount;
		String csp_MembershipFileName = EligibilityUploadCommon.membershipFileName;
		try {
			if (!(listOfFiles.length == 0)) {
				for (int i = 0; i < listOfFiles.length; i++) {
					chkFlag = false;
					overAllProcess = false;
					File file = listOfFiles[i];
					linesInTextFile = Files.readAllLines(Paths.get(file.toString()));

					if (linesInTextFile.get(0).contains(headerMap.get("CONTROLNUMBER"))) {
						String Arr[] = file.getName().toString().split("_");
						String ackFileDate = (Arr[2].substring(0, Arr[2].length() - 4));
						overAllProcess = true;
						for (String ACKfile : linesInTextFile) {
							if (ACKfile.startsWith("ControlNumber")
									&& ACKfile.contains(headerMap.get("CONTROLNUMBER"))) {
								chkFlag = true;
							}

							else if (ACKfile.startsWith("FileSequenceNo")
									&& ACKfile.contains(headerMap.get("FILESEQUENCENO"))) {
								chkFlag = true;

							} else if (ACKfile.startsWith("SenderID") && ACKfile.contains("RAM")) {
								chkFlag = true;

							} else if (ACKfile.startsWith("ReceiverID") && ACKfile.contains("CSP")) {
								chkFlag = true;

							} else if (ACKfile.startsWith("FileName") && ACKfile.contains(csp_MembershipFileName)) {
								chkFlag = true;
							} else if (ACKfile.startsWith("AckFileDateTime") && ACKfile.contains(ackFileDate)) {
								chkFlag = true;

							} else if (ACKfile.startsWith("AckStatus") && ACKfile.contains("PASS")) {
								chkFlag = true;

							} else if (ACKfile.startsWith("ExpectedRecordCount")
									&& ACKfile.contains(ExpectedRecordCount)) {
								chkFlag = true;
							} else if (ACKfile.startsWith("ActualRecordCount")
									&& ACKfile.contains(ExpectedRecordCount)) {
								chkFlag = true;
							}

							else if (ACKfile.startsWith("ExpectedAmount1") && ACKfile.contains("N/A")) {
								chkFlag = true;

							} else if (ACKfile.startsWith("ActualAmount1") && ACKfile.contains("N/A")) {
								chkFlag = true;
							}

							else if (ACKfile.startsWith("ExpectedAmount2") && ACKfile.contains("N/A")) {
								chkFlag = true;

							} else if (ACKfile.startsWith("ActualAmount2") && ACKfile.contains("N/A")) {
								chkFlag = true;

							} else if (ACKfile.startsWith("ExpectedAmount3") && ACKfile.contains("N/A")) {
								chkFlag = true;
							} else if (ACKfile.startsWith("ActualAmount3") && ACKfile.contains("N/A")) {
								chkFlag = true;

							} else if (ACKfile.startsWith("ExpectedAmount4") && ACKfile.contains("N/A")) {

								chkFlag = true;
							} else if (ACKfile.startsWith("ActualAmount4") && ACKfile.contains("N/A")) {
								chkFlag = true;

							} else if (ACKfile.startsWith("ExpectedAmount5") && ACKfile.contains("N/A")) {
								chkFlag = true;

							} else if (ACKfile.startsWith("ActualAmount5") && ACKfile.contains("N/A")) {
								chkFlag = true;

								System.out.println("The ACK file is " + ACKfile);
							}

							else {
								chkFlag = false;
								break;
							}

							if (chkFlag) {
								i = listOfFiles.length;
							}

						}
					}
				}

				if (!overAllProcess) {
					Assert.fail("The downloaded ACK file data does not match with the data in CSP membership file ");
				}

			}

			else {
				Assert.fail("There are NO ACK files and the no.of files in downloaded are:" + listOfFiles.length);
				chkFlag = false;
			}

		} catch (Exception e) {
			System.out.println(e.getMessage().toString());
			e.printStackTrace();
		}
	}
	//
	public boolean execute_job_p(String JobName, String UnixHost, String UnixUser, String UnixPass,String process) throws Exception {
		System.out.println("The JobName is :" + JobName);

		String JobLog = null;
		JSch jsch = new JSch();
		Channel channel = null;
		Session session = null;

		try {
			session = jsch.getSession(UnixUser, UnixHost, 22);
			session.setPassword(UnixPass);
			session.setConfig("StrictHostKeyChecking", "no");
			session.connect();
			// execute job
			String cmd = "cd " + "" + getshellJobPath() + ";" + JobName + " ";
			channel = session.openChannel("shell");
			OutputStream ops = channel.getOutputStream();
			PrintStream ps = new PrintStream(ops, true);
			channel.connect();
			ps.println(cmd);
			InputStream in = channel.getInputStream();
			byte[] tmp = new byte[1024];
			String row = null;
			while (true) {
				while (in.available() > 0) {
					int i = in.read(tmp, 0, 1024);
					if (i < 0)
						break;
					// System.out.println(new String(tmp, 0, i));
//					JobLog += new String(tmp, 0, i);
					 row =new String(tmp, 0, i);
					 JobLog +=row;
					System.out.println(JobLog);
					if(row.contains("Writing to error file")){
						 String errorFile[] = row.split("[\\[\\]]");
						 for(String msg: errorFile){
							 if(msg.contains("DEMOFILEERROR")){
								 demoFileError=msg;	 
								 System.out.println("The DEMO ERROR FILE is:"+demoFileError);
							 }
							 else if(msg.contains("ELIGFILEERROR")){
								 eligFileError=msg;
								 System.out.println("The ELIG ERROR FILE is:"+eligFileError);
							 }
							 
						 }
					}
				//	  demoFileError=errorFile[1].toString().substring(0,errorFile[1].length());
//						System.out.println("The DEMO ERROR FILE is:"+demoFileError);
//					}
//					else if(row.contains("Writing to error file")){
//						 String errorFile[] = row.split("[\\[\\]]");
//						  eligFileError=errorFile[1].toString().substring(0,errorFile[1].length());
//						System.out.println("The ELIG ERROR FILE is:"+eligFileError);
//						
//					}
				
			/*	if (process == "recon") {
					if (JobLog != null) {
						if (JobLog.contains("Recon Process ended")) {
							log.info("The Shell Job executed Successfully for " + JobName);
							flag = true;

						}
					}

				}*/// else {
//					if (JobLog != null) {
						
						/*if(process =="EligibilityUpload"){
							if(row.contains("Writing to error file")){
								 String errorFile[] = JobLog.split("[\\[\\]]");
								  demoFileError=errorFile[1].toString().substring(0,errorFile[1].length());
								System.out.println("The DEMO ERROR FILE is:"+demoFileError);
							}
							else if(JobLog.contains("Writing to error file")){
								 String errorFile[] = JobLog.split("[\\[\\]]");
								  eligFileError=errorFile[1].toString().substring(0,errorFile[1].length());
								System.out.println("The ELIG ERROR FILE is:"+eligFileError);
								
							}
						}*/
						
						if (JobLog.contains("Process status 'C' is updated in the AUDIT_MASTER table")
								|| JobLog.contains("Process status 'F' is updated in the AUDIT_MASTER table")) {
							log.info("The Shell Job executed Successfully for " + JobName);
							break;
							//flag = true;

//							if (JobLog.contains("Process status 'F' is updated in the AUDIT_MASTER table")) {
//								log.error("The Shell Job " + JobName
//										+ " is Failed.Please check the Server Log file for more details");
//								AssertJUnit.fail("The Shell Job " + JobName
//										+ " is Failed.Please check the Server Log file for more details");
//								flag = false;
//
//							}
							
//							break;

						}
						try {
							Thread.sleep(1000);
						} catch (Exception ee) {
						}
					}
				//}
//			}
		} 
		}catch (Exception e) {
			log.error("Error in executing the Job" + e);
			e.printStackTrace();
		} finally {
			channel.disconnect();
			session.disconnect();
		}
		return flag;

	}
	public boolean holdFlagsJob(String JobName, String UnixHost, String UnixUser, String UnixPass,String planName,String seqRevenueId) throws Exception {
		System.out.println("The JobName is :" + JobName);

		String JobLog = null;
		JSch jsch = new JSch();
		Channel channel = null;
		Session session = null;

		try {
			session = jsch.getSession(UnixUser, UnixHost, 22);
			session.setPassword(UnixPass);
			session.setConfig("StrictHostKeyChecking", "no");
			session.connect();
			// execute job
			String cmd = "cd " + "" + getshellJobPath() + ";" + JobName + " ";
			channel = session.openChannel("shell");
			OutputStream ops = channel.getOutputStream();
			PrintStream ps = new PrintStream(ops, true);
			channel.connect();
			ps.println(cmd);
			InputStream in = channel.getInputStream();
			byte[] tmp = new byte[1024];
			while (true) {
				while (in.available() > 0) {
					int i = in.read(tmp, 0, 1024);
					if (i < 0)
						break;
					JobLog += new String(tmp, 0, i);
					System.out.println(JobLog);
				}
				if (JobLog != null) {
					if (JobLog.contains("Invoice generation is on hold")||JobLog.contains("Reconciliation process for "+planName+" "+seqRevenueId+" is on hold")) {
						flag = true;
						}
						break;

					}
				}
			
		} catch (Exception e) {
			log.error("Error in executing the Job" + e);
			e.printStackTrace();
		} finally {
			channel.disconnect();
			session.disconnect();
		}
		System.out.println("The returned Flag for Seq is:" + flag);
		return flag;

	}
	
	public static boolean execute_unix_BulkUpdatejob(String JobName, String UnixHost, String UnixUser, String UnixPass) throws Exception {
		System.out.println("The JobName is :" + JobName);
		boolean isJobExecuted = false;
		String JobLog = null;
		JSch jsch = new JSch();
		Channel channel = null;
		Session session = null;

		try {
			session = jsch.getSession(UnixUser, UnixHost, 22);
			session.setPassword(UnixPass);
			session.setConfig("StrictHostKeyChecking", "no");
			session.connect();
			// execute job
			String cmd = "cd " + "" + getshellJobPath() + ";" + JobName + " ";
			channel = session.openChannel("shell");
			OutputStream ops = channel.getOutputStream();
			PrintStream ps = new PrintStream(ops, true);
			channel.connect();
			ps.println(cmd);
			InputStream in = channel.getInputStream();
			byte[] tmp = new byte[1024];
			while (true) {
				while (in.available() > 0) {
					int i = in.read(tmp, 0, 1024);
					if (i < 0)
						break;
					JobLog += new String(tmp, 0, i);
					System.out.println(JobLog);
				}
				if (JobName.contains("bulkupdate")) {
					if (JobLog != null) {
						if (JobLog.contains("Bulk Update Completed") || JobLog.contains("Successfully fiile loaded into DB")) {
							log.info("The Shell Job executed Successfully for " + JobName);
							isJobExecuted = true;
							break;
						}
					}

				} 
			}
		} catch (Exception e) {
			log.error("Error in executing the Job" + e);
			e.printStackTrace();
		} finally {
			channel.disconnect();
			session.disconnect();
		}

		return isJobExecuted;

	}
}
