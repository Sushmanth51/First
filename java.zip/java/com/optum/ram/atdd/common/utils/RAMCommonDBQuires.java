package com.optum.ram.atdd.common.utils;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.optum.facets.atdd.common.utils.ConnectionHelper;
import com.optum.facets.atdd.common.utils.DatabaseProcessor;

public class RAMCommonDBQuires extends CSPCommonTestBase {

	/**
	 * @param qry
	 * @return
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Common method to return Boolean for the String query
	 */
	public boolean booleanForString(String qry) throws ClassNotFoundException, IOException, SQLException{
		ResultSet result = null;
		Statement statement = null;
		int cnt = 0;	
		try {
			statement = getConnection();
			result = DatabaseProcessor.executeSqlQuery(statement,qry);
			while (result.next()) { 
				cnt = result.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}finally{
			statement.close();
			result.close();
		}
		if(cnt>0){
			return true;
		}else{
			return false;
		}		
	}
	
	/**
	 * @param qry
	 * @return String
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Common method to return Boolean for the String query
	 */
	public String getSingleResult(String qry) throws ClassNotFoundException, IOException, SQLException{
		ResultSet result = null;
		Statement statement = null;
		String resultString = "";	
		try {
			statement = getConnection();
			result = DatabaseProcessor.executeSqlQuery(statement,qry);
			while (result.next()) { 
				resultString = result.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return resultString;
		}finally{
			statement.close();
			result.close();
		}
		return resultString;
				
	}
	
	/**
	 * @param query
	 * @return List<String>
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 * Generic method to return Single column list for a query
	 */
	public List<String> getSingleColumnListforQuery(String query) throws ClassNotFoundException, IOException, SQLException {
		List<String>stringList = new ArrayList<String>();	
		ResultSet result = null;
		Statement statement = null;
		try {
			statement = getConnection();
			result = DatabaseProcessor.executeSqlQuery(statement,query);
			while (result.next()) {
				stringList.add(result.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			statement.close();
			result.close();
		}	
		return stringList;
	}
	/**
	 * @purpose Method used to get the data from Sqlite tables.
	 * @param tableName
	 * @param keycolumn
	 * @param value
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> getTestDataBykeycolumn(String tableName, String keycolumn, String value)
			throws Exception {

		ConnectionHelper.sqliteConnection = ConnectionHelper
				.openSqliteConnection("src/main/resources/eligibilityUpload/db_file/eligibilityUpload.db");
		Statement stmt;
		ResultSet rs;
		Map<String, String> rsResults;
		String query;
		try {
			stmt = ConnectionHelper.sqliteConnection.createStatement();
			if (null != keycolumn) {

				query = ("select * FROM " + tableName + " WHERE " + keycolumn + " = '" + value + "' ");
			} else {
				query = "select * FROM " + tableName + "";
			}
			System.out.println("The Query is" + query);
			rs = stmt.executeQuery(query);
			rsResults = new HashMap<String, String>();
			while (rs.next()) {
				ResultSetMetaData rsmd = rs.getMetaData();
				for (int i = 1; i <= rsmd.getColumnCount(); i++) {
					rsResults.put(rsmd.getColumnName(i), rs.getString(rsmd.getColumnName(i)));
				}
			}
			return rsResults;

		} catch (Exception e) {
			throw new Exception(e);
		}

	}
	/**
	 * Generic method to get the entire row from SqlLite db table based on the
	 * Key[i.e TestCaseID]
	 * 
	 * @param tableName
	 * @param testCaseId
	 * @return rsResults[i.e. Map based on the KeyValue(i.e. testcaseID)]
	 * @throws Exception
	 * @author ksushman
	 */
	public Map<String, String> getTestDataByTestCaseID(String tableName, String testCaseId) throws Exception {

		ConnectionHelper.sqliteConnection = ConnectionHelper
				.openSqliteConnection("src/main/resources/eligibilityUpload/db_file/eligibilityUpload.db");
		Statement stmt;
		ResultSet rs;
		Map<String, String> rsResults;
		String query;
		try {
			stmt = ConnectionHelper.sqliteConnection.createStatement();
			if (null != testCaseId) {

				query = ("select * FROM " + tableName + " WHERE TESTCASEID = '" + testCaseId + "' ");
			} else {
				query = "select * FROM " + tableName + "";
			}
			System.out.println("The Query is" + query);
			rs = stmt.executeQuery(query);
			rsResults = new HashMap<String, String>();
			while (rs.next()) {
				ResultSetMetaData rsmd = rs.getMetaData();
				for (int i = 1; i <= rsmd.getColumnCount(); i++) {
					rsResults.put(rsmd.getColumnName(i), rs.getString(rsmd.getColumnName(i)));
				}
			}
			return rsResults;

		} catch (Exception e) {
			throw new Exception(e);
		}

	}
	
	public Map<String, String> getDatafromDb(String query)
			throws Exception {
		Statement stmt = null;
		stmt = getConnection();
		ResultSet rs;
		Map<String, String> rsResults;
		
		try {
			System.out.println("The Query is" + query);
			rs = stmt.executeQuery(query);
			rsResults = new HashMap<String, String>();
			while (rs.next()) {
				ResultSetMetaData rsmd = rs.getMetaData();
				for (int i = 1; i <= rsmd.getColumnCount(); i++) {
					rsResults.put(rsmd.getColumnName(i), rs.getString(rsmd.getColumnName(i)));
				}
			}
			return rsResults;

		} catch (Exception e) {
			throw new Exception(e);
		}

	}
	
	
	public Map<String, String> getDatafromDb1(String query)
			throws Exception {
		Statement stmt = null;
		stmt = getConnection();
		List<String>stringList = new ArrayList<String>();	
		ResultSet rs;
		Map<String, String> rsResults;
		
		try {
			System.out.println("The Query is" + query);
			rs = stmt.executeQuery(query);
			rsResults = new HashMap<String, String>();
			while (rs.next()) {
				ResultSetMetaData rsmd = rs.getMetaData();
				for (int i = 1; i <= rsmd.getColumnCount(); i++) {
					rsResults.put(rsmd.getColumnName(i), rs.getString(rsmd.getColumnName(i)));
				}
			}
			return rsResults;

		} catch (Exception e) {
			throw new Exception(e);
		}

	}
	
	public List<String> getRow(String Query) throws Exception {
		System.out.println("The Query is" + Query);
		Statement stmt = null;
		 stmt = getConnection();
		//Statement stmt = ConnectionHelper.oracleConnection.createStatement();
		
		ResultSet rs = stmt.executeQuery(Query);
		ResultSetMetaData rsmd = rs.getMetaData();
		List<String> Row=new ArrayList<String>();
		try {
			while (rs.next()) {
				for (int i = 1;i <= rsmd.getColumnCount(); i++) {
					if(rs.getString(rsmd.getColumnName(i))==null){
						Row.add("");
					}
					else{
						Row.add(rs.getString(rsmd.getColumnName(i)));
					}
				}
			}
		} catch (Exception e) {

			return null;
		}
		return Row;
	}
	
	public List<ArrayList<String>> getRows(String Query) throws Exception {
		System.out.println("The Query is" + Query);
		Statement stmt = null;
		 stmt = getConnection();
		//Statement stmt = ConnectionHelper.oracleConnection.createStatement();
		
		ResultSet rs = stmt.executeQuery(Query);
		ResultSetMetaData rsmd = rs.getMetaData();
		List<ArrayList<String>> Rows=new ArrayList<ArrayList<String>>();
		
		try {
			while (rs.next()) {
				ArrayList<String> Row=new ArrayList<String>();
				for (int i = 1;i <= rsmd.getColumnCount(); i++) {
					if(rs.getString(rsmd.getColumnName(i))==null){
						Row.add("");
					}
					else{
						Row.add(rs.getString(rsmd.getColumnName(i)));
					}
					
				}
				Rows.add(Row);
			}
		} catch (Exception e) {

			return null;
		}
		return Rows;
	}
}
