package com.optum.ram.atdd.common.utils;

public class DemoBean {

	private String subscriber_id;
	private String group_id;
	private String medicaid_id;
	private String firstName;
	private String lastName;
	private String Address_Line1;
	private String city;
	private String state;
	private String zip_code;
	// private String demoRecordCount;

	public String getSubscriber_id() {
		return subscriber_id;
	}

	public void setSubscriber_id(String object) {
		this.subscriber_id = object;
	}

	public String getGroup_id() {
		return group_id;
	}

	public void setGroup_id(String group_id) {
		this.group_id = group_id;
	}

	public String getMedicaid_id() {
		return medicaid_id;
	}

	public void setMedicaid_id(String medicaid_id) {
		this.medicaid_id = medicaid_id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress_Line1() {
		return Address_Line1;
	}

	public void setAddress_Line1(String address_Line1) {
		Address_Line1 = address_Line1;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip_code() {
		return zip_code;
	}

	public void setZip_code(String zip_code) {
		this.zip_code = zip_code;
	}
}