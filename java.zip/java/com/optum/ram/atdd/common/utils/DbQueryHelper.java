package com.optum.ram.atdd.common.utils;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

public class DbQueryHelper extends CSPCommonTestBase{

	static Logger LOG = Logger.getLogger("DbQueryHelper");

	/*
	 * Purpose :This method is used to clear the data in tables for their
	 * respective process Parameters:planName,process ReturnType:query
	 */

	public String backoutTables(String planName, String process) {
		String query = null;
		switch (process) {
		case "EligibilityUpload":
			query = "begin \n Delete from ram_membership_file_header;\n Delete from RAM_DEMOGRAPHICS_FILE_HEADER;\n Delete from RAM_DEMOGRAPHICS_FILE_DATA where plan_name ='"
					+ planName
					+ "';\n Delete from RAM_DEMOGRAPHICS_FILE_TRAILER;\n Delete from RAM_DEMOGRAPHICS_FILE_ERROR where plan_name='"
					+ planName
					+ "';\n Delete from RAM_ELIGIBILITY_FILE_HEADER;\n Delete from RAM_ELIGIBILITY_FILE_DATA where plan_name='"
					+ planName
					+ "';\n Delete from RAM_ELIGIBILITY_FILE_TRAILER;\n Delete from RAM_ELIGIBILITY_FILE_ERROR where plan_name='"
					+ planName + "'; end;";
			break;
		case "MemberSync":
			query = "begin \ndelete from ram_member_demographics where plan_name IN ('" + planName
					+ "');\n delete from ram_member_eligibility where plan_name IN ('" + planName + "');end;";
			break;
		case "Invoice":
			// query="delete from ram_invoice_detail where plan_name IN
			// ('"+planName+"');delete from ram_invoice_archive where plan_name
			// IN ('"+planName+"');delete from ram_invoice_header where
			// seq_revenue_id IN('100004','100088');"

			break;
		case "Payment":
			query = "delete from RAM_PAYMENT_ADDITIONAL_DATA where SEQ_PAYMENT_HEADER_ID in (SELECT seq_payment_header_id FROM RAM_PAYMENT_HEADER WHERE PLAN_NAME = '"
					+ planName
					+ "');delete from RAM_PAYMENT_HDR_TRLR where SEQ_PAYMENT_HEADER_ID in (SELECT seq_payment_header_id FROM RAM_PAYMENT_HEADER WHERE PLAN_NAME = '"
					+ planName + "');"
					+ "delete from RAM_PAYMENT_ARCHIVE where SEQ_PAYMENT_HEADER_ID in (SELECT seq_payment_header_id FROM RAM_PAYMENT_HEADER WHERE PLAN_NAME = '"
					+ planName
					+ "');delete from RAM_PAYMENT_REPORT where SEQ_PAYMENT_HEADER_ID in (SELECT seq_payment_header_id FROM RAM_PAYMENT_HEADER WHERE PLAN_NAME = '"
					+ planName + "');"
					+ "delete from RAM_PAYMENT_HISTORY where SEQ_PAYMENT_HEADER_ID in (SELECT seq_payment_header_id FROM RAM_PAYMENT_HEADER WHERE PLAN_NAME = '"
					+ planName + "');"
					+ "delete from RAM_PAYMENT_STAGE where SEQ_PAYMENT_HEADER_ID in (SELECT seq_payment_header_id FROM RAM_PAYMENT_HEADER WHERE PLAN_NAME = '"
					+ planName + "');"
					+ "delete from RAM_PAYMENT_SUPPLEMENTARY where SEQ_PAYMENT_HEADER_ID in (SELECT seq_payment_header_id FROM RAM_PAYMENT_HEADER WHERE PLAN_NAME = '"
					+ planName + "');"
					+ "delete from RAM_PAYMENT_TRANS_ENTITY where SEQ_PAYMENT_TRANS_SET_ID in (SELECT SEQ_PAYMENT_TRANS_SET_ID from RAM_PAYMENT_TRANSACTION_SET where SEQ_PAYMENT_HEADER_ID in (SELECT seq_payment_header_id FROM RAM_PAYMENT_HEADER WHERE PLAN_NAME = '"
					+ planName + "'));"
					+ "DELETE FROM RAM_PAYMENT_TRANSACTION_SET WHERE SEQ_PAYMENT_TRANS_SET_ID in (SELECT SEQ_PAYMENT_TRANS_SET_ID from RAM_PAYMENT_TRANSACTION_SET where SEQ_PAYMENT_HEADER_ID in (SELECT seq_payment_header_id FROM RAM_PAYMENT_HEADER WHERE PLAN_NAME = '"
					+ planName + "'));"
					+ "DELETE from RAM_PAYMENT_DETAIL where SEQ_PAYMENT_HEADER_ID in (SELECT seq_payment_header_id FROM RAM_PAYMENT_HEADER WHERE PLAN_NAME = '"
					+ planName + "');"
					+ "DELETE from RAM_PAYMENT_HEADER where SEQ_PAYMENT_HEADER_ID in (SELECT seq_payment_header_id FROM RAM_PAYMENT_HEADER WHERE PLAN_NAME = '"
					+ planName + "');";

			break;
		case "Recon":
			query = "delete ram_reconciliation_archive where plan_name IN ('" + planName
					+ "');delete ram_reconciliation_detail where plan_name IN ('" + planName + "');";
			break;
		case "Rates":
			 query="delete ram_rate_categ_matrix where company_code ='UHGVA';delete ram_rate_matrix where company_code = '"+planName+"' and seq_revenue_id IN('110054','110055','110056');"
			 		+ "delete ram_categ_plancode_matrix where company_code ='"+planName+"';"
			 				+ "deleteweb.ram_rate_upload_header where company_code='"+planName+"'";
			break;

		}
		LOG.info("The SQL Query is" + query);
		return query;
	}

	/*
	 * Purpose : This method used to create the select queries &return the Query
	 * to be executed Parameters: tableName,planName Return Type: query
	 */

	public String selectQuery(String tableName, String planName) {
		String query;
		if (planName == null) {
			query = "select * from " + tableName + "";

		} else {

			query = "select * from " + tableName + " Where plan_name='" + planName + "'";
		}
		LOG.info("The Returned Query is" + query);
		return query;
	}

	/*
	 * Purpose : This method used to create the queries with where condition and
	 * return the output to be executed Parameters: tableName,where Return Type:
	 * query
	 */

	public String selectQueryWhere(String tableName, String where) {

		String query = "select * from " + tableName + " Where " + where + "";
		LOG.info("The Returned Query is" + query);
		return query;

	}

	/*
	 * Purpose : This method used to build the queries for Aggregate functions
	 * in the Database Parameters: tableName,function,where,column_name Return
	 * Type: output
	 */

	public String aggregate_function(String tableName, String function, String where) {
		String query = null;
		switch (function) {
		case "Count":
			query = "select count(*) from " + tableName + " Where " + where + "";

			break;
		case "Sum":
			// query="select SUM("+column_name+") from "+tableName+" Where
			// "+where+"";

		}
		LOG.info("The Returned Query is" + query);
		return query;

	}

	/*
	 * Purpose : This method used to execute the Sub-queries in the Database &
	 * returns the output query that need to be executed in db Parameters:
	 * tableName,function,where,column_name Return Type: output
	 */

	public String subQuery(String outerTable, String keyColumn, String InnerTable, String outerQryCond,
			String InnerQryCond, String outputcolumn) {

		String query = "select " + outputcolumn + " from " + outerTable + " where " + outerQryCond + " and " + keyColumn
				+ " IN ((Select " + keyColumn + " from " + InnerTable + " where subscriber_id='" + InnerQryCond + "'))";

		return query;

	}

	/*
	 * Purpose :This method is used to get the count of records in the table
	 * Parameters:tableName,planName ReturnType:count
	 */

	public String unionOftableswithDistinctCount(String tableName1, String tableName2, String planName, String column) {

		String count = null;

		count = "select count(*) from (select distinct " + column + " from " + tableName1 + " where plan_name='"
				+ planName + "'" + " UNION " + "select distinct " + column + " from " + tableName2
				+ " where plan_name='" + planName + "')";
		LOG.info("The Returned Query is" + count);
		return count;

	}

	/**
	 * Generic method to get values in specific column from the database table
	 * 
	 * @param Query
	 * @return
	 * @throws SQLException
	 * @throws NullPointerException
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	public String getMultipleValues(String Query) throws SQLException, NullPointerException, ClassNotFoundException, IOException {
		System.out.println("The Query is" + Query);
		Statement stmt;
		 stmt= getConnection();
		// stmt = ConnectionHelper.oracleConnection.createStatement();
		ResultSet rs = stmt.executeQuery(Query);
		String Column_Value = null;
		try {
			while (rs.next()) {
				if (rs.getString(1).trim().length() > 0) {
					if (Column_Value == null)
						Column_Value = rs.getString(1);
					else
						Column_Value = Column_Value + "," + rs.getString(1);
				}
			}
		} catch (Exception e) {

			return null;
		}
		return Column_Value;
	}
	
	
	
	
}
