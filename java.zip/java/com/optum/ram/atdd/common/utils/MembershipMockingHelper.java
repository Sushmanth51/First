package com.optum.ram.atdd.common.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MembershipMockingHelper {

	private class Layout {
		@SuppressWarnings("unused")
		String fieldName = "";
		int fromPosition = -1;
		int toPosition = -1;
	}

	private Map<String, Layout> demographicsLayout = null;
	private Map<String, Layout> eligibilityLayout = null;

	private static final String DEMOGRAPHICS = "DEMO";
	private static final String ELIGIBILITY = "ELIG";
	private static final String DEMOGRAPHICS_LAYOUT_FILE = "src/main/resources/eligibilityUpload/layouts/StdDemoFileLayout.txt";
	private static final String ELIGIBILITY_LAYOUT_FILE = "src/main/resources/eligibilityUpload/layouts/StdEligFileLayout.txt";
	private static final String CLASS_ID = "CLASS_ID";
	private static final String SUBGROUP_ID = "SUBGROUP_ID";
	private static final String PLAN_CODE = "PLAN_CODE";
	private static final String GENDER = "GENDER";
	private static final String COUNTY = "COUNTY";
	private static final String EFFECTIVE_DATE = "EFFECTIVE_DATE";
	private static final String TERM_DATE = "TERM_DATE";
	private static final String SUBSCRIBER_ID = "SUBSCRIBER_ID";
	private static final String MEDICAID_ID = "MEDICAID_ID";
	private static final String FIRST_NAME = "FIRST_NAME";
	private static final String LAST_NAME = "LAST_NAME";
	private static final String COMMENT = "--";
	private static final String COMMA = ",";
	private static final String STRING = "S";
	private static final String NUMBER = "N";
	private static final String DATE = "D";
	private static final String YES = "Y";
	private static final String NO = "N";
	private static final String PIPE = "|";
	private static final String SPACE = " ";
	private static final String EMPTY = "";
	private static final String HEADER = "H";
	private static final String TRAILER = "T";
	private static final String DEFAULT = "DEFAULT";
	private static final int FIELD_NAME = 0;
	private static final int FROM_POSITION = 1;
	private static final int TO_POSITION = 2;
	private static final int DATA_TYPE = 3;
	private static final int REQUIRED = 4;
	private static final int LAYOUT_LENGTH = 5;
	private static final String ADDRESS_LINE_1 = "ADDRESS_LINE_1";
	private static final String CITY = "CITY";
	private static final String STATE = "STATE";
	private static final String ZIP_CODE = "ZIP_CODE";
	private static final String GROUP_ID = "GROUP_ID";
	
	Set<String> existingSubscriberIds = new HashSet<String>();

	/**
	 * @param eligrec
	 * @return boolean
	 * Method for mandatory check for ELIG records
	 */
	private boolean eligMandatoryDataCheck(Map<String, String> eligrec) {
		if (!eligrec.get(SUBGROUP_ID).equals(SPACE) && !eligrec.get(EFFECTIVE_DATE).equals(SPACE) && !eligrec.get(CLASS_ID).equals(SPACE)
				&& !eligrec.get(TERM_DATE).equals(SPACE)) {
			return true;
		}
		return false;
	}

	/**
	 * @param eligrec
	 * @return boolean
	 * Method for mandatory check for DEMO records
	 */
	private boolean demoMandatoryDataCheck(Map<String, String> demoRecord) {
		if (!demoRecord.get(SUBSCRIBER_ID).equals(SPACE) && !demoRecord.get(MEDICAID_ID).equals(SPACE)
				&& !demoRecord.get(FIRST_NAME).equals(SPACE) && !demoRecord.get(LAST_NAME).equals(SPACE)) {
			if (demoRecord.get(MEDICAID_ID).equalsIgnoreCase("UNKNOWN")
					|| demoRecord.get(MEDICAID_ID).equalsIgnoreCase("VOID")) {
				return false;
			}
			return true;
		}
		return false;
	}

	/**
	 * Iterate through each field in the layout and create a map of all fields
	 * from the source file.
	 * @param layoutHolder
	 * @param line
	 * @return
	 */
	private static Map<String, String> getRecord(String line) throws Exception {
		Map<String, Layout> layoutHolder = null;
		MembershipMockingHelper mocking = new MembershipMockingHelper();

		// Retrieve the layout.
		layoutHolder = mocking.getLayout(line);

		// Create record.
		Map<String, String> record = new HashMap<String, String>();
		Set<String> fields = layoutHolder.keySet();
		String planCode = "";
		for (String field : fields) {
			Layout layout = layoutHolder.get(field);
			String fieldValue = line.substring(layout.fromPosition - 1, layout.toPosition);
			fieldValue = EMPTY.equals(fieldValue.trim()) ? SPACE : fieldValue.trim();
			fieldValue = fieldValue.replace(PIPE, SPACE);
			record.put(field, fieldValue);

			// Plan code is concatenation of CLASS_ID and SUBGROUP_ID.
			if (CLASS_ID.equals(field) || SUBGROUP_ID.equals(field)) {
				if (CLASS_ID.equals(field)) {
					planCode = fieldValue.trim() + planCode.trim();
				} else {
					planCode = fieldValue.trim();
				}

			}
		}

		// If plan code value is null or empty, use 'DEFAULT' as the value.
		if (planCode.toString().equals(EMPTY)) {
			planCode = DEFAULT;
		}

		record.put(PLAN_CODE, planCode.toString());
		return record;
	}

	/**
	 * This method reads a layout file.
	 * 
	 * @return Map<String, Layout> - A map containing layout objects with name,
	 *         from position and to position fields.
	 * @throws Exception
	 */
	private Map<String, Layout> getLayout(String recordLine) throws Exception {
		Map<String, Layout> layoutHolder = null;

		if (recordLine.startsWith(DEMOGRAPHICS)) {
			if (demographicsLayout != null) {
				layoutHolder = demographicsLayout;
			} else {
				// Initialize layout.
				demographicsLayout = getRecordLayout(new File(DEMOGRAPHICS_LAYOUT_FILE));
				layoutHolder = demographicsLayout;
			}
		} else if (recordLine.startsWith(ELIGIBILITY)) {
			if (eligibilityLayout != null) {
				layoutHolder = eligibilityLayout;
			} else {
				// Initialize layout.
				eligibilityLayout = getRecordLayout(new File(ELIGIBILITY_LAYOUT_FILE));
				layoutHolder = eligibilityLayout;
			}
		} else {
			throw new Exception("Invalid record type. Expected DEMO or ELIG. Found [" + recordLine + "]");
		}
		return layoutHolder;
	}

	/**
	 * This method parses a text layout file, and validates each field to ensure
	 * values are valid. Requirements: 1. Comment lines begin with 2 hyphens. 2.
	 * Blank lines are allowed. 3. Field values should not begin or end with a
	 * space. 4. Data types can be S-String, N-Number, D-Date. 5. Length should
	 * only be a number. 6. Values for "Required" field can only be Y-Yes, N-No.
	 * 
	 * @param layoutFile
	 *            - A text file that has the validation values for each field.
	 * @return String[] - A list containing fields and their layout values.
	 * @throws Exception
	 */
	private Map<String, Layout> getRecordLayout(File layoutFile) throws Exception {
		BufferedReader reader = null;

		Map<String, Layout> layoutHolder = new HashMap<String, Layout>();
		try {
			// InputStream is =
			// this.getClass().getClassLoader().getResourceAsStream(layoutFile.getName());
			reader = new BufferedReader(new FileReader(layoutFile));
			String line = null;
			while ((line = reader.readLine()) != null) {
				// Skip blank or comment lines.
				if (line.trim().equals(EMPTY) || line.trim().startsWith(COMMENT)) {
					continue;
				}
				// Get field.
				String[] fieldLayout = line.split(COMMA);

				// Layout fields should be of size 5.
				if (fieldLayout.length != LAYOUT_LENGTH) {
					throw new IllegalArgumentException("Invalid layout. Expected [" + LAYOUT_LENGTH
							+ "] tokens. Found [" + fieldLayout.length + "]");
				} else {
					// Remove space, if any, from field value.
					for (int i = 0; i < fieldLayout.length; i++) {
						fieldLayout[i] = fieldLayout[i].trim();
					}

					// Validate each field to ensure it contains a valid value.
					// 1. Valid Data type.
					if (!(fieldLayout[DATA_TYPE].equals(STRING) || fieldLayout[DATA_TYPE].equals(NUMBER)
							|| fieldLayout[DATA_TYPE].equals(DATE))) {
						throw new IllegalArgumentException(
								"Invalid Layout Configuration. Field [" + fieldLayout[FIELD_NAME]
										+ "] Expected Datatype [S,N,D]. Found [" + fieldLayout[DATA_TYPE] + "].");
					}

					// 2. Valid from and to position.
					try {
						Integer.parseInt(fieldLayout[FROM_POSITION]);
						Integer.parseInt(fieldLayout[TO_POSITION]);
					} catch (Exception e) {
						throw new IllegalArgumentException("Invalid Layout Configuration. Field ["
								+ fieldLayout[FIELD_NAME] + "] Expected a number. Found [" + fieldLayout[FROM_POSITION]
								+ " and " + fieldLayout[TO_POSITION] + "].");
					}

					// 3. Valid required value.
					if (!(fieldLayout[REQUIRED].equals(YES) || fieldLayout[REQUIRED].equals(NO))) {
						throw new IllegalArgumentException("Invalid Layout Configuration. Field ["
								+ fieldLayout[FIELD_NAME] + "] Expected [Y,N]. Found [" + fieldLayout[REQUIRED] + "].");
					}
				}

				// Store the layout field
				Layout record = new Layout();
				record.fieldName = fieldLayout[FIELD_NAME].trim();
				record.fromPosition = Integer.parseInt(fieldLayout[FROM_POSITION].trim());
				record.toPosition = Integer.parseInt(fieldLayout[TO_POSITION].trim());
				layoutHolder.put(fieldLayout[FIELD_NAME].trim(), record);
			}
		} catch (FileNotFoundException e) {
			throw new Exception("File [" + layoutFile.getPath() + "] not found.");
		} catch (IOException e) {
			throw new Exception("IO Exception. " + e.toString());
		} catch (IllegalArgumentException e) {
			throw new Exception(e.toString());
		} finally {
			try {
				if (reader != null) {
					reader.close();
				}
			} catch (IOException e) {
				System.out.println("Warning: Error when closing files.");
			}
		}
		return layoutHolder;
	}

	/**
	 * @param mockedRecords
	 * @param memFilePath
	 * @throws Exception
	 * Method to create actual Mocked file with new name
	 */
	public void createMockedFile(Map<String, List<String>> mockedRecords, String memFilePath)
			throws Exception {

		try {
			Path filePath = Paths.get(memFilePath);
			List<String> lines = Files.readAllLines(filePath, StandardCharsets.UTF_8);
				for (Entry<String, List<String>> rec : mockedRecords.entrySet()) {
					lines.add(lines.size() - 1, rec.getKey());
					List<String> eligRec = rec.getValue();
					for (String s : eligRec) {
						lines.add(lines.size() - 1, s);
					}
				}
			
				//trailer = new StringBuilder(lines.get(lines.size()-1));
/*				//TOTAL_RECORD_COUNT
				System.out.println(leftPadding0(String.valueOf(Integer.parseInt(trailer.substring(1, 16))),15));
				//MEMBERSHIP_RECORD_COUNT
				System.out.println(leftPadding0(String.valueOf(Integer.parseInt(trailer.substring(16, 31))),15));*/
				
				/*System.out.println(leftPadding0(String.valueOf(lines.size()),15));
				System.out.println(leftPadding0(String.valueOf(lines.size()-2),15));*/
				lines.remove(lines.size()-1);
				lines.add("T"+leftPadding0(String.valueOf(lines.size()+1),15)+leftPadding0(String.valueOf(lines.size()-1),15));
						
			Files.write(filePath, lines, StandardCharsets.UTF_8);
			existingSubscriberIds.clear();
			
		} catch (FileNotFoundException e) {
			throw new Exception("File [" + memFilePath + "] not found.");
		} catch (IOException e) {
			throw new Exception("Error while processing [" + memFilePath + "].");
		}

	}
	
	public static String leftPadding0(String str, int num) {
		return String.format("%1$" + num + "s", str).replace(' ', '0');
	}

	/**
	 * @param str
	 * @param num
	 * @return String
	 * Method to PAD spaces for string
	 */
	public static String rightPadding(String str, int num) {
		return String.format("%1$-" + num + "s", str);
	}

	/**
	 * @param invoiceParam
	 * @param mockedRecords
	 * @param memFilePath
	 * @param plan
	 * @param groupId
	 * @param mockedTempFile 
	 * @return
	 * @throws Exception
	 * Method to create Mock data for IKM
	 */
	public Map<String, List<String>> createMockDataforIKM(String invoiceParam,
			Map<String, List<String>> mockedRecords, String memFilePath, String plan, String groupId, String mockedTempFile) throws Exception {

		List<String> eligList;
		String member;
		StringBuilder memBuilder;
		StringBuilder eligBuilder;
		Map<String, Layout> layoutHolder = null;
		Layout layout;
		boolean chkFlag;

		String[] invoiceParams = invoiceParam.split(",");

		for (int i = 0; i < invoiceParams.length; i++) {
			chkFlag = false;
			member = null;
			memBuilder = null;
			eligBuilder = null;
			eligList = new ArrayList<String>();

			Map<String, List<String>> tempMockRec = new HashMap<String, List<String>>();
			tempMockRec = prepareDataForMocking(memFilePath, plan, groupId, tempMockRec);
			if (!tempMockRec.isEmpty()) {

				for (Entry<String, List<String>> entry : tempMockRec.entrySet()) {
					member = entry.getKey();
					eligList = entry.getValue();
				}
				memBuilder = new StringBuilder(member);

				if (invoiceParams[i].equalsIgnoreCase(PLAN_CODE)) {
					eligBuilder = new StringBuilder(eligList.get(0));
					layoutHolder = getLayout(eligBuilder.toString());
					layout = layoutHolder.get(CLASS_ID);
					eligBuilder.replace(layout.fromPosition - 1, layout.toPosition,
							rightPadding("", layout.toPosition - layout.fromPosition + 1));
					layout = layoutHolder.get(SUBGROUP_ID);
					eligBuilder.replace(layout.fromPosition - 1, layout.toPosition,
							rightPadding("", layout.toPosition - layout.fromPosition + 1));
					eligList.remove(0);
					eligList.add(eligBuilder.toString());
					chkFlag = true;

				} else if (invoiceParams[i].equalsIgnoreCase(GENDER)) {
					layoutHolder = getLayout(member);
					layout = layoutHolder.get(GENDER);
					memBuilder.replace(layout.fromPosition - 1, layout.toPosition,
							rightPadding("", layout.toPosition - layout.fromPosition + 1));
					chkFlag = true;
				} else if (invoiceParams[i].equalsIgnoreCase(COUNTY)){
					eligBuilder = new StringBuilder(eligList.get(0));
					layoutHolder = getLayout(eligBuilder.toString());
					layout = layoutHolder.get("COUNTY_CODE");
					eligBuilder.replace(layout.fromPosition - 1, layout.toPosition,
							rightPadding("", layout.toPosition - layout.fromPosition + 1));
					eligList.remove(0);
					eligList.add(eligBuilder.toString());
					chkFlag = true;
				}
				if (chkFlag) {
					removeDataFromFile(member, mockedTempFile);
					mockedRecords.put(memBuilder.toString(), eligList);
				}
			}
		}
		return mockedRecords;
	}

	private void removeDataFromFile(String member, String mockedTempFile) {

		try{
			Path sourcePath = Paths.get(mockedTempFile);
			List<String> lines = Files.readAllLines(sourcePath, StandardCharsets.UTF_8);

			for(int i=0; i<=lines.size(); i++){
				if(lines.get(i).contains(member.substring(4, 13))){
					lines.remove(i);
					while(lines.get(i).startsWith("ELIG")){
						lines.remove(i);
					}
					break;
				}
			}
			Files.write(sourcePath, lines, StandardCharsets.UTF_8);
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/**
	 * @param memberKey
	 * @param mockedRecords
	 * @param memFilePath
	 * @param plan
	 * @param groupId
	 * @param mockedTempFile 
	 * @return
	 * @throws Exception
	 * Method to create Mock data for MKM
	 */
	public Map<String, List<String>> createMockDataforMKM(String memberKey, Map<String, List<String>> mockedRecords,
			String memFilePath, String plan, String groupId, String mockedTempFile) throws Exception {
		List<String> eligList;
		String member;
		StringBuilder memberBuilder;
		Map<String, Layout> layoutHolder = null;
		Layout layout;

		String[] memberKeys = memberKey.split("\\|\\|");

		for (int i = 0; i < memberKeys.length; i++) {
			member = null;
			memberBuilder = null;
			eligList = new ArrayList<String>();
			Map<String, List<String>> tempMockRec = new HashMap<String, List<String>>();
			tempMockRec = prepareDataForMocking(memFilePath, plan, groupId, tempMockRec);
			if (!tempMockRec.isEmpty()) {

				for (Entry<String, List<String>> entry : tempMockRec.entrySet()) {
					member = entry.getKey();
					eligList = entry.getValue();
				}
				layoutHolder = getLayout(member);
				memberBuilder = new StringBuilder(member);
				layout = layoutHolder.get(memberKeys[i]);
				memberBuilder.replace(layout.fromPosition - 1, layout.toPosition,
						rightPadding("", layout.toPosition - layout.fromPosition + 1));
				mockedRecords.put(memberBuilder.toString(), eligList);
				removeDataFromFile(member, mockedTempFile);
			}
		}
		return mockedRecords;
	}

	/**
	 * @param memberKey
	 * @param mockedRecords
	 * @param memFilePath
	 * @param plan
	 * @param groupId
	 * @return
	 * @throws Exception
	 * Method to Create Mock record for DMI
	 */
	public Map<String, List<String>> createMockDataforDMI(String memberKey, Map<String, List<String>> mockedRecords,
			String memFilePath, String plan, String groupId) throws Exception {

		String memOne;
		String memTwo;
		List<String> eligList;
		Map<String, Layout> layoutHolder = null;
		StringBuilder memTwobuilder;
		Layout layout;

		String[] memberKeys = memberKey.split("\\|\\|");

		for (int i = 0; i < memberKeys.length; i++) {
			memOne = null;
			memTwo = null;
			memTwobuilder = null;

			Map<String, List<String>> tempMockRec = new HashMap<String, List<String>>();
			for (int j = 0; j < 2; j++) {
				tempMockRec = prepareDataForMocking(memFilePath, plan, groupId, tempMockRec);
			}
			eligList = new ArrayList<String>();
			boolean chk = false;
			if (!tempMockRec.isEmpty()) {
				for (Entry<String, List<String>> entry : tempMockRec.entrySet()) {
					if (!chk) {
						memOne = entry.getKey();
						chk = true;
					} else {
						memTwo = entry.getKey();
						eligList = entry.getValue();
						break;
					}
				}

				layoutHolder = getLayout(memTwo);
				layout = layoutHolder.get(memberKeys[i]);
				memTwobuilder = new StringBuilder(memTwo);
				memTwobuilder.replace(layout.fromPosition - 1, layout.toPosition, rightPadding(
						getRecord(memOne).get(memberKeys[i]), layout.toPosition - layout.fromPosition + 1));

				layout = layoutHolder.get(SUBSCRIBER_ID);
				StringBuffer memOneSubsId = new StringBuffer(getRecord(memTwo).get(SUBSCRIBER_ID));
				memOneSubsId.setCharAt(memOneSubsId.length() - 1, '*');
				memTwobuilder.replace(layout.fromPosition - 1, layout.toPosition,
						rightPadding(memOneSubsId.toString(), layout.toPosition - layout.fromPosition + 1));

				mockedRecords.put(memTwobuilder.toString(), eligList);
			}
		}
		return mockedRecords;
	}

	/**
	 * @param memFilePath
	 * @param plan
	 * @param groupId
	 * @param finalMockedRec
	 * @return
	 * @throws Exception
	 * Method to Pick data for mocking
	 */
	private Map<String, List<String>> prepareDataForMocking(String memFilePath, String plan, String groupId, Map<String, List<String>> mockedRecords) throws Exception {
		mockedRecords = getMockedRecords(memFilePath, plan, groupId, mockedRecords);		
		return mockedRecords;
	}

	/**
	 * @param memFilePath
	 * @param plan
	 * @param groupId
	 * @param recTobeMocked
	 * @return
	 * @throws Exception
	 * Method to Pick data for mocking
	 */
	private Map<String, List<String>> getMockedRecords(String memFilePath, String plan, String groupId, Map<String, List<String>> mockedRecords) throws Exception {
		BufferedReader reader = null;
		String line = null;
		String subscriberId = null;


		Map<String, String> demoRecord = new HashMap<String, String>();
		String demoRec = "";
		List<String> eligRec = new ArrayList<String>();
		try {
			reader = new BufferedReader(new FileReader(new File(memFilePath)));
			while ((line = reader.readLine()) != null) {

				if (EMPTY.equals(line.trim()) || line.startsWith(HEADER) || line.startsWith(TRAILER)) {
					continue;
				}
				if (line.startsWith(DEMOGRAPHICS)) {
					if (!eligRec.isEmpty()) {
						break;
					}
					demoRecord = getRecord(line);
					if (demoMandatoryDataCheck(demoRecord)
							&& !existingSubscriberIds.contains(demoRecord.get(SUBSCRIBER_ID))) {
						subscriberId = demoRecord.get(SUBSCRIBER_ID);
						demoRec = line;
					}
				} else if (line.startsWith(ELIGIBILITY)) {
					if (Arrays.asList(groupId.split(",")).contains(line.substring(32, 40).trim())) {
						Map<String, String> eligrec = getRecord(line);
						if (eligMandatoryDataCheck(eligrec) && !demoRec.isEmpty()) {
							eligRec.add(line);
						}
					}
				} else {
					throw new Exception("Invalid record type. Expected DEMO or ELIG. Found [" + line + "]");
				}
			}
			if(!eligRec.isEmpty()){
				mockedRecords.put(demoRec, eligRec);
			}
		} catch (Exception e) {
			throw new Exception(e);
		} finally {
			reader.close();
		}
		if(!mockedRecords.isEmpty()){			
			existingSubscriberIds.add(subscriberId);
		}
		return mockedRecords;
	}

	/**
	 * @param mockedRecords
	 * @param memFilePath
	 * @param plan
	 * @param groupId
	 * @param mockedTempFile 
	 * @return
	 * @throws Exception
	 * Method to Create Mock record for NRF
	 */
	public Map<String, List<String>> createMockDataforNRF(Map<String, List<String>> mockedRecords, String memFilePath,
			String plan, String groupId, String mockedTempFile) throws Exception {
		List<String> eligList = new ArrayList<>();
		String member = null;
		StringBuilder eligBuilder;
		Map<String, Layout> layoutHolder = null;
		Layout layout;

		Map<String, List<String>> tempMockRec = new HashMap<String, List<String>>();
		tempMockRec = prepareDataForMocking(memFilePath, plan, groupId, tempMockRec);
		if (!tempMockRec.isEmpty()) {

			for (Entry<String, List<String>> entry : tempMockRec.entrySet()) {
				member = entry.getKey();
				eligList = entry.getValue();
			}
			layoutHolder = getLayout(eligList.get(0));
			eligBuilder = new StringBuilder(eligList.get(0));
			layout = layoutHolder.get(CLASS_ID);
			eligBuilder.replace(layout.fromPosition - 1, layout.toPosition,
					rightPadding("XXXX", layout.toPosition - layout.fromPosition + 1));
			layout = layoutHolder.get(SUBGROUP_ID);
			eligBuilder.replace(layout.fromPosition - 1, layout.toPosition,
					rightPadding("XXXX", layout.toPosition - layout.fromPosition + 1));
			eligList.remove(0);
			eligList.add(eligBuilder.toString());

			mockedRecords.put(member, eligList);
			removeDataFromFile(member, mockedTempFile);
		}
		return mockedRecords;
	}


	/**
	 * @param fieldTobeBlank
	 * @param mockedRecords
	 * @param memFilePath
	 * @param plan
	 * @param groupId
	 * @param mockedTempFile
	 * @return
	 * @throws Exception
	 */
	public Map<String, List<String>> createMockDataForErrorTables(String[] fieldTobeBlank,
			Map<String, List<String>> mockedRecords, String memFilePath, String plan, String groupId,
			String mockedTempFile) throws Exception {
		List<String> eligList;
		String member;
		StringBuilder memberBuilder;
		Map<String, Layout> layoutHolder = null;
		Layout layout;
		Map<String, List<String>> validRec = new HashMap<String, List<String>>();

		for (int i = 0; i < fieldTobeBlank.length; i++) {
			member = null;
			memberBuilder = null;
			eligList = new ArrayList<String>();
			Map<String, List<String>> tempMockRec = new HashMap<String, List<String>>();
			validRec = getValidRecord(tempMockRec, memFilePath, plan, groupId, mockedTempFile);

			if (!validRec.isEmpty()) {
				for (Entry<String, List<String>> entry : validRec.entrySet()) {
					member = entry.getKey();
					eligList = entry.getValue();
				}

				layoutHolder = getLayout(member);// 1
				memberBuilder = new StringBuilder(member);
				layout = layoutHolder.get(fieldTobeBlank[i]);
				memberBuilder.replace(layout.fromPosition - 1, layout.toPosition,
						rightPadding("", layout.toPosition - layout.fromPosition + 1));

				mockedRecords.put(memberBuilder.toString(), eligList);
				removeDataFromFile(member, mockedTempFile);

			}
		}
		System.out.println("The Mocked member is" + mockedRecords);
		return mockedRecords;
	}

	/**
	 * @Purpose :Verify whether the record has all the Situational values or
	 *          not.If chkflag is true, it will pick the next record before
	 *          mocking the file
	 * @param tempMockRec
	 * @param memFilePath
	 * @param plan
	 * @param groupId
	 * @param mockedTempFile
	 * @return
	 * @throws Exception
	 */
	private Map<String, List<String>> getValidRecord(Map<String, List<String>> tempMockRec, String memFilePath,
			String plan, String groupId, String mockedTempFile) throws Exception {
		Map<String, List<String>> validRec = new HashMap<String, List<String>>();
		boolean chkFlag = true;
		String member;
		List<String> eligList;
		while (chkFlag) {
			tempMockRec = new HashMap<String, List<String>>();
			tempMockRec = prepareDataForMocking(memFilePath, plan, groupId, tempMockRec);
			for (Entry<String, List<String>> entry : tempMockRec.entrySet()) {
				member = entry.getKey();
				eligList = entry.getValue();

				Map<String, String> memRec = getRecord(member);

				if (!memRec.get(ADDRESS_LINE_1).equals(SPACE) && !memRec.get(CITY).equals(SPACE)
						&& !memRec.get(STATE).equals(SPACE) && !memRec.get(ZIP_CODE).equals(SPACE)) {
					validRec = tempMockRec;
					chkFlag = false;
				}

			}
		}
		return validRec;
	}

	public Map<String, List<String>> createMockDataforErrorEligRecord(String[] invoiceParam,
			Map<String, List<String>> mockedRecords, String memFilePath, String plan, String groupId,
			String mockedTempFile) throws Exception {

		//
		List<String> eligList;
		String member;
		StringBuilder memBuilder;
		StringBuilder eligBuilder;
		Map<String, Layout> layoutHolder = null;
		Layout layout;
		boolean chkFlag;

		for (int i = 0; i < invoiceParam.length; i++) {
			chkFlag = false;
			member = null;
			memBuilder = null;
			eligBuilder = null;
			eligList = new ArrayList<String>();

			Map<String, List<String>> tempMockRec = new HashMap<String, List<String>>();
			tempMockRec = prepareDataForMocking(memFilePath, plan, groupId, tempMockRec);
			if (!tempMockRec.isEmpty()) {

				for (Entry<String, List<String>> entry : tempMockRec.entrySet()) {
					member = entry.getKey();
					eligList = entry.getValue();
				}
				memBuilder = new StringBuilder(member);

				if (invoiceParam[i].equalsIgnoreCase(EFFECTIVE_DATE)) {
					eligBuilder = new StringBuilder(eligList.get(0));
					layoutHolder = getLayout(eligBuilder.toString());
					layout = layoutHolder.get(EFFECTIVE_DATE);
					eligBuilder.replace(layout.fromPosition - 1, layout.toPosition,
							rightPadding("", layout.toPosition - layout.fromPosition + 1));
					eligList.remove(0);
					eligList.add(eligBuilder.toString());
					chkFlag = true;

				} else if (invoiceParam[i].equalsIgnoreCase(TERM_DATE)) {
					eligBuilder = new StringBuilder(eligList.get(0));
					layoutHolder = getLayout(eligBuilder.toString());
					layout = layoutHolder.get(TERM_DATE);
					eligBuilder.replace(layout.fromPosition - 1, layout.toPosition,
							rightPadding("", layout.toPosition - layout.fromPosition + 1));
					eligList.remove(0);
					eligList.add(eligBuilder.toString());
					chkFlag = true;
				} else if (invoiceParam[i].equalsIgnoreCase(GROUP_ID)) {
					eligBuilder = new StringBuilder(eligList.get(0));
					layoutHolder = getLayout(eligBuilder.toString());
					layout = layoutHolder.get(GROUP_ID);
					eligBuilder.replace(layout.fromPosition - 1, layout.toPosition,
							rightPadding("", layout.toPosition - layout.fromPosition + 1));
					eligList.remove(0);
					eligList.add(eligBuilder.toString());
					chkFlag = true;
				}

				if (chkFlag) {
					removeDataFromFile(member, mockedTempFile);
					mockedRecords.put(memBuilder.toString(), eligList);
				}
			}

		}
		System.out.println("The Mocked member is" + mockedRecords);
		return mockedRecords;
	}

}
