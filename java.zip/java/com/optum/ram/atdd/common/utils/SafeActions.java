/*************************************** PURPOSE **********************************

 - This class contains all UserAction methods
*/

package com.optum.ram.atdd.common.utils;


import static org.testng.Assert.fail;

import java.util.Collections;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.Alert;
//import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.optum.ram.ramui.BaseSetup;



public class SafeActions extends Sync
{

	
	private static SafeActions safeActionsobj ;

	//Local WebDriver instance
	protected WebDriver driver;

	private static final Log log = LogFactory.getLog(SafeActions.class);

	
	//Constructor to initialize the local WebDriver variable with the WebDriver variable that,
	//has been passed from each PageParts Java class
	
	public static SafeActions getInstance(){
		if(null == safeActionsobj){
			safeActionsobj = new SafeActions(BaseSetup.driver);
		}
			return safeActionsobj;

	}
	
	
	public SafeActions(WebDriver driver)
	{
		super(driver);
		this.driver=driver;
	}
	/**
	 * 
	 * TODO scroll method to scroll the page down until expected element is visible	 *
	 * @param locator - locator value by which an element is located
	 * @param waitTime - Time to wait for an element
	 * @return - returns the text value from element
	 */
	public void scrollIntoElementView(By locator)
	{
		try
		{
			((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();",driver.findElement(locator));
		}
		catch(StaleElementReferenceException e)
		{			
			//log.error("Element with " + locator +"is not attached to the page document"+getStackTrace());
			Assert.fail("Element with " + locator +"is not attached to the page document");			
		}
	    catch (NoSuchElementException e)
		{	    	
			//log.error("Element " + locator + " was not found in DOM"+getStackTrace());	
			Assert.fail("Element "+ locator +" was not found in DOM");			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			log.error("Unable to scroll the page to find "+ locator+ "\n"+getStackTrace());
			Assert.fail("Unable to scroll the page to find "+ locator);			
		}
	}
	
		/**
	 * Method - Safe Method for User Click, waits until the element is loaded and then performs a click action
	 * @param locator
	 * @param waitTime
	 */
	public void safeClick(By locator, int optionWaitTime)
	{
		try
		{
			if(waitUntilClickable(locator, optionWaitTime))
			{
				scrollIntoElementView(locator);
				WebElement element = driver.findElement(locator);
				setHighlight(element);
				element.click();		
				log.info("Clicked on the element " + locator);
			}
			else
			{
				fail("Unable to click the element " + locator);
			}
		}
		catch(StaleElementReferenceException e)
		{
			//log.error("Element with " + locator + " is not attached to the page document"+getStackTrace());
			Assert.fail("Element with " + locator + " is not attached to the page document");
		}
		catch (NoSuchElementException e)
		{
			log.error("Element " + locator + " was not found in DOM"+getStackTrace());	
			Assert.fail("Element " + locator + " was not found in DOM");
		}
		catch(Exception e)
		{
			//log.error("Element " + locator + " was not clickable"+getStackTrace());		
			Assert.fail("Element " + locator + " was not clickable");
		}
	}
	
	/**
	 * Method - Safe Method for User Click using Actions.click, waits until the element is loaded and then performs a click action
	 * @param locator
	 * @param waitTime
	 */
	
	public void safeActionsClick(By locator,int waitTime)
	  {
	   try
	   {
	       if(isElementVisible(locator, waitTime))
	    {
	    	WebElement element=driver.findElement(locator);
	        setHighlight(element);
	        Actions builder = new Actions(driver);
	        builder.moveToElement(element).click().build().perform();
	        try {
	         Thread.sleep(2000);
	     } catch (InterruptedException e) {
	   //   log.error("Exception occurred while waiting"+getStackTrace());
	     }
	        log.info("Clicked on element " + locator);
	       }
	       else
	    {     
	     //log.error("Element "+locator+" was not visible to click "+ getStackTrace());
	     Assert.fail("Element "+locator+" was not visible to click");
	    }
	   }
	   catch(StaleElementReferenceException e)
	   {
	   // log.error("Element with " + locator + " is not attached to the page document"+getStackTrace());
	    Assert.fail("Element with " + locator + " is not attached to the page document");
	   }
	   catch (NoSuchElementException e)
	   {
	   // log.error("Element " + locator + " was not found in DOM"+getStackTrace()); 
	    Assert.fail("Element " + locator + " was not found in DOM");
	   }
	   catch(Exception e)
	   {
	   // log.error("Unable to click the cursor on " + locator + getStackTrace()); 
	    Assert.fail("Unable to click the cursor on " + locator);
	   }
	   
	  }

	/**
	 * Method - safeClearAndTypeCredential to used for enter credential
	 * @param locator
	 * @param text
	 * @param optionWaitTime
	 */
	public void safeClearAndTypeCredential(By locator, String text, int optionWaitTime)
	{
		try
		{
			//int waitTime =  getWaitTime(optionWaitTime);
			if(safeVerify(locator, optionWaitTime))
			{
				scrollIntoElementView(locator);
				WebElement element=driver.findElement(locator);
				setHighlight(element);
				//element.clear();
				//element.sendKeys(text);
				
   				JavascriptExecutor jse = (JavascriptExecutor)driver;
   				jse.executeScript("arguments[0].value='"+text+"';", element);
				log.info("Cleared the field and entered - '"+text+" in the element - " + locator);
			}
			else
			{			
			//	log.error("Unable to clear and enter " + text + " in field "+ locator+getStackTrace());
				Assert.fail("Unable to clear and enter " + text + " in field "+ locator);
			}
		}
		catch(StaleElementReferenceException e)
		{
			//log.error("Element with " + locator + " is not attached to the page document"+getStackTrace());
			Assert.fail("Element with " + locator + " is not attached to the page document");
		}
		catch (NoSuchElementException e)
		{
			//log.error("Element " + locator + " was not found in DOM"+getStackTrace());	
			Assert.fail("Element " + locator + " was not found in DOM");
		}
		catch(Exception e)
		{
			//log.error("Unable to clear and enter '" + text + "' text in field with locator -"+ locator+getStackTrace());
			Assert.fail("Unable to clear and enter '" + text + "' text in field with locator -"+ locator);
		}
	}
	
	
	/**
	 * Method - Safe Method for User Clear and Type, waits until the element is loaded and then enters some text
	 * @param locator
	 * @param sText
	 * @param waitTime
	 */
	public void safeClearAndType(By locator, String text, int optionWaitTime)
	{
		try
		{
			//int waitTime =  getWaitTime(optionWaitTime);
			if(safeVerify(locator, optionWaitTime))
			{
				scrollIntoElementView(locator);
				WebElement element=driver.findElement(locator);
				setHighlight(element);
				element.clear();
				element.sendKeys(text);
				log.info("Cleared the field and entered - '"+text+" in the element - " + locator);
			}
			else
			{			
			//	log.error("Unable to clear and enter " + text + " in field "+ locator+getStackTrace());
				Assert.fail("Unable to clear and enter " + text + " in field "+ locator);
			}
		}
		catch(StaleElementReferenceException e)
		{
			//log.error("Element with " + locator + " is not attached to the page document"+getStackTrace());
			Assert.fail("Element with " + locator + " is not attached to the page document");
		}
		catch (NoSuchElementException e)
		{
			//log.error("Element " + locator + " was not found in DOM"+getStackTrace());	
			Assert.fail("Element " + locator + " was not found in DOM");
		}
		catch(Exception e)
		{
			//log.error("Unable to clear and enter '" + text + "' text in field with locator -"+ locator+getStackTrace());
			Assert.fail("Unable to clear and enter '" + text + "' text in field with locator -"+ locator);
		}
	}

	/**
	 * Method - Safe Method for User Type, waits until the element is loaded and then enters some text
	 * @param locator
	 * @param sText
	 * @param waitTime
	 */
	public void safeType(By locator, String text, int optionWaitTime)
	{
		try
		{
			//int waitTime =  getWaitTime(optionWaitTime);
			if(safeVerify(locator, optionWaitTime))
			{
				scrollIntoElementView(locator);
				WebElement element=driver.findElement(locator);
				setHighlight(element);
				element.sendKeys(text);
			}
			else
			{
				//log.error("Unable to enter " + text + " in field " + locator+getStackTrace());
				Assert.fail("Unable to enter " + text + " in field " + locator);
			}
		}
		catch(StaleElementReferenceException e)
		{
			//log.error("Element with " + locator + " is not attached to the page document"+getStackTrace());
			Assert.fail("Element with " + locator + " is not attached to the page document");
		}
		catch (NoSuchElementException e)
		{
			//log.error("Element " + locator + " was not found in DOM"+getStackTrace());	
			Assert.fail("Element " + locator + " was not found in DOM");
		}
		catch(Exception e)
		{
			//log.error("Unable to enter '" + text + "' text in field with locator -"+ locator+getStackTrace());
			Assert.fail("Unable to enter '" + text + "' text in field with locator -"+ locator);
		}
	}
	/**
	 * Method - Method for switching to frame using any locator of the frame
	 * @param driver
	 * @param ParentFrame
	 * @param ChildFrame
	 */
	public void safeSwitchToFrame(By Framelocator, int waitTime)
	{
		try
		{
			if(safeVerify(Framelocator,waitTime))
			{
				WebElement Frame = driver.findElement(Framelocator);             
			    driver.switchTo().frame(Frame);
			    log.info("Navigated to frame with locator " + Framelocator);	
			}
			else
			{
			//	log.error("Unable to navigate to frame with locator " + Framelocator +getStackTrace());
				Assert.fail("Unable to navigate to frame with locator " + Framelocator );
			}
		}
		catch(NoSuchFrameException e)
		{
			//log.error("Unable to locate frame with locator " + Framelocator+getStackTrace());
			Assert.fail("Unable to locate frame with locator " + Framelocator);
		}
		catch(Exception e)
		{
			//log.error("Unable to navigate to frame with locator " + Framelocator +getStackTrace());
			Assert.fail("Unable to navigate to frame with locator " + Framelocator );
		}
	}
	
	
	/**
	 * Method - Method for switching back to webpage from frame
	 * @param driver
	 */
	public void safeSwitchToDefaultFrame()
	{
		try
		{
			driver.switchTo().defaultContent();
			log.info("Navigated to back to webpage from frame");
		}
		catch(Exception e)
		{
			//log.error("unable to navigate back to main webpage from frame"+getStackTrace());
			Assert.fail("unable to navigate back to main webpage from frame");
		}
	}
	/**
	 * Waits for an element till the timeout expires
	 * @param driver (WebDriver) The driver object to be used to wait and find the element
	 * @param bylocator (By) locator object of the element to be found
	 * @param waitTime (int) The time in seconds to wait until returning a failure
	 * @return - True (Boolean) if element is located within timeout period else false
	 */
    public boolean safeVerify(By locator, int waitTime)
	{    	
    	boolean bFlag = false;	
    	//nullifyImplicitWait();
    	log.info("Waiting for presence of element " + locator);
		try
		{
			
			WebDriverWait wait = new WebDriverWait(driver, waitTime);
			wait.until(ExpectedConditions.presenceOfElementLocated(locator)); 	
			if(driver.findElement(locator).isDisplayed()||driver.findElement(locator).isEnabled())
			{
				highlightElement(driver.findElement(locator));
				bFlag = true;
				log.info("Element " + locator + " is displayed");
			}
		}	
		
		catch (NoSuchElementException e)
		{
			log.info("Element " + locator + " was not found in DOM");			
		}
		catch (TimeoutException e)
		{
		//	log.info("Element " + locator + " was not displayed in time - "+waitTime+getStackTrace());
			Assert.fail("Element " + locator + "was not displayed in time - "+waitTime+getStackTrace());
		}
		catch (Exception e)
		{
		
			//log.error("Element " + locator + " is not displayed"+getStackTrace());
			Assert.fail("Element " + locator + " is not displayed");
		}
		return bFlag;
	}
	



	
	/**
	 * Method - Safe Method for User Select option from Drop down by option name, waits until the element is loaded and then selects an option from drop down
	 * @param locator
	 * @param sOptionToSelect
	 * @param waitTime
	 * @return - boolean (returns True when option is selected from the drop down else returns false)
	 * @throws Exception
	 */
	public void safeSelectOptionInDropDown(By locator, String optionToSelect)
	{ 
		try
		{
			List<WebElement> options = Collections.<WebElement>emptyList();
			//int waitTime =  getWaitTime(optionWaitTime);
			if(isElementPresent(locator))
			{		
				scrollIntoElementView(locator);
				WebElement selectElement = driver.findElement(locator); 
				setHighlight(selectElement);
				Select select = new Select(selectElement); 
				//Get a list of the options 
				options = select.getOptions(); 
				// For each option in the list, verify if it's the one you want and then click it
				if(!options.isEmpty())
				{
					for (WebElement option: options) 
					{ 
						if (option.getText().contains(optionToSelect))
						{ 
							option.click(); 
							log.info("Selected " + option + " from " + locator + " dropdown");
							break; 
						}
					}
				}
			}
			else
			{
				//log.error("Unable to select " + optionToSelect + " from " + locator + getStackTrace());
				Assert.fail("Unable to select " + optionToSelect + " from " + locator + getStackTrace());
			}
		}
		catch(StaleElementReferenceException e)
		{
			//log.error("Element with dropdown locator- " + locator + " or option to be selected -'"+optionToSelect+"' webelement is not attached to the page document"+getStackTrace());
			Assert.fail("Element with dropdown locator- " + locator + " or option to be selected -'"+optionToSelect+"' webelement is not attached to the page document"+getStackTrace());
		}
		catch (NoSuchElementException e)
		{
			//log.error("Element with dropdown locator- " + locator + " or option to be selected -'"+optionToSelect+"' webelement was not found in DOM"+getStackTrace());	
			Assert.fail("Element with dropdown locator- " + locator + " or option to be selected -'"+optionToSelect+"' webelement was not found in DOM"+getStackTrace());
		}
		catch(Exception e)
		{
			//log.error("Unable to select " + optionToSelect + " from " + locator + getStackTrace());
			Assert.fail("Unable to select " + optionToSelect + " from " + locator + getStackTrace());
		}
	}
	
	/**
	 * 
	 * This method is used to switch to windows based on provided number.
	 *
	 * @param num , Window number starting at 0
	 */
	public void switchToWindow(int num)
	{
		try
		{
			int numWindow = driver.getWindowHandles().size();
			String[] window = (String[])driver.getWindowHandles().toArray(new String[numWindow]);
			driver.switchTo().window(window[num]);
			log.info("Navigated successfully to window with sepcified number: "+num);
		}
		catch(NoSuchWindowException e)
		{
			//log.error("Window with sepcified number "+num+" doesn't exists. Please check the window number or wait until the new window appears"+getStackTrace());
			Assert.fail("Window with sepcified number  "+num+"doesn't exists. Please check the window number or wait until the new window appears");			
		}
		catch(Exception e)
		{
		//	log.error("Some exception occured while switching to new window with number: "+num+getStackTrace());
			Assert.fail("Some exception occured while switching to new window with number: "+num);			
		}
	}
	/**
	 * Method - Safe Method for User Click, waits until the element is loaded and then performs a click action
	 * @param locatorToClick
	 * @param locatorToCheck
	 * @param waitTime
	 * @return - boolean (returns True when click action is performed else returns false)
	 * @throws Exception
	 */
	public void safeWaitClick(By locatorToClick,By locatorToCheck, int waitElementToClick,int waitElementToCheck ) throws Exception 
	{
		boolean bResult = false;
        int iAttempts = 0;
        nullifyImplicitWait();
        WebDriverWait wait = new WebDriverWait(driver, waitElementToClick);
        WebDriverWait wait2 = new WebDriverWait(driver,waitElementToCheck);
        while(iAttempts < 3) 
        {
        	
            try 
            {
              	wait.until(ExpectedConditions.visibilityOfElementLocated(locatorToClick));
            	wait.until(ExpectedConditions.elementToBeClickable(locatorToClick));
    			WebElement element = driver.findElement(locatorToClick);
    			
    			if(element.isDisplayed())
    			{
    				setHighlight(element);
        			element.click();
        			waitForPageToLoad();
        			waitForJQueryProcessing(waitElementToCheck);
        			wait2.until(ExpectedConditions.visibilityOfElementLocated(locatorToCheck));
        			WebElement elementToCheck = driver.findElement(locatorToCheck);
        			if(elementToCheck.isDisplayed())
        			{
                        log.info("Clicked on element " + locatorToClick);
        				break;
        			}
        			else
        			{
        				Thread.sleep(1000);
        				continue;
        			}
    			}
            } 
            catch(Exception e) 
            {            	
            	log.info("Attempt: "+iAttempts +"\n Unable to click on element " + locatorToClick);
            }
            iAttempts++;
        }
        if (!bResult)
        {
        	Assert.fail("Unable to click on element " + locatorToClick);
        }
	}

	
	
	 /**
 	 * 
	 * TODO Safe method to get text from an element
	 *
	 * @param locator - locator value by which an element is located
	 * @param waitTime - Time to wait for an element
	 * @return - returns the text value from element
	 */
	public String safeGetText(By locator,int waitTime)
	{
		String sValue =null;
		try
		{
			if(safeVerify(locator, waitTime))
			{
				highlightElement(driver.findElement(locator));
				sValue = driver.findElement(locator).getText();
			}
			else
			{
				Assert.fail("Unable to get the text from the element "+ locator);
			}
			
		}
		catch(StaleElementReferenceException e)
		{			
			//log.error("Element with " + locator +"is not attached to the page document"+getStackTrace());
			Assert.fail("Element with " + locator +"is not attached to the page document");			
		}
	    catch (NoSuchElementException e)
		{	    	
			//log.error("Element " + locator + " was not found in DOM"+getStackTrace());	
			Assert.fail("Element "+ locator +" was not found in DOM");			
		}
		catch(Exception e)
		{
			//log.error("Unable to get the text from the element "+ locator+ "\n"+getStackTrace());
			Assert.fail("Unable to get the text from the element "+ locator);
		}		
		return sValue;		
	}
	
	/**
	 * 
	 * This method is used to switch to windows based on provided window title
	 * @param title, Window title to which
	 * @param, waitTime
	 *
	 **/
	
	public void switchToWindow(String title) {
		try {
			int numWindows = driver.getWindowHandles().size();
			int i = 0;
			while (numWindows < 2) {
				driver.wait(500);
				if (++i > 21) {
					break;
				}
			}
			if (numWindows >= 2) {
				
			boolean bFlag=false;
				for (String handle : driver.getWindowHandles()) {
					driver.switchTo().window(handle);
					if (driver.getTitle().contains(title)) {
						log.info("Navigated succesfsully to new windowwith title "+title);
						bFlag = true;
						break;
					}
				}
				if(!bFlag){
					log.error("Window with sepcified titlt "+title+" doesn't exists. Please check the window title or wait until the new window appears"+getStackTrace());
					Assert.fail("Window with sepcified number  "+title+"doesn't exists. Please check the window title or wait until the new window appears");
				}
			}
			else{
				log.info("Can not switch to new window as there is only one window, wait until the new window appears");
			}
		}
		catch(NoSuchWindowException e)
		{
			log.error("Can not switch to new window "+getStackTrace());
			Assert.fail("Can not switch to new window ");			
		}
		catch(Exception e)
		{
			log.error("Some exception occured while switching to new window with number: "+getStackTrace());
			Assert.fail("Some exception occured while switching to new window with number: ");			
		}
	}
	
	/**
	 * 
	 * This method is used to switch to windows based on provided unique element locater
	 * @param locater, unique element locater
	 * @param, waitTime
	 *
	 **/
	
	public void switchToWindow(By locator, int...waitTime) {
		try {
			int numWindows = driver.getWindowHandles().size();
			int i = 0;
			while (numWindows < 2) {
				driver.wait(500);
				if (++i > 21) {
					break;
				}
			}
			if (numWindows >= 2) {
				boolean bFlag = false;
				for (String handle : driver.getWindowHandles()) {
					driver.switchTo().window(handle);
					if (isElementPresent(locator)) {
						log.info("Navigated successfully to new window");
						bFlag = true;
						break;
					}
				}
				if (!bFlag) {
					log.error("Window with sepcified locator " + locator + " doesn't exists. Please check the locator or wait until the new window appears" + getStackTrace());
					Assert.fail("Window with sepcified locator  " + locator + "doesn't exists. Please check the locator or wait until the new window appears" );
				}
			}
			else{
				log.info("Can not switch to new window as there is only one window, wait until the new window appears");
			}
		}
		catch(NoSuchWindowException e)
		{
			log.error("Can not switch to new window "+getStackTrace());
			Assert.fail("Can not switch to new window ");			
		}
		catch(Exception e)
		{
			log.error("Some exception occured while switching to new window with number: "+getStackTrace());
			Assert.fail("Some exception occured while switching to new window with number: ");			
		}
	}
	/**
	@Method Highlights on current working element or locator
	@param Webdriver instance
	@param WebElement
	@return void (nothing)
	*/
	public void setHighlight(WebElement element) throws Exception
	{
		try{
			((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px solid red'", element);
			} catch(Exception e){
			if(e.toString().contains("arguments[0] is null")){
			throw new Exception("No Such Element");
			}
			}
			}
	
		/*//if(sys.getProperty("HighlightElements").equalsIgnoreCase("true"))
		{
	        String attributevalue = "border:3px solid red;";
	        JavascriptExecutor executor = (JavascriptExecutor) driver;
	        String getattrib = element.getAttribute("style");
	        executor.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, attributevalue);
	        try 
	        {
				Thread.sleep(100);
			} 
	        catch (InterruptedException e) 
			{
				log.error("Sleep interrupted - "+getStackTrace());
			}
	        executor.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, getattrib);
		}       
    }*/
	
	/**
	 * Method: Highlights on current working element or locator
	 * @param driver
	 * @param locator
	 * @throws Exception
	 */
	public void highlightElement(WebElement element) throws Exception
	{
		//if(sys.getProperty("HighlightElements").equalsIgnoreCase("true"))
		{
	    	((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px solid green'", element);
	        Thread.sleep(100);
	      //  executor.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, getattrib);
		}       
    }
	
	/**
	 * 
	 * This method is used to return list of WebElements matched by locator 
	 *
	 * @param Locator
	 * @return
	 */
	public List<WebElement> safeGetWebElementList(By Locator) 
	{
		List<WebElement> list = null;
		try
		{
			list= driver.findElements(Locator);
		}
		catch(Exception e)
		{
			log.error("Some exception occured while retriving web elements of a locator, exception message: "+getStackTrace());
			Assert.fail("Some exception occured while retriving web elements of a locator");
		}
		return list;
	}
	
public void closebrowser(){
	driver.close();
}
	 /**
     * TODO To get the entire exception stack trace
     * 
     * @return returns the stack trace
     */
    public static String getStackTrace()
    {
		String trace = "";
		int i;
		StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
		for(i=2;i<stackTrace.length;i++)
		{
			trace = trace+"\n"+stackTrace[i];
		}
		return trace;
    }

    // Added by Vibhakar Started
    
    public void safeClickOnCheckBox(By locator,int waitTime)
   	{
   		try
   		{
   			if(safeVerify(locator, waitTime))
   			{
   					driver.findElement(locator).click();
   				
   			}
   			else
   			{
   				Assert.fail("Unable to get the text from the element "+ locator);
   			}
   			
   		}
   		catch(StaleElementReferenceException e)
   		{			
   			//log.error("Element with " + locator +"is not attached to the page document"+getStackTrace());
   			Assert.fail("Element with " + locator +"is not attached to the page document");			
   		}
   	    catch (NoSuchElementException e)
   		{	    	
   			//log.error("Element " + locator + " was not found in DOM"+getStackTrace());	
   			Assert.fail("Element "+ locator +" was not found in DOM");			
   		}
   		catch(Exception e)
   		{
   			//log.error("Unable to get the text from the element "+ locator+ "\n"+getStackTrace());
   			Assert.fail("Unable to get the text from the element "+ locator);
   		}		
   				
   	}
       
       public void clickOnCheckBox(By locator,int waitTime)
   	{
   		try
   		{
   			if(safeVerify(locator, waitTime))
   			{
   				if(!driver.findElement(locator).isSelected()){
   					driver.findElement(locator).click();
   				}
   				
   			}
   			else
   			{
   				Assert.fail("Unable to get the text from the element "+ locator);
   			}
   			
   		}
   		catch(StaleElementReferenceException e)
   		{			
   			//log.error("Element with " + locator +"is not attached to the page document"+getStackTrace());
   			Assert.fail("Element with " + locator +"is not attached to the page document");			
   		}
   	    catch (NoSuchElementException e)
   		{	    	
   			//log.error("Element " + locator + " was not found in DOM"+getStackTrace());	
   			Assert.fail("Element "+ locator +" was not found in DOM");			
   		}
   		catch(Exception e)
   		{
   			//log.error("Unable to get the text from the element "+ locator+ "\n"+getStackTrace());
   			Assert.fail("Unable to get the text from the element "+ locator);
   		}		
   				
   	}
       public void clickToUnCheckBox(By locator,int waitTime)
   	{
   		try
   		{
   			if(safeVerify(locator, waitTime))
   			{
   				if(driver.findElement(locator).isSelected()){
   					driver.findElement(locator).click();
   				}
   				
   			}
   			else
   			{
   				Assert.fail("Unable to get the text from the element "+ locator);
   			}
   			
   		}
   		catch(StaleElementReferenceException e)
   		{			
   			//log.error("Element with " + locator +"is not attached to the page document"+getStackTrace());
   			Assert.fail("Element with " + locator +"is not attached to the page document");			
   		}
   	    catch (NoSuchElementException e)
   		{	    	
   			//log.error("Element " + locator + " was not found in DOM"+getStackTrace());	
   			Assert.fail("Element "+ locator +" was not found in DOM");			
   		}
   		catch(Exception e)
   		{
   			//log.error("Unable to get the text from the element "+ locator+ "\n"+getStackTrace());
   			Assert.fail("Unable to get the text from the element "+ locator);
   		}		
   				
   	}
       
       public void safeTypeWithAlertMessage(By locator, String text, int optionWaitTime)
   	{
   		try
   		{
   			//int waitTime =  getWaitTime(optionWaitTime);
   			if(safeVerify(locator, optionWaitTime))
   			{
   				scrollIntoElementView(locator);
   				WebElement element=driver.findElement(locator);
   				JavascriptExecutor jse = (JavascriptExecutor)driver;
   				jse.executeScript("arguments[0].value='"+text+"';", element);	
   			}
   			else
   			{
   				//log.error("Unable to enter " + text + " in field " + locator+getStackTrace());
   				Assert.fail("Unable to enter " + text + " in field " + locator);
   			}
   		}
   		catch(StaleElementReferenceException e)
   		{
   			//log.error("Element with " + locator + " is not attached to the page document"+getStackTrace());
   			Assert.fail("Element with " + locator + " is not attached to the page document");
   		}
   		catch (NoSuchElementException e)
   		{
   			//log.error("Element " + locator + " was not found in DOM"+getStackTrace());	
   			Assert.fail("Element " + locator + " was not found in DOM");
   		}
   		catch(Exception e)
   		{
   			log.error(e);
   			//log.error("Unable to enter '" + text + "' text in field with locator -"+ locator+getStackTrace());
   			Assert.fail("Unable to enter '" + text + "' text in field with locator -"+ locator);
   		}
   	}
    
    // Added by Vibhakar end

       //Added by ksushman 
       /**
   	 * Method - Safe Method for getting checkbox value, waits until the element is loaded and then deselects checkbox
   	 * @param locator
   	 * @param checkOption
   	 * @param waitTime
   	 * @return - boolean (returns True when the checkbox is enabled else returns false)
   	 * @throws Exception
   	 */
   	public boolean safeGetCheckboxValue(By locator, int... optionWaitTime)
   	{
   		boolean isSelected = false;
   		try
   		{
   				WebElement checkBox = driver.findElement(locator);
   				if (checkBox.isSelected())		
   					isSelected = true; 
   			
   			else
   			{			
   				log.error("Unable to get the status of checkbox " + locator+" '"+getStackTrace());
   				Assert.fail("Unable to get the status of checkbox " + locator+" '"+getStackTrace());
   			}
   		}
   		catch(StaleElementReferenceException e)
   		{
   			log.error("Element with " + locator + " is not attached to the page document"+getStackTrace());
   			Assert.fail("Element with " + locator + " is not attached to the page document");
   		}
   		catch (NoSuchElementException e)
   		{
   			log.error("Element " + locator + " was not found in DOM"+getStackTrace());	
   			Assert.fail("Element " + locator + " was not found in DOM");
   		}
   		catch(Exception e)
   		{
   			log.error("Unable to get the status of checkbox " + locator+getStackTrace());	
   			Assert.fail("Unable to get the status of checkbox " + locator);	
   		}
   		return isSelected;
   	}
   	
   	/**
   	 * 
   	 * TODO Safe method to get the attribute value
   	 *
   	 * @param locator - locator value by which an element is located
   	 * @param sAttributeValue - attribute type
   	 * @param waitTime - Time to wait for an element
   	 * @return - returns the attribute value of type string
   	 */
   	public String safeGetAttribute(By locator,String sAttributeValue,int waitTime)
   	{
   		String sValue = null;
   		try
   		{
   			if(safeVerify(locator, waitTime))
   			{
   				sValue = driver.findElement(locator).getAttribute(sAttributeValue);
   			}
   			else
   			{
   				log.error("Unable to get attribute from locator "+locator);
   				Assert.fail("Unable to get attribute from locator "+locator);
   			}
   		}
   		catch(StaleElementReferenceException e)
   		{			
   			log.error("Element with " + locator +"is not attached to the page document"+getStackTrace());
   			Assert.fail("Element with " + locator +"is not attached to the page document");			
   		}
   	    catch (NoSuchElementException e)
   		{	    	
   			log.error("Element " + locator + " was not found in DOM"+getStackTrace());	
   			Assert.fail("Element "+ locator +" was not found in DOM");			
   		}
   		catch(Exception e)
   		{
   			log.error("Unable to get attribute value of type " + sAttributeValue + " from the element "+ locator+ "\n"+getStackTrace());		
   			Assert.fail("Unable to get attribute value of type " + sAttributeValue + " from the element "+ locator);
   		}		
   		return sValue;		
   	}
   	
   	public  void alertAccept(){
   	        Alert alert = driver.switchTo().alert();
   	        alert.accept();	
   	}
   	/**
	* Method - safeClearAndTypeCredential to used for enter credential
	* @param locator
	* @param text
	* @param optionWaitTime
	*/
	public void safeJsType(By locator, String text, int optionWaitTime)
	{
	try
	{
		
	//int waitTime =  getWaitTime(optionWaitTime);
	if(safeVerify(locator, optionWaitTime))
	{
	scrollIntoElementView(locator);
	WebElement element=driver.findElement(locator);
	setHighlight(element);
	//element.clear();
	//element.sendKeys(text);

   JavascriptExecutor jse = (JavascriptExecutor)driver;
   jse.executeScript("arguments[0].value='"+text+"';", element);
log.info("Cleared the field and entered - '"+text+" in the element - " + locator);
	}
	else
	{ 
	// log.error("Unable to clear and enter " + text + " in field "+ locator+getStackTrace());
	Assert.fail("Unable to clear and enter " + text + " in field "+ locator);
	}
	}
	catch(StaleElementReferenceException e)
	{
	//log.error("Element with " + locator + " is not attached to the page document"+getStackTrace());
	Assert.fail("Element with " + locator + " is not attached to the page document");
	}
	catch (NoSuchElementException e)
	{
	//log.error("Element " + locator + " was not found in DOM"+getStackTrace()); 
	Assert.fail("Element " + locator + " was not found in DOM");
	}
	catch(Exception e)
	{
	//log.error("Unable to clear and enter '" + text + "' text in field with locator -"+ locator+getStackTrace());
	Assert.fail("Unable to clear and enter '" + text + "' text in field with locator -"+ locator);
	}
	}
}
