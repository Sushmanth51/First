package com.optum.ram.atdd.common.utils;

import java.io.File;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.testng.Assert;
import org.testng.AssertJUnit;

import com.optum.ram.atdd.eligibility.eligibilityUpload.EligibilityDBqueries;
import com.optum.ram.membersync.MemberSyncDBqueries;

public class MappingBeanMembers extends CSPCommonTestBase {

	Statement statement;

	/*
	 * Purpose :Reading the Membership file,mapping only the members for
	 * specified plan_name [i.e. GroupId in the membership file with
	 * ELIG_PLAN_NAME column in the ram_plan_name_xwalk table] Verifying the
	 * data from the Membership file is loaded into the staging tables and
	 * Membership tables or not[i.e.Demographics_File_data
	 * ,Eligibility_file_data table & MemberDemographics,MemberEligibility
	 * table] Parameters:Row ReturnType:null
	 */
	/**
	 * @Purpose:Stores all the Demographic records in the Demo Bean
	 * @param Row
	 * @return d-[Demo Bean]
	 */
	public DemoBean setDemoRecordsInBean(String Row) {
		DemoBean d = null;
		d = new DemoBean();
		d.setSubscriber_id(Row.substring(04, 13));
		d.setGroup_id(Row.substring(13, 21));
		d.setMedicaid_id(Row.substring(21, 41));
		d.setLastName(Row.substring(76, 111));
		d.setFirstName(Row.substring(111, 126));
		d.setAddress_Line1(Row.substring(206, 246));
		d.setCity(Row.substring(286, 305));
		d.setZip_code(Row.substring(307, 318));
		d.setState(Row.substring(305, 307));
		return d;

	}

	/**
	 * @Purpose:Stores all the Eligibility records in the Elig Bean
	 * @param Row
	 * @return e[elig-bean]
	 */

	public EligBean setEligRecordsInBeans(String Row) {
		EligBean e;
		e = new EligBean();
		e.setEffective_date(Row.substring(4, 12));
		e.setTermDate(Row.substring(12, 20));
		e.setPlan_id(Row.substring(20, 28));
		e.setSubgroup_id(Row.substring(28, 32));
		e.setClass_id(Row.substring(40, 44));
		return e;
	}

	/**
	 * @purpose:Reads the membership file and store all the info in map by key
	 *                as'Demographics'record and Value as it corresponding
	 *                'Eligibility'records
	 * @param testCaseId
	 * @return memberInfoGroupID
	 * @throws Exception
	 */
	public Map<DemoBean, List<EligBean>> memberShipFileMapping(String testCaseId) throws Exception {
		statement = getConnection();
		DbQueryHelper dbhelper = new DbQueryHelper();
		Map<DemoBean, List<EligBean>> memberInfoGroupID = new HashMap<DemoBean, List<EligBean>>();
		Map<String, String> tdMap;
		RAMCommonDBQuires rcmnDbobj=new RAMCommonDBQuires();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String ELIG_PLAN_NAME = dbhelper.getMultipleValues(
				"select ELIG_PLAN_NAME from ram_plan_name_xwalk where plan_name ='" + tdMap.get("PLANNAME") + "'");

		inputFileName = tdMap.get("PATHNAME") + "/" + tdMap.get("FILENAME");
		System.out.println("The File path is" + inputFileName);
		File file = new File(inputFileName);
		Scanner read = new Scanner(file);
		DemoBean d = null;
		EligBean e;
		List<EligBean> eligList = null;

		while (read.hasNextLine()) {
			String Row = read.nextLine();
			String recordType = Row.substring(0, 4);

			try {
				if (recordType.equals("DEMO")) {
					if (recordType.equals("DEMO")) {
						d = setDemoRecordsInBean(Row);

						if (Arrays.asList(ELIG_PLAN_NAME.split(",")).contains(d.getGroup_id().trim())) {
							System.out.println("The GroupId in the file is :" + d.getGroup_id()
									+ " is matched with the ELIG_PLAN_NAME Xwalk table :" + ELIG_PLAN_NAME + "");
							eligList = new ArrayList<EligBean>();
						}

						else {
							d = null;
							System.out.println("The Demo bean is Null-No Demograpics record inserted");
						}

					}
				} else if (recordType.equals("ELIG")) {
					e = setEligRecordsInBeans(Row);
					if (null != eligList) {
						eligList.add(e);
					}
				}

				else {

					System.out.println("It is a Header/ Trailer record");
				}

				if (null != d && null != eligList) {
					memberInfoGroupID.put(d, eligList);
				} else if (recordType.equals("ELIG")) {
					e = setEligRecordsInBeans(Row);
					if (null != eligList) {
						eligList.add(e);
					}

				}

				else {

					System.out.println("It is a Header/ Trailer record");
				}

				if (null != d && null != eligList) {
					memberInfoGroupID.put(d, eligList);
				}
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
		System.out.println("The total demographcis records count for the planName with " + tdMap.get("PLANNAME")
				+ " Which contains Group_ID as " + ELIG_PLAN_NAME + " are :" + memberInfoGroupID.size());

		read.close();
		return memberInfoGroupID;

	}

	/*
	 * Purpose :verify the data from the file is loaded into the Temporary
	 * tables and MemberShip tables are not verify that the Subscriber_id of the
	 * Demographic records are mapped to their corresponding Eligibility records
	 * Parameters:bean(contains all the Membership
	 * info),planName,process,validation ReturnType:null
	 */

	public void verifyRecordInFileWithDbValidation(Map<DemoBean, List<EligBean>> memberInfoGroupID, String testCaseId)
			throws Exception {

		String demorecordValidation, EligrecordValidation, subscriber_id, medicaid_id, firstName, lastName, city, state,
				zip_code, effective_date, term_date, Plancode, plan_id, group_id;

		DbQueryHelper dbhelper = new DbQueryHelper();
		Map<String, String> tdMap;
		RAMCommonDBQuires rcmnDbobj=new RAMCommonDBQuires();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String LOB_xwalk = dbhelper.getMultipleValues(
				"select RAM_LOB from RAM_PLAN_NAME_XWALK where plan_name='" + tdMap.get("PLANNAME") + "'");
		for (Map.Entry<DemoBean, List<EligBean>> entry : memberInfoGroupID.entrySet()) {

			DemoBean demobean = entry.getKey();
			subscriber_id = demobean.getSubscriber_id().trim();
			medicaid_id = demobean.getMedicaid_id().trim();
			group_id = demobean.getGroup_id().trim();
			firstName = demobean.getFirstName().trim();
			lastName = demobean.getLastName().trim();
			city = demobean.getCity().trim();
			zip_code = demobean.getZip_code().trim();
			state = demobean.getState().trim();

			String Where = null;

			if (!tdMap.get("PLANNAME").isEmpty()) {
				if (Where == null)
					Where = " plan_name='" + tdMap.get("PLANNAME") + "'";
				else
					Where = Where + "AND plan_name='" + tdMap.get("PLANNAME") + "'";
			}
			if (!subscriber_id.isEmpty()) {
				if (Where == null)
					Where = " subscriber_id='" + subscriber_id + "'";
				else
					Where = Where + "AND subscriber_id='" + subscriber_id + "'";
			}
			if (!firstName.isEmpty()) {
				if (Where == null)
					Where = " first_Name='" + firstName + "'";
				else
					Where = Where + "AND first_Name='" + firstName + "'";
			}
			if (!lastName.isEmpty()) {
				if (Where == null)
					Where = " last_Name='" + lastName + "'";
				else
					Where = Where + "AND last_Name='" + lastName + "'";
			}
			if (!medicaid_id.isEmpty()) {
				if (Where == null)
					Where = " medicaid_id='" + medicaid_id + "'";
				else
					Where = Where + "AND medicaid_id='" + medicaid_id + "'";
			}
			if (!city.isEmpty()) {
				if (Where == null)
					Where = " city='" + city + "'";
				else
					Where = Where + "AND city='" + city + "'";
			}
			if (!state.isEmpty()) {
				if (Where == null)
					Where = " state='" + state + "'";
				else
					Where = Where + "AND state='" + state + "'";
			}

			if (!zip_code.isEmpty()) {
				if (Where == null)
					Where = " zip_code='" + zip_code + "'";
				else
					Where = Where + "AND zip_code='" + zip_code + "'";
			}

			demorecordValidation = dbhelper.getMultipleValues(
					String.format(EligibilityDBqueries.COUNT_OF_RECORDS, "RAM_DEMOGRAPHICS_FILE_DATA", Where));
			if (demorecordValidation.equals("1")) {
				System.out.println("The record inserted into the Demo_file_data table successfully with subscriber_id:"
						+ subscriber_id);
			} else if (demorecordValidation.equals("0")) {
				demorecordValidation = dbhelper
						.getMultipleValues(String.format(EligibilityDBqueries.COUNT_OF_RECORDS_FILTER,
								"RAM_DEMOGRAPHICS_FILE_Error", "subscriber_id", subscriber_id));
				if (demorecordValidation.equals("1")) {
					System.out.println(
							"The record is moved into the Demo_file_Error table with subscriber_id:" + subscriber_id);
				} else {
					AssertJUnit.fail(
							"No Demographics record inserted into the Db with the subscriber_id :" + subscriber_id);
				}
			}

			List<EligBean> listElig = entry.getValue();
			for (EligBean eligBean : listElig) {
				Plancode = eligBean.getPlancode().trim();
				effective_date = eligBean.getEffective_date().trim();
				term_date = eligBean.getTermDate().trim();
				plan_id = eligBean.getPlan_id().trim();

				String where_Elig_Cond = " plan_name='" + tdMap.get("PLANNAME")
						+ "' and trunc(effective_date)=to_date('" + effective_date
						+ "','YYYYMMDD') and trunc(term_date)=to_date('" + term_date + "','YYYYMMDD') and plan_code='"
						+ Plancode + "'";

				String where_EligCond = "plan_name='" + tdMap.get("PLANNAME") + "' and subscriber_id='" + subscriber_id
						+ "' and trunc(effective_date)=to_date('" + effective_date
						+ "','YYYYMMDD') and trunc(term_date)=to_date('" + term_date + "','YYYYMMDD') and plan_code='"
						+ Plancode + "'";
				EligrecordValidation = dbhelper.getMultipleValues(
						"select subscriber_id from ram_eligibility_file_data where " + where_EligCond + "");
				if (subscriber_id.equals(EligrecordValidation)) {
					System.out.println("The corresponding Elig record is mapped with Subscriber of Demo record"
							+ EligrecordValidation);
					// LOB verification for each Eligibility record
					String LOB_MemberElig = dbhelper
							.getMultipleValues(dbhelper.subQuery("ram_member_eligibility", "seq_member_id",
									"RAM_MEMBER_DEMOGRAPHICS", where_Elig_Cond, subscriber_id, "LINE_OF_BUSINESS"));

					if (LOB_xwalk.contains(LOB_MemberElig)) {
						System.out.println(
								"The LOB:" + LOB_MemberElig + " is generated based on Xwalk table" + LOB_xwalk + "");
					} else {

						Assert.fail("FAIL:The company code in the file:" + LOB_MemberElig
								+ "  not assigned for the Subscriber_id" + subscriber_id + "as XwalkCompanyCode is "
								+ LOB_xwalk);

					}
					// End
				} else {
					EligrecordValidation = dbhelper
							.getMultipleValues(String.format(EligibilityDBqueries.COUNT_OF_RECORDS_FILTER,
									"RAM_ELIGIBILITY_FILE_Error", "subscriber_id", subscriber_id));
					if (!EligrecordValidation.equals("0")) {
						System.out.println(
								"The corresponding Elig record is moved to Elig_Error table mapped with Subscriber of Demo record"
										+ EligrecordValidation);
					} else {
						AssertJUnit.fail(
								"The corresponding Elig record in not mapped with the subscriber_id :" + subscriber_id);
					}
				}
			}

		}
	}

	/*
	 * Purpose :verify the data from the Temporary
	 * tables are moved to the RAM MemberShip tables are not verify that the Subscriber_id of the
	 * Demographic records are mapped to their corresponding Eligibility records
	 * Parameters:bean(contains all the Membership
	 * info),planName,process,validation ReturnType:null
	 */

	public void verifyDataInRamMembershiptables(Map<DemoBean, List<EligBean>> memberInfoGroupID, String testCaseId)
			throws Exception {

		String memberDemo_recordCount, EligrecordValidation, subscriber_id, medicaid_id, firstName, lastName, city,
				state, zip_code, effective_date, term_date, Plancode, plan_id, group_id;

		DbQueryHelper dbhelper = new DbQueryHelper();
		Map<String, String> tdMap;
		RAMCommonDBQuires rcmnDbobj=new RAMCommonDBQuires();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String companyCode_xwalk = dbhelper
				.getMultipleValues("select distinct company_code from RAM_PLAN_NAME_XWALK where plan_name='"
						+ tdMap.get("PLANNAME") + "'");
		for (Map.Entry<DemoBean, List<EligBean>> entry : memberInfoGroupID.entrySet()) {

			DemoBean demobean = entry.getKey();
			subscriber_id = demobean.getSubscriber_id().trim();
			medicaid_id = demobean.getMedicaid_id().trim();
			group_id = demobean.getGroup_id().trim();
			firstName = demobean.getFirstName().trim();
			lastName = demobean.getLastName().trim();
			city = demobean.getCity().trim();
			zip_code = demobean.getZip_code().trim();
			state = demobean.getState().trim();
			// !subscriber_id.equals(null)||
			if (!subscriber_id.isEmpty() && !medicaid_id.isEmpty() && !group_id.isEmpty() && !firstName.isEmpty()
					&& !lastName.isEmpty() && !city.isEmpty() && !zip_code.isEmpty() && !state.isEmpty()) {

				String Where = null;

				if (!tdMap.get("PLANNAME").isEmpty()) {
					if (Where == null)
						Where = " plan_name='" + tdMap.get("PLANNAME") + "'";
					else
						Where = Where + "AND plan_name='" + tdMap.get("PLANNAME") + "'";
				}
				if (!subscriber_id.isEmpty()) {
					if (Where == null)
						Where = " subscriber_id='" + subscriber_id + "'";
					else
						Where = Where + "AND subscriber_id='" + subscriber_id + "'";
				}
				if (!firstName.isEmpty()) {
					if (Where == null)
						Where = " first_Name='" + firstName + "'";
					else
						Where = Where + "AND first_Name='" + firstName + "'";
				}
				if (!lastName.isEmpty()) {
					if (Where == null)
						Where = " last_Name='" + lastName + "'";
					else
						Where = Where + "AND last_Name='" + lastName + "'";
				}
				if (!medicaid_id.isEmpty()) {
					if (Where == null)
						Where = " medicaid_id='" + medicaid_id + "'";
					else
						Where = Where + "AND medicaid_id='" + medicaid_id + "'";
				}
				if (!city.isEmpty()) {
					if (Where == null)
						Where = " city='" + city + "'";
					else
						Where = Where + "AND city='" + city + "'";
				}
				if (!state.isEmpty()) {
					if (Where == null)
						Where = " state='" + state + "'";
					else
						Where = Where + "AND state='" + state + "'";
				}

				if (!zip_code.isEmpty()) {
					if (Where == null)
						Where = " zip_code='" + zip_code + "'";
					else
						Where = Where + "AND zip_code='" + zip_code + "'";
				}

				memberDemo_recordCount = dbhelper.getMultipleValues(
						String.format(EligibilityDBqueries.COUNT_OF_RECORDS, "ram_member_demographics", Where));
				if (memberDemo_recordCount.equals("1")) {
					System.out.println(
							"The record inserted into the ram_member_demographics table successfully with subscriber_id:"
									+ subscriber_id);
				} else if (memberDemo_recordCount.equals("0")) {
					String demo_Error_recordCount = dbhelper
							.getMultipleValues(String.format(EligibilityDBqueries.COUNT_OF_RECORDS_FILTER,
									"RAM_DEMOGRAPHICS_FILE_Error", "subscriber_id", subscriber_id));
					if (demo_Error_recordCount.equals("1")) {
						System.out.println("The record is moved into the Demo_file_Error table with subscriber_id:"
								+ subscriber_id);
					} else {
						AssertJUnit
								.fail("No Demographics record inserted into the Demo_file_Error with the subscriber_id :"
										+ subscriber_id);
					}
				} else {
					System.out.println("<<<<<<<<<<<<<<SOME DEMO VALUE IS MISSING>>>>>>");
				}

				List<EligBean> listElig = entry.getValue();
				for (EligBean eligBean : listElig) {
					Plancode = eligBean.getPlancode().trim();
					effective_date = eligBean.getEffective_date().trim();
					term_date = eligBean.getTermDate().trim();
					plan_id = eligBean.getPlan_id().trim();

					String where_Elig_Cond = " plan_name='" + tdMap.get("PLANNAME")
							+ "' and trunc(effective_date)=to_date('" + effective_date
							+ "','YYYYMMDD') and trunc(term_date)=to_date('" + term_date
							+ "','YYYYMMDD') and plan_code='" + Plancode + "'";

					EligrecordValidation = dbhelper.getMultipleValues(
							String.format(MemberSyncDBqueries.MEMBER_ELIG_VALD, subscriber_id, where_Elig_Cond));
					if (subscriber_id.equals(EligrecordValidation)) {
						System.out.println("The corresponding Elig record is inserted into the ram_member_eligibility"
								+ EligrecordValidation);

						// Company code verification for each Eligibility record
						String companycode_MemberElig = dbhelper
								.getMultipleValues(dbhelper.subQuery("ram_member_eligibility", "seq_member_id",
										"RAM_MEMBER_DEMOGRAPHICS", where_Elig_Cond, subscriber_id, "company_code"));

						if (companyCode_xwalk.contains(companycode_MemberElig)) {
							System.out.println("The CompanyCode:" + companycode_MemberElig
									+ " is generated based on Xwalk table" + companyCode_xwalk + "");
						} else {

							Assert.fail("FAIL:The company code in the file:" + companycode_MemberElig
									+ "  not assigned for the Subscriber_id" + subscriber_id + "as XwalkCompanyCode is "
									+ companyCode_xwalk);

						}
						// End
					} else if (EligrecordValidation == null) {
						String eligErrorRecords = dbhelper
								.getMultipleValues(String.format(EligibilityDBqueries.COUNT_OF_RECORDS_FILTER,
										"ram_eligibility_file_error", "subscriber_id", subscriber_id));
						if (!eligErrorRecords.equals("0")) {
							System.out.println(
									"The ELIGIBILITY records are moved to the ram_eligibility_file_error table with the Subscriber_id:"
											+ subscriber_id);
						} else {
							Assert.fail(
									"The ELIG records are NOT moved to the ram_eligibility_file_error table with the Subscriber_id:"
											+ subscriber_id);
							System.out.println(
									"The ELIG records are NOT moved to the ram_eligibility_file_error table with the Subscriber_id:"
											+ subscriber_id);
						}
					}

					else {
						AssertJUnit.fail(
								"The corresponding Elig record in not mapped with the subscriber_id :" + subscriber_id);
					}
				}

			}
		}
	}
}
