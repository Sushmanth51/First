package com.optum.ram.atdd.common.utils;

public class EligBean {

	private String plan_id;
	private String effective_date;
	private String termDate;
	private String subgroup_id;
	private String class_id;
	private String plancode;
	private String group_Id;

	public String getPlan_id() {
		return plan_id;
	}

	public void setPlan_id(String plan_id) {
		this.plan_id = plan_id;
	}

	public String getEffective_date() {
		return effective_date;
	}

	public void setEffective_date(String effective_date) {
		this.effective_date = effective_date;
	}

	public String getTermDate() {
		return termDate;
	}

	public String getGroup_Id() {
		return group_Id;
	}

	public void setGroupId(String group_Id) {
		this.group_Id = group_Id;
	}

	public void setTermDate(String termDate) {
		this.termDate = termDate;
	}

	public String getSubgroup_id() {
		return subgroup_id;
	}

	public void setSubgroup_id(String subgroup_id) {
		this.subgroup_id = subgroup_id;
	}

	public String getClass_id() {
		return class_id;
	}

	public void setClass_id(String class_id) {
		this.class_id = class_id;
	}

	public String getPlancode() {
		plancode = class_id + subgroup_id;
		return plancode;
	}

	public void setPlancode(String plancode) {
		this.plancode = plancode;
	}

}
