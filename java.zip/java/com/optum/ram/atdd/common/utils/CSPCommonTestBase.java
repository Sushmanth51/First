package com.optum.ram.atdd.common.utils;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.optum.cloudsdk.crypto.Crypto;
import com.optum.cloudsdk.crypto.CryptoFactory;
import com.optum.cloudsdk.crypto.CryptoType;
import com.optum.facets.atdd.common.utils.CommonTestBase;
import com.optum.facets.atdd.common.utils.ConnectionHelper;
import com.optum.ram.ramui.BaseSetup;

import cucumber.api.testng.TestNGCucumberRunner;

public class CSPCommonTestBase extends CommonTestBase {
	protected static String inputFileName;
	Long numberOfLinesInTextFile;
	List<String> linesInTextFile = null;
	protected static String configDatabasePath = null;
	protected Crypto cryptoPBE = CryptoFactory.getCrypto(CryptoType.PBE, null);
	public String dbConfigPath;
	public static Connection oracleConnection;
	public static WebDriver driver;

	@BeforeSuite()
	public void setUpClass()
			throws ClassNotFoundException, SQLException, IOException, InstantiationException, IllegalAccessException {
		// dbConfigPath = System.getProperty("DBCONFIG_SUFFIX");//read from
		// maven/jenkins;
		// System.out.print("DBCONFIG_SUFFIX=" + dbConfigPath + "\n");
		// if ((dbConfigPath == null) || (dbConfigPath.isEmpty() ) ){
		// throw new SQLiteException("Please set up the DBCONFIG_SUFFIX property
		// in your maven configuration", SQLiteErrorCode.SQLITE_CANTOPEN);
		// }

		testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());

		oracleConnection = ConnectionHelper.openOracleConnection(CSPPropertyReader.getServer(),
				CSPPropertyReader.getPort(), CSPPropertyReader.getsid(), CSPPropertyReader.getUsername(),
				CSPPropertyReader.getPassword());
		driverlaunch();
		//BaseSetup.initiateDriver();
	
	}

	@AfterSuite(alwaysRun = true)
	public void tearDownClass() {
		try {
			ConnectionHelper.closeAllDatabaseConnections();
			// ConnectionHelper.writeandclsoeExcelConnection();

		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		testNGCucumberRunner.finish();
	}

	public Statement getConnection() throws SQLException, ClassNotFoundException, IOException {

		if (null != oracleConnection) {
			return oracleConnection.createStatement();
		} else {
			return ConnectionHelper.openOracleConnection(CSPPropertyReader.getServer(), CSPPropertyReader.getPort(),
					CSPPropertyReader.getsid(), CSPPropertyReader.getUsername(), CSPPropertyReader.getPassword())
					.createStatement();
		}

	}
	
	public WebDriver driverlaunch(){
		if(null!= driver){
			return driver;
		}
		else{
			return BaseSetup.initiateDriver();	
		}
		}
		

		
	}


