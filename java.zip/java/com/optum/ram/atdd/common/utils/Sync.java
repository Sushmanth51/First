/*************************************** PURPOSE **********************************

 - This class contains all synchronization methods
*/


package com.optum.ram.atdd.common.utils;




import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;




public class Sync
{
	
	private Logger log = Logger.getLogger("Sync");
	private WebDriver driver;
	
	public Sync(WebDriver driver)
	{
		this.driver = driver;
	}
	
	/**
	* Sets implicitWait to ZERO. This helps in making explicitWait work...
	* @param driver (WebDriver) The driver object to be used
	* @return void
	* @throws Exception
	*/
	public void nullifyImplicitWait()
	{
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); //nullify implicitlyWait()
	}

	/**
	* Set driver's implicitlyWait() time according given waitTime.
	* @param driver (WebDriver) The driver object to be used
	* @param waitTimeInSeconds (int) The time in seconds to specify implicit wait
	* @return void
	* @throws Exception
	*/
	public void setImplicitWait(int waitTimeInSeconds)
	{
		driver.manage().timeouts().implicitlyWait(waitTimeInSeconds, TimeUnit.SECONDS);
	}
	
	/**
	* Waits for the Condition of JavaScript.
	*
	*
	* @param driver (WebDriver) The driver object to be used to wait and find the element
	* @param javaScript (String) The javaScript condition we are waiting. e.g. "return (xmlhttp.readyState >= 2 && xmlhttp.status == 200)"
	* @param timeOutInSeconds (int) The time in seconds to wait until returning a failure
	* @return True (boolean) if javaScript condition is satisfied within timeOutInSeconds 
	**/
	public boolean waitForJavaScriptCondition(final String javaScript, int timeOutInSeconds)
	{
		boolean jscondition = false;
		nullifyImplicitWait();
		try
		{				
			new WebDriverWait(driver, timeOutInSeconds).until(new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driverObject) {
			return (Boolean) ((JavascriptExecutor) driverObject).executeScript(javaScript);
			}
			});
			jscondition = (Boolean) ((JavascriptExecutor) driver).executeScript(javaScript);		
		} 
		catch (Exception e) 
		{
		
             //log.info("ERROR-js condition not satisfied.."+getStackTrace());
			log.error("js condition not satisfied.."+getStackTrace());
			//Assert.fail("js condition not satisfied..");
		}

		return jscondition;
	}	
	

    
    /**
	 * Waits for an alert till the timeout expires
	 * @param waitTime (int) The time in seconds to wait until returning a failure
	 * @return - True (Boolean) if element is located within timeout period else false
	 */
    public boolean isAlertPresent(int waitTime)
	{    	
    	boolean bFlag = false;	
    	nullifyImplicitWait();
    	log.info("Waiting for presence of alert");
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, waitTime);
			wait.until(ExpectedConditions.alertIsPresent());//presenceOfElementLocated(locator)); 			
			Alert alert=driver.switchTo().alert();
				bFlag = true;
				log.info("Alert with text '"+alert.getText()+"' is displayed");
		}		
		catch (NoAlertPresentException e)
		{
			
			log.info("alert not present"+getStackTrace());			
		}
		catch (TimeoutException e)
		{
			log.info("alert not present"+getStackTrace());
//			bFlag=false;
		}
		catch (Exception e)
		{
			log.info("alert not present"+getStackTrace());
			//Assert.fail("alert not present");
		}
		//setImplicitWait(IMPLICITWAIT);
		return bFlag;
	}
 
  	
 
	/**
	 * Method -  Waits for an element till the element is clickable
	 * @param driver (WebDriver) The driver object to be used to wait and find the element
	 * @param bylocator (By) locator object of the element to be found
	 * @param waitTime (int) The time in seconds to wait until returning a failure	 
	 * @return - True (Boolean) if element is located and is clickable within timeout period else false
	 * @throws Exception
	 */
	public boolean waitUntilClickable(By locator, int optionWaitTime)
	{    	
		//int waitTime =  getWaitTime(optionWaitTime);
		boolean bFlag = false;
    	//nullifyImplicitWait();
    	//setImplicitWait(15);
		try
		{
			log.info("Waiting until element " + locator+" is clickable");
			WebDriverWait wait = new WebDriverWait(driver, optionWaitTime);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
		
			 
			if(driver.findElement((locator)).isDisplayed())
			{
				bFlag = true;
				log.info("Element " + locator + " is displayed and is clickable");
			}
		}
		
		catch (NoSuchElementException e)
		{
			//log.info("Error_Element " + locator + " was not displayed"+getStackTrace());
			log.error("Element " + locator + " was not displayed"+getStackTrace());
			Assert.fail("Element " + locator + " was not displayed");
		}
		catch (TimeoutException e)
		{
			log.error("Element " + locator + " was not clickable in time - "+optionWaitTime+getStackTrace());
			Assert.fail("Element " + locator + " was not clickable in time - "+optionWaitTime);//+UtilityMethods.getStackTrace());
		}
		catch (Exception e)
		{
			log.error("Element " + locator + " was not clickable"+"\n"+getStackTrace());		
			Assert.fail("Element " + locator + " was not clickable" +"\n");//+UtilityMethods.getStackTrace());
		}
		//setImplicitWait(IMPLICITWAIT);
		return bFlag;
	}
	
	

	/**
	 * Method -  Waits for an element till the element is visible
	 * @param driver (WebDriver) The driver object to be used to wait and find the element
	 * @param bylocator (By) locator object of the element to be found
	 * @param waitTime (int) The time in seconds to wait until returning a failure	 
	 * @return - True (Boolean) if element is located and is visible on screen within timeout period else false
	 * @throws Exception
	 */
	public boolean isElementVisible(By locator, int optionWaitTime)
	{
	//	int waitTime =  getWaitTime(optionWaitTime);
		boolean bFlag = false;
		nullifyImplicitWait(); 
		log.info("Waiting until element " + locator+" is visible");
		try
		{			
			WebDriverWait wait = new WebDriverWait(driver, optionWaitTime);
			wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			//setImplicitWait(IMPLICITWAIT); 
			if(driver.findElement((locator)).isDisplayed())
			{
				bFlag = true;
			log.info("Element " + locator + " is displayed");
			}
		}
		catch (NoSuchElementException e)
		{	
			log.info("Element " + locator + " was not displayed"+getStackTrace());			
		}
		catch (TimeoutException e)
		{
			log.info("Element " + locator + " was not visible in time - "+optionWaitTime+getStackTrace());
		}
		
		catch (Exception e)
		{	
			log.error("Element " + locator + " was not displayed"+getStackTrace());	
			Assert.fail("Element " + locator + " was not displayed.");
		}
		return bFlag;
	}


	    /** Waits for the completion of Ajax jQuery processing by checking "return jQuery.active == 0" condition.
    *
    * @param driver - The driver object to be used to wait and find the element
    * @param timeOutInSeconds - The time in seconds to wait until returning a failure
    * @return True (Boolean) if jquery/ ajax is loaded within specified timeout.
    * @throws Exception
    * */
	public boolean waitForJQueryProcessing(int timeOutInSeconds)
	{
		log.info("Waiting ajax processing to complete..");
		boolean jQcondition = false;
		try 
		{
			Thread.sleep(500);
			new WebDriverWait(driver, timeOutInSeconds).until(new ExpectedCondition<Boolean>() 
			{
				@Override
				public Boolean apply(WebDriver driverObject)
				{
					return (Boolean) ((JavascriptExecutor) driverObject).executeScript("return jQuery.active == 0");
				}
			});
			jQcondition = (Boolean) ((JavascriptExecutor) driver).executeScript("return window.jQuery != undefined && jQuery.active === 0");
			System.out.println(jQcondition);
			return jQcondition;
		} 
		catch (Exception e) 
		{
			log.error("Page Loading is not completed"+ getStackTrace());
			//Assert.fail("Page Loading is not completed");
		}
		return jQcondition;
	}
	
	/**
	 * Method - Wait until a particular text appears on the screen
	 * @param driver (WebDriver) The driver object to be used to wait and find the element
	 * @param text (String) - text until which the WebDriver should wait.
	 * @return void
	 * @throws Exception
	 */
	public void waitForPageToLoad(final String text) throws Exception
	{
		log.info("Waiting for page to be loaded...");
		nullifyImplicitWait(); 
		(new WebDriverWait(driver, 20)).until(new ExpectedCondition<WebElement>() {
		    public WebElement apply(WebDriver d) 
		    {
		        return d.findElement(By.partialLinkText(text));
		    }
		});
		//setImplicitWait(IMPLICITWAIT); 
	}
	
	
	/**
	* Waits until page is loaded.
	*
	* @param driver - The driver object to use to perform this element search
	* @param int - timeout in seconds
	* @return True (boolean)
	* @throws Exception
	*/
	public boolean waitForPageToLoad(int timeOutInSeconds)
	{
		log.info("Waiting for page to be loaded...");
		boolean isPageLoadComplete = false;
		nullifyImplicitWait(); //nullify implicitlyWait()
		try
		{
			new WebDriverWait(driver, timeOutInSeconds).until(new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driverObject) {
			return (Boolean) ((String)((JavascriptExecutor)driver).executeScript("return document.readyState")).equals("complete");
			}
			});
			isPageLoadComplete = (Boolean) ((String)((JavascriptExecutor)driver).executeScript("return document.readyState")).equals("complete");
		}
		catch(Exception e)
	   	{		
			log.error("Unable to load web page"+getStackTrace());
		//	Assert.fail("unable to load webpage");
	   	}
		//setImplicitWait(IMPLICITWAIT);
		return isPageLoadComplete;
	}
	
	/**
	* Waits until page is loaded. Default timeout is 250 seconds. Poll time is every 500 milliseconds.
	*
	* @param driver - The driver object to use to perform this element search
	* @return void
	* @throws Exception
	*/
	
	public void waitForPageToLoad() throws Exception 
	{
		log.info("Waiting for page to be loaded...");
		try
		{
			int waitTime = 0;
			boolean isPageLoadComplete = false;
			do 
			{

				isPageLoadComplete = ((String)((JavascriptExecutor)driver).executeScript("return document.readyState")).equals("complete");
				System.out.print(".");
				Thread.sleep(500);
				waitTime++;
				if(waitTime > 500)
				{
					break;
				}
			} 
			while(!isPageLoadComplete);

			if(!isPageLoadComplete)
			{	

				log.error("Unable to load webpage with in default timeout 250 seconds");
				//Assert.fail("unable to load webpage with in default timeout 250 seconds");
			}
		}
		catch(Exception e)
		{		
			log.error("Unable to load web page"+getStackTrace());
		//	Assert.fail("unable to load webpage");
		}

	}

    public boolean isElementPresent(By locator)
    {
    	log.info("Waiting for presence of element " + locator);
    //	setImplicitWait(IMPLICITWAIT);
    	return driver.findElements(locator).size()>0;	
    }
	
    public boolean isElementDisplayed(By locator)
    {
    	log.info("Verifying if element " + locator+ " is displayed");
    	boolean isDisplayed = false;
    	//setImplicitWait(IMPLICITWAIT);
    	
    	try
    	{
    		if(isElementPresent(locator))
	    	{
	    		isDisplayed = driver.findElement(locator).isDisplayed();	
	    	}
    	} 
 		catch (Exception e)
 		{
 			log.error("Exception occured while determining state of " + locator +getStackTrace());			
 		}	
    	return isDisplayed;
    }
    
    public boolean isElementEnabled(By locator)
    {
    	log.info("Verifying if element " + locator+ " is enabled");
    	boolean isEnabled = false;
    	//setImplicitWait(IMPLICITWAIT);
    	try
    	{
    		if(isElementPresent(locator))
        	{
    			isEnabled = driver.findElement(locator).isEnabled();
        	}
    	} 
 		catch (Exception e)
 		{
 			log.info("Exception occured while determining state of " + locator +getStackTrace());
 			log.error("Exception occured while determining state of " + locator +getStackTrace());			
 		}
    	return isEnabled;
    }
    /**
     * TODO To get the entire exception stack trace
     * 
     * @return returns the stack trace
     */
    public static String getStackTrace()
    {
		String trace = "";
		int i;
		StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
		for(i=2;i<stackTrace.length;i++)
		{
			trace = trace+"\n"+stackTrace[i];
		}
		return trace;
    }	
}


