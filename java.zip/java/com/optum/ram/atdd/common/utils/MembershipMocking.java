package com.optum.ram.atdd.common.utils;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.optum.ram.invoice.InvoiceCommon;

public class MembershipMocking {
	
	String[] DEM0_SITUATIONAL_FIELDS = new String[] { "ADDRESS_LINE_1", "CITY", "STATE", "ZIP_CODE" };
	String[] DEMO_MANDATORY_FIELDS = new String[] { "MEDICAID_ID", "LAST_NAME", "FIRST_NAME" };
	String[] ElIG_MANDATORY_FIELDS = new String[] { "GROUP_ID", "EFFECTIVE_DATE", "TERM_DATE" };

	public void createMockDataForMembership(String plan, String seqRevId, String membershipFolder, boolean mockErrorDataFlag) throws Exception {

		// String memFilePath =
		// "src/main/resources/eligibilityUpload/testdata/CSP_03162018110401_Membership.txt";
		File[] files;
		String memFilePath;
		String groupId;
		String memberKey;
		String invoiceParam;
		String mockedTempFile;
		InvoiceCommon common = new InvoiceCommon();
		MembershipMockingHelper mocking = new MembershipMockingHelper();
		Map<String, List<String>> mockedRecords = new HashMap<String, List<String>>();
		try {
			files = new File(membershipFolder).listFiles();
			memFilePath = membershipFolder + "/"+files[0].getName();
			groupId = common.getGroupId(plan);
			memberKey = common.getMemberKey(plan,seqRevId);
			invoiceParam = common.getInvoiceParamy(plan, seqRevId);

			if (null != memberKey && null != groupId && null != invoiceParam) {
				mockedTempFile = createDuplicateFile(memFilePath);
				mockedRecords = mocking.createMockDataforDMI(memberKey, mockedRecords, memFilePath, plan, groupId);
				mockedRecords = mocking.createMockDataforIKM(invoiceParam, mockedRecords, memFilePath, plan, groupId, mockedTempFile);
				mockedRecords = mocking.createMockDataforMKM(memberKey, mockedRecords, memFilePath, plan, groupId, mockedTempFile);
				mockedRecords = mocking.createMockDataforNRF(mockedRecords, memFilePath, plan, groupId, mockedTempFile);
				
				if(mockErrorDataFlag){
					
					mockedRecords = mocking.createMockDataForErrorTables(DEM0_SITUATIONAL_FIELDS, mockedRecords,
							memFilePath, plan, groupId, mockedTempFile);
					mockedRecords = mocking.createMockDataForErrorTables(DEMO_MANDATORY_FIELDS, mockedRecords, memFilePath,
							plan, groupId, mockedTempFile);
					mockedRecords = mocking.createMockDataforErrorEligRecord(ElIG_MANDATORY_FIELDS, mockedRecords,
							memFilePath, plan, groupId, mockedTempFile);
				}
				
				if (!mockedRecords.isEmpty()) {
					mocking.createMockedFile(mockedRecords, mockedTempFile);
				} else {
					System.out.println("No eligibile records available in MemShip file for Plan: " + plan);
				}

			} else {
				System.out.println("NO MemberKey/GroupId/InvoiceParam available for plan " + plan);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private String createDuplicateFile(String memFilePath) throws IOException {
		String newMockedFile;
		int index = memFilePath.lastIndexOf("_");
		String split1 = memFilePath.substring(0, index);
		String split2 = memFilePath.substring(index + 1, memFilePath.length());

		newMockedFile = split1.substring(0, split1.length() - 1)
				+ String.valueOf(Integer.parseInt(split1.substring(split1.length() - 1, split1.length())) + 1) + "_"
				+ split2;
		Path memFile = Paths.get(memFilePath);
		List<String> lines = Files.readAllLines(memFile, StandardCharsets.UTF_8);
		Path mockedFile = Paths.get(newMockedFile);
		Files.write(mockedFile, lines, StandardCharsets.UTF_8);
		
		return newMockedFile;
	}

	public static void main(String[] args) throws Exception {
		MembershipMocking mocking = new MembershipMocking();
		String plan = "VAMDN";
		String seqRevId = "110057";
		boolean mockErrorDataFlag = false;
		mocking.createMockDataForMembership(plan, seqRevId, CSPPropertyReader.getcsp_MembeshipFiles(), mockErrorDataFlag);
	}
}
