package com.optum.ram.atdd.common.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.optum.cloudsdk.crypto.Crypto;
import com.optum.cloudsdk.crypto.CryptoFactory;
import com.optum.cloudsdk.crypto.CryptoType;

/**
 * Reads the property file
 */
public class CSPPropertyReader {


	private static String username;
	private static String password;
	private static String server;
	private static String port;
	private static String sid;
	private static String nasid;
	private static String environment;
	private static String unixUsername;
	private static String unixPassword;
	private static String unixServer;
	private static String unixRootDirectory;
	private static String propertyFile = "src/main/resources/common/property/%sramcredentials.properties";
	private static String EligUpload_ServerPathInbound;
	private static String shellJobPath;
	private static String csp_MembeshipFiles;
	private static String eligibilityUploadJob;
	private static String invoiceJob;
	private static String ack_Membershipfile;
	private static String reconJob;
	private static String memberSyncJob;
	private static String billingJob;
	private static String de_intermediateFiles_SeverPath;
	private static String csp_MembershipFiles_WrongSequence;
	private static String ieDriverPath;
	private static String appUrl;
	private static String app_userName;
	private static String app_password;
	private static String rateUploadJob;
	private static String bulkupdateJob;


	/**
	 * @return the username
	 * @throws IOException
	 */
	public static String getUsername() throws IOException {
		if (username == null) {
			readProperties();
		}
		return username;
	}

	/**
	 * @return the password
	 */
	public static String getPassword() throws IOException {
		if (password == null) {
			readProperties();
		}
		return password;
	}

	/**
	 * @return the databasename
	 */
	public static String getServer() throws IOException {
		if (server == null) {
			readProperties();
		}
		return server;
	}

	/**
	 * @return the port
	 */
	public static String getPort() throws IOException {
		if (port == null) {
			readProperties();
		}
		return port;
	}

	/**
	 * @return the sid
	 */
	public static String getsid() throws IOException {
		if (sid == null) {
			readProperties();
		}
		return sid;
	}

	/**
	 * @return the nas Id
	 * @throws IOException
	 */
	public static String getNasId() throws IOException {
		if (nasid == null) {
			readProperties();
		}
		return nasid;
	}

	/**
	 * @return the nas environment
	 * @throws IOException
	 */
	public static String getEnvironment() throws IOException {
		if (environment == null) {
			readProperties();
		}
		return environment;
	}

	/**
	 * @return the Unix username
	 * @throws IOException
	 */
	public static String getUnixUsername() throws IOException {
		if (unixUsername == null) {
			readProperties();
		}
		return unixUsername;
	}

	/**
	 * @return the unix password
	 */
	public static String getUnixPassword() throws IOException {
		if (unixPassword == null) {
			readProperties();
		}
		return unixPassword;
	}

	/**
	 * @return the unix server name
	 */
	public static String getUnixServer() throws IOException {
		if (unixServer == null) {
			readProperties();
		}
		return unixServer;
	}

	/**
	 * @return the unix root directory
	 */
	public static String getUnixRootDirectory() throws IOException {
		if (unixRootDirectory == null) {
			readProperties();
		}
		return unixRootDirectory;
	}

	/**
	 * @return The unix server inbound directory for the EligibilityUpload
	 *         process
	 */

	public static String getde_intermediateFilesSeverPath() throws IOException {
		if (de_intermediateFiles_SeverPath == null) {
			readProperties();
		}
		return de_intermediateFiles_SeverPath;
	}

	/**
    	 * @return The unix server inbound directory for the EligibilityUpload process
	 */

	public static String getEligUpload_ServerPathInbound() throws IOException {
		if (EligUpload_ServerPathInbound == null) {
			readProperties();
		}
		return EligUpload_ServerPathInbound;
	}

	public static String getshellJobPath() throws IOException {
		if (shellJobPath == null) {
			readProperties();
		}
		return shellJobPath;
	}

	/*
	 * 
	 */
	public static String getcsp_MembeshipFiles() throws IOException {
		if (csp_MembeshipFiles == null) {
			readProperties();
		}
		return csp_MembeshipFiles;
	}

	public static String geteligibilityUploadJob() throws IOException {
		if (eligibilityUploadJob == null) {
			readProperties();
		}
		return eligibilityUploadJob;
	}

	public static String getInvoiceJob() throws IOException {
		if (null == invoiceJob) {
			readProperties();
		}
		return invoiceJob;
	}

        
        public static String getReconJob() throws IOException{
        	if(null == reconJob){
        		readProperties();
        	}
			return reconJob;
        }
        
	public static String getBillingJob() throws IOException{
		if (null == billingJob) {
			readProperties();
		}

		return billingJob;
	}

	public static String getack_Membershipfile() throws IOException {
		if (null == ack_Membershipfile) {
			readProperties();
		}
		return ack_Membershipfile;
	}

	public static String getcsp_MembershipFiles_WrongSequence() throws IOException {

		if (null == csp_MembershipFiles_WrongSequence) {
			readProperties();
		}
		return csp_MembershipFiles_WrongSequence;

	}

	public static String getMemberSyncJob() throws IOException {
		if (null == memberSyncJob) {
			readProperties();
		}
		return memberSyncJob;
	}
	
	public static String getIeDriverPath() throws IOException {
		if (null == ieDriverPath) {
			readProperties();
		}
		return ieDriverPath;
	}

	public static String getappUrl() throws IOException {
		if (null == appUrl) {
			readProperties();
		}
		return appUrl;
	}

	public static String getapp_userName() throws IOException {
		if (null == app_userName) {
			readProperties();
		}
		return app_userName;
	}

	public static String getapp_password() throws IOException {
		if (null == app_password) {
			readProperties();
		}
		return app_password;
	}
	
	public static String getRateUploadJob() throws IOException{
		if (null == rateUploadJob) {
			readProperties();
		}

		return rateUploadJob;
	}
	
	public static String getBulkupdateJob() throws IOException {
		if (null == bulkupdateJob) {
			readProperties();
		}
		return bulkupdateJob;
	}


	
	private static void readProperties() throws IOException {
		InputStream input;
		Properties prop;
		Crypto cryptoPBE;
		String prefix;

		prefix = System.getProperty("CSP_ENV_NAME");

                if (prefix == null ){ // When running from 1) jenkins or 2) when running as TestNG. 
			prefix = "";
                }
                else{ // When running as maven tests with environment variable set to Dev or Test
			prefix = prefix + "_";
		}
		System.out.println("CSP_ENV_NAME prefix is: " + prefix);

		input = new FileInputStream(String.format(propertyFile, prefix));
		prop = new Properties();
		prop.load(input);
		cryptoPBE = CryptoFactory.getCrypto(CryptoType.PBE, null);

		server = prop.getProperty("server");

		System.out.println("Server is: " + server);
		username = prop.getProperty("db_username");
		password = cryptoPBE.decryptString(prop.getProperty("db_password"));
		// password = prop.getProperty("db_password");
		port = prop.getProperty("port");
		sid = prop.getProperty("sid");
		nasid = prop.getProperty("nasid");
		environment = prop.getProperty("environment");
		unixUsername = prop.getProperty("unixusername");
		unixPassword = cryptoPBE.decryptString(prop.getProperty("unixpassword"));
		// unixPassword = prop.getProperty("unixpassword");
		unixServer = prop.getProperty("unixserver");
		shellJobPath = prop.getProperty("shellJobPath");
		unixRootDirectory = prop.getProperty("unixrootdirectory");
		EligUpload_ServerPathInbound = prop.getProperty("EligUpload_ServerPathInbound");
		csp_MembeshipFiles = prop.getProperty("csp_MembeshipFiles");
		eligibilityUploadJob = prop.getProperty("eligibilityUploadJob");
		invoiceJob = prop.getProperty("invoiceJob");
		ack_Membershipfile = prop.getProperty("ack_Membershipfile");
		memberSyncJob = prop.getProperty("memberSyncJob");
		de_intermediateFiles_SeverPath = prop.getProperty("de_intermediateFiles_SeverPath");
		csp_MembershipFiles_WrongSequence = prop.getProperty("csp_MembershipFiles_WrongSequence");
		reconJob = prop.getProperty("reconJob");
		billingJob = prop.getProperty("billingJob");
		ieDriverPath=prop.getProperty("ieDriverPath");
		appUrl=prop.getProperty("appUrl");
		app_userName=prop.getProperty("app_userName");
		app_password=cryptoPBE.decryptString(prop.getProperty("app_password"));
		rateUploadJob = prop.getProperty("rateUploadJob");
		bulkupdateJob = prop.getProperty("bulkupdateJob");
	}
}
