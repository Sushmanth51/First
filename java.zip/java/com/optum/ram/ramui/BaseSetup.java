/**************************************** PURPOSE **********************************

 - This class contains the code related to Basic setup of TestSuites such as Instantiating Browser,
 - Launching Browser from selected Configuration.

USAGE
 - Inherit this BaseClass for any TestSuite class. You don't have to write any @Beforeclass and @AfterClass
 - actions in your TestSuite Classes

 - Example: 
 --import Com.Base
 --- public class <TestSuiteClassName> extends BaseClass
 */
package com.optum.ram.ramui;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;

import com.optum.cloudsdk.crypto.Crypto;
import com.optum.cloudsdk.crypto.CryptoFactory;
import com.optum.cloudsdk.crypto.CryptoType;
import com.optum.ram.atdd.common.utils.CSPCommonTestBase;
import com.optum.ram.atdd.common.utils.CSPPropertyReader;



public class BaseSetup extends CSPCommonTestBase{
	
	public static WebDriver driver;

	/*
	 * Purpose : Launching the IE browser Parameters: null Return Type:null
	 */

	public static WebDriver initiateDriver() {

		try {
				DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
				capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
				capabilities.setCapability(InternetExplorerDriver.ENABLE_ELEMENT_CACHE_CLEANUP, true);
				capabilities.setCapability("ignoreZoomSetting", true);
				capabilities.setCapability("requireWindowFocus",true);
			/*	capabilities.setCapability(InternetExplorerDriver.FORCE_CREATE_PROCESS, true); 
				capabilities.setCapability(InternetExplorerDriver.IE_SWITCHES, "-private");*/
				
			System.setProperty("webdriver.ie.driver",CSPPropertyReader.getIeDriverPath());
			driver = new InternetExplorerDriver(capabilities);
			driver.manage().window().maximize();
		} catch (Exception e) {
		Assert.fail("Unable to launch Internet Explorer"+e.getMessage());
		}
		return driver;
		
	}
	  public static void main(String[] args) {
		

			  final Crypto cryptoPBE =CryptoFactory.getCrypto(CryptoType.PBE, null);
			  
			  String x=cryptoPBE.encryptString("ROGw2()b");
//			  System.out.println("0C0AEEk+jHOt/hbOHGc58lIFw156lMVX");
			  String y=cryptoPBE.decryptString(x);
			  System.out.println(y);
			  System.out.println(x);
			  }
	
	    }

	

