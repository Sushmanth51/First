package com.optum.ram.ramui;

import org.openqa.selenium.By;

public class ServiceTablocators {

	public static By HEADER_FRAME = By.xpath("//frame[@name='header']");
	public static By RIGHT_FRAME = By.id("right_frame");
	public static By SERVICE_TAB = By.xpath("//a[@id='aservicereports']");
	public static By TrackingReportOverall_link = By.xpath("//a[@id='trackingoverall']");
	public static By TrackingReportDetail_link = By.xpath("//a[contains(.,'Tracking Report Detail')]");
	public static By AgingReport_link = By.xpath("//a[text()='Aging Report']");
	public static By BulkUpdate_link = By.xpath("//a[@id='bulkUpdate']");
	public static By BatchReports_link = By.xpath("//a[@id='fetchbatchreports']");

	// Tracking overall Report Screen
	public static By Page_Banner = By.xpath("//span[@class='pagebanner']");
	public static By Date_From_Field = By.xpath("//input[@id='fromDate']");
	public static By Date_To_Field = By.xpath("//input[@id='toDate']");
	public static By REPORT_BUTTON = By.xpath("//input[@value='Report']");
	public static By TrackingReportoverall_Header_Msg = By
			.xpath("//div[ @class='headingMajor' and contains(.,'TRACKING OVERALL REPORT FOR START DATE')]");
	public static By Export_CSV_link = By.xpath("//div[contains(@class,'exportlinks')]/a[contains(@href,'Csv')]");
	public static By Export_Excel_2007_link = By
			.xpath("//div[contains(@class,'exportlinks')]/a[contains(@href,'excel')]/span[contains(.,'Excel 2007')]");
	public static By Noof_Items_Found_Msg = By.xpath("//span[@class='pagebanner']");
	public static By ROWDATA_TRACKINGOVERALLPAGE = By.xpath("(//table[@id='memberDetail']/tbody/tr)[1]");

	// search Tab
	public static By SEARCH_TAB = By.id("asearch");
	public static By MEDICAID_ID_FIELD = By.xpath("//input[@name='medicaidId']");
	public static By SEARCH_BTN = By.xpath("//input[@name='Search']");
	public static By NOOFRECORDS_MEMBERDETAILS = By.xpath("//div[@id='DisplayTables']/span");
	public static By REVENUE_MONTH_FIELD=By.xpath("//input[@name='revMonth']");
	public static By ROW_1 = By.xpath("//table[@id='memberDetail']/tbody/tr[1]/td[2]");

	// MemberDetail Screen
	public static By MEMEBERDETAILS_HEADER_MSG = By
			.xpath("//span[@class='headingRightMajor_underline' and text()='Member Details']");
	public static By MemberDetailsForm = By.xpath("//form[@name='memberDetailsForm']");
	public static By Member_Field_MemberDetailScreen = By
			.xpath("//form[@name='memberDetailsForm']//td[text()='Member:']");
	public static By Member_Demographics_Table = By.xpath("//div[@id='MyTables']/span[text()='Demographics']");
	public static By MEMBERDEMO_DETAIL_TR = By.xpath("//table[@id='memberDemoDetailTable']/tbody/tr");
	public static By MEMBERELIG_DETAIL_TR = By.xpath("//table[@id='memberEligDetailTable']/tbody/tr");
	public static By MEMBERINVOICE_DETAIL_TR = By.xpath("//table[@id='memberInvoiceDetailTable']/tbody/tr");
	public static By MEMBERPAYMENT_DETAIL_TR = By.xpath("//table[@id='memberPaymentDetailTable']/tbody/tr");
	public static By MEMBERDETAIL_SYSTEM_STATUS= By.xpath("//form[@name='memberDetailsForm']//table[@class]/tbody/tr/td[contains(.,'System Status:')]/following-sibling::td");
	public static By MEMBERDETAIL_DOB= By.xpath("//table[@id='memberDemoDetailTable']/tbody/tr/td[6]");
	public static By PAYMENT_STARTDATE_MEMBERDETAIL= By.xpath("//table[@id='memberPaymentDetailTable']/tbody/tr/td[2]");
	public static By INVOICE_ERROR_MSG= By.xpath("//font[contains(.,'Missing Invoice Key')]");
	
	//form[@name='memberDetailsForm']//tr/td[contains(.,'Invoice Error')]/following-sibling::td/font[contains(@color,'red')]
	// Tracking Detail Report Screen:
	public static By FROM_DATE_INPUT_FIELD = By.xpath("//input[@name='fromDate']");
	public static By TO_DATE_INPUT_FIELD = By.xpath("//input[@name='toDate']");
	public static By TrackingDetailReport_Header_Msg = By
			.xpath("//span[ contains(@class,'headingRight') and contains(.,'Tracking Detail Report')]");
	public static By ROWDATA_SYSSTATUS_TRACKINGDETAIL = By.xpath("//table[@id='System_Status']/tbody/tr");

	public static By Export_Excel_link = By.xpath("(//div[@class='exportlinks']/a/span[text()='Excel '])[1]");
	public static By Export_Excel2007_link = By.xpath("(//div[@class='exportlinks']/a/span[text()='Excel 2007 '])[1]");
	public static By PAGEBANNER_TRACKINGDETAILREPORT= By.xpath("(//span[@class='pagebanner'])[1]");
	public static By SYSTEM_STATUS_COLUMN=By.xpath("//table[@id='System_Status']/tbody/tr/td[1]/a");
	public static By BACK_BTN = By.xpath("//img[@id='btback']");

	// AgingReport Screen
	public static By Period_Link = By.xpath("//a[text()='0-30']");

	// BulkUpdate Screen
	public static By BULKUPDATE_LINK = By.id("bulkUpdate");
	public static By BROWSE_BUTTON = By.id("locPath");
	public static By UPLOADFILE_BUTTON = By.xpath("//input[@value='Upload File']");
	public static By TEMPATE_DOWNLOAD = By.xpath("//td[contains(.,'Click here to get File Layout')]");
	public static By FILEUPLOAD_SUCCESS_MSG=By.xpath("//span[@class='MessageGreen' and contains(.,'File has been uploaded successfully')]");
	// Batch Report Screen
	public static By From_DATE = By
			.xpath("//td[contains(.,'From Month (MMYYYY):')]/following-sibling::td/input[@name='fromMonth']");
	public static By To_DATE = By
			.xpath("//td[contains(.,'To Month (MMYYYY):')]/following-sibling::td/input[@name='toMonth']");
	public static By REPORTNAME_DD = By.xpath("//td[text()='Report Name:']/following-sibling::td/select");
	public static By Required_FieldsMsg = By.xpath("//span[text()='* Fields are required']");
	public static By  BATCH_REPORT_LINK=By.id("fetchbatchreports");
	public static By REPORT_BTN=By.xpath("//input[@value='Report']");

	// Recon_Tab
	public static By Hold_Reconciliation_link = By.xpath("//a[@id='holdrecon']");
	public static By Hold_Invoice_Checkbox = By
			.xpath("//span[text()='Hold Invoice:']/parent::td/following-sibling::td/input[@id='holdInvoice']");

	public static By Hold_Reconciliation_Checkbox = By
			.xpath("//span[text()='Hold Reconciliation:']/parent::td/following-sibling::td/input[@id='holdRecon']");
	public static By Hold_Finance_Summarization_Checkbox = By.xpath(
			"//span[text()='Hold Finance Summarization:']/parent::td/following-sibling::td/input[@id='holdFinance']");
	public static String SYS_STATUS = "//table[@id='System_Status']/tbody/tr/td/a[contains(.,'";
	public static String OPEN_RECORDS = "')]/../following-sibling::td[contains(.,'";
	public static String BILLED_AMT = "')]/../td[contains(.,'";
	public static String CLOSE = "')]";
	public static String SYSTEM_STATUS_LINK = "//table[@id='System_Status']/tbody/tr/td[1]/a[text()='";
	public static String BRACES_CLOSE = "']";
	public static By TRACKING_OVERALL_MEDICAID_ID_FIELD = By.xpath("//input[@name='medicaidId' and @id='medicaidId']");
	public static By BULK_UPDATE_BUTTON = By.xpath("//input[@value='Bulk Update']");
	
	public static By BULK_UPDATE_FILES = By.xpath("//table[@id='displaytable']/tbody/tr");
	public static By MEMBER_DETAILS = By.xpath("//table[@id='memberDetail']/tbody/tr");
}

