package com.optum.ram.ramui;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.optum.ram.atdd.common.utils.DbQueryHelper;
import com.optum.ram.atdd.common.utils.SafeActions;
import com.optum.ram.rateUpload.RateUploadDBqueries;

public class RevenueStreamTab {
	
	public static void clickOnRevStreamTab(){
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeSwitchToFrame(RevenueStreamTabLocators.HEADER_FRAME, 10);
		safeActionsobj.safeClick(RevenueStreamTabLocators.REVENUE_TAB, 10);
		safeActionsobj.safeSwitchToDefaultFrame();
		safeActionsobj.safeSwitchToFrame(RevenueStreamTabLocators.RIGHT_FRAME, 10);
	}
	
	public static void clickOnAddRevenueStreamLink() {
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeVerify(RevenueStreamTabLocators.AddRevenueStream_link, 10);
		safeActionsobj.safeClick(RevenueStreamTabLocators.AddRevenueStream_link, 10);
	}
	public static void clickOnUpdateRevenueStreamLink() {
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeVerify(RevenueStreamTabLocators.UpdateRevenueStream_link, 10);
		safeActionsobj.safeClick(RevenueStreamTabLocators.UpdateRevenueStream_link, 10);
	}
	public static void clickOnViewRevenueStreamLink() {
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeVerify(RevenueStreamTabLocators.ViewRevenueStream_link, 10);
		safeActionsobj.safeClick(RevenueStreamTabLocators.ViewRevenueStream_link, 10);
	}
	
	public static void populateRevenueStreamDataForm(Map<String,String> formData, String testCaseId) throws InterruptedException {
		SafeActions safeActionsobj = SafeActions.getInstance();
		String BaseRevenueStream = formData.get("BASEREVENUESTREAM");
		if(BaseRevenueStream != null && BaseRevenueStream.length()>0){
			safeActionsobj.safeSelectOptionInDropDown(RevenueStreamTabLocators.baseRevenueStream_DROPDOWN, BaseRevenueStream);
		}
		String PlanName = formData.get("PLANNAME");
		if(PlanName != null && PlanName.length()>0){
			safeActionsobj.safeType(RevenueStreamTabLocators.planName_FIELD, PlanName, 10);
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, Plan Name:* ");
		}
		
		String CompanyCode = formData.get("COMPANYCODE");
		if(CompanyCode != null && CompanyCode.length()>0){
		safeActionsobj.safeType(RevenueStreamTabLocators.companyCode_FIELD, CompanyCode, 10);
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, Company Code:* ");
		}
		
		String RevenueType = formData.get("REVENUETYPE");
		if(RevenueType != null && RevenueType.length()>0){
		safeActionsobj.safeType(RevenueStreamTabLocators.revenueType_FIELD, RevenueType, 10);
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, Revenue Type:* ");
		}
		
		String SourceCode = formData.get("SOURCECODE");
		if(SourceCode != null && SourceCode.length()>0){
		safeActionsobj.safeSelectOptionInDropDown(RevenueStreamTabLocators.sourceCode_DROPDOWN, SourceCode);
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, Source Code:* ");
		}
		
		String ConfigurationEffectiveDate = formData.get("CONFIGURATIONEFFECTIVEDATE");
		if(ConfigurationEffectiveDate != null && ConfigurationEffectiveDate.length()>0){
		safeActionsobj.safeType(RevenueStreamTabLocators.effectiveDate_FIELD, ConfigurationEffectiveDate, 10);
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, Configuration Effective Date:* ");
		}
		
		String TermDate = formData.get("TERMDATE");
		if(TermDate != null && TermDate.length()>0){
		safeActionsobj.safeType(RevenueStreamTabLocators.termDate_FIELD, TermDate, 10);
		}
		
		String RSDescription = formData.get("RSDESCRIPTION");
		if(RSDescription != null && RSDescription.length()>0){
		safeActionsobj.safeType(RevenueStreamTabLocators.rsDescription_FIELD, RSDescription, 10);
		}
		
		String InvoiceEffectiveDate = formData.get("INVOICEEFFECTIVEDATE");
		if(InvoiceEffectiveDate != null && InvoiceEffectiveDate.length()>0){
		safeActionsobj.safeType(RevenueStreamTabLocators.invoiceEffectiveDate_FIELD, InvoiceEffectiveDate, 10);
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, Invoice Effective Date:* ");
		}
		
		String Go_LiveDate = formData.get("GO_LIVEDATE");
		if(Go_LiveDate != null && Go_LiveDate.length()>0){
		safeActionsobj.safeType(RevenueStreamTabLocators.implementationDate_FIELD, Go_LiveDate, 20);
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, Go-Live Date:* ");
		}
		
		String LineOfBusiness = formData.get("LINEOFBUSINESS");
		if(LineOfBusiness != null && LineOfBusiness.length()>0){
		safeActionsobj.safeType(RevenueStreamTabLocators.lineofBusiness_FIELD, LineOfBusiness, 20);
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, Line Of Business:* ");
		}
		String PDA_BackInMonth = formData.get("PDABACKINMONTHS");
		if(PDA_BackInMonth != null && PDA_BackInMonth.length()>0){
			
		}
		
		String VarianceThreshold = formData.get("VARIANCETHRESHOLD");
		if(VarianceThreshold != null  && VarianceThreshold.length()>0){
		safeActionsobj.safeTypeWithAlertMessage(RevenueStreamTabLocators.varianceThreshold_FIELD, VarianceThreshold, 20);
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, Variance Threshold $:* ");
		}
		
		String CurrentInvoice_DayOfMonth = formData.get("CURRENTINVOICE_DAYOFMONTH");
		if(CurrentInvoice_DayOfMonth != null && CurrentInvoice_DayOfMonth.length()>0){
		safeActionsobj.safeType(RevenueStreamTabLocators.currentInvoiceDayOfMonth_FIELD, CurrentInvoice_DayOfMonth, 20);
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, Current Invoice (DayOfMonth):* ");
		}
		
		String GLBusinessAccount = formData.get("GLBUSINESSACCOUNT");
		if(GLBusinessAccount != null && GLBusinessAccount.length()>0){
		safeActionsobj.safeTypeWithAlertMessage(RevenueStreamTabLocators.glBusinessAccount_FIELD, GLBusinessAccount, 20);
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, GL Business Account:* ");
		}
		
		String GLBusinessUnit = formData.get("GLBUSINESSUNIT");
		if(GLBusinessUnit != null && GLBusinessUnit.length()>0){
		safeActionsobj.safeType(RevenueStreamTabLocators.glBusinessUnit_FIELD, GLBusinessUnit, 20);
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, GL Business Unit:* ");
		}
		String paymentParameters = formData.get("PAYMENTPARAMETERS");
		if(paymentParameters != null && paymentParameters.length()>0){
			String[] paymentParameterValue = paymentParameters.split("/");
			if(paymentParameterValue != null && paymentParameterValue.length >0){
				for(String paymentParam : paymentParameterValue){
					if("Plan code".equalsIgnoreCase(paymentParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.paymentParameters_PLAN_CODE_FIELD, 10);
					}
					if("County".equalsIgnoreCase(paymentParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.paymentParameters_COUNTY_FIELD, 10);
					}
					if("Age".equalsIgnoreCase(paymentParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.paymentParameters_AGE_FIELD, 10);
					}
					if("Gender".equalsIgnoreCase(paymentParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.paymentParameters_GENDER_FIELD, 10);
					}
				}
			}
		}
		
		String invoiceParameters = formData.get("INVOICEPARAMETERS");
		if(invoiceParameters != null && invoiceParameters.length()>0){
			String[] invoiceParameterValue = invoiceParameters.split("/");
			if(invoiceParameterValue != null && invoiceParameterValue.length >0){
				for(String invoiceParam : invoiceParameterValue){
					if("Plan code".equalsIgnoreCase(invoiceParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.invoiceParameters_PLAN_CODE_FIELD, 10);
					}
					if("Gender".equalsIgnoreCase(invoiceParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.invoiceParameters_GENDER_FIELD, 10);
					}
					if("County".equalsIgnoreCase(invoiceParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.invoiceParameters_COUNTY_FIELD, 10);
					}
					if("Age".equalsIgnoreCase(invoiceParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.invoiceParameters_AGE_FIELD, 10);
					}
					if("Age including months with years".equalsIgnoreCase(invoiceParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.invoiceParameters_AGE_MONTHS_FIELD, 10);
					}
				}
			}
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, Invoice Parameters:* ");
		}
		
		String reconParameters = formData.get("RECONPARAMETERS");
		if(reconParameters != null && reconParameters.length()>0){
			String[] reconParameterValue = reconParameters.split("/");
			if(reconParameterValue != null && reconParameterValue.length >0){
				for(String reconParam : reconParameterValue){
					if("Plan code".equalsIgnoreCase(reconParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.reconParameters_PLAN_CODE_FIELD, 10);
					}
					if("County".equalsIgnoreCase(reconParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.reconParameters_COUNTY_FIELD, 10);
					}
					if("Age".equalsIgnoreCase(reconParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.reconParameters_AGE_FIELD, 10);
					}
					if("Gender".equalsIgnoreCase(reconParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.reconParameters_GENDER_FIELD, 10);
					}
				}
			}
		}
		
		String memberMatckKeyParameters = formData.get("MEMMATCHKEY");
		if(memberMatckKeyParameters != null && memberMatckKeyParameters.length()>0){
			String[] memMatchKeyParameterValue = memberMatckKeyParameters.split("/");
			if(memMatchKeyParameterValue != null && memMatchKeyParameterValue.length >0){
				for(String memMatchKeyParam : memMatchKeyParameterValue){
					if("Medicaid ID".equalsIgnoreCase(memMatchKeyParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.memberKey_MEDICAID_ID_FIELD, 10);
					}
					if("Employee Number".equalsIgnoreCase(memMatchKeyParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.memberKey_EMPLOYEE_NO_FIELD, 10);
					}
					if("SSN".equalsIgnoreCase(memMatchKeyParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.memberKey_SOCIAL_SEC_NO_FIELD, 10);
					}
					if("Subscriber ID".equalsIgnoreCase(memMatchKeyParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.memberKey_SUBSCRIBER_ID_FIELD, 10);
					}
					if("Previous Subscriber ID".equalsIgnoreCase(memMatchKeyParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.memberKey_PREV_SUBSCRIBER_ID_FIELD, 10);
					}
					if("Previous Medicaid Id".equalsIgnoreCase(memMatchKeyParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.memberKey_PREV_MEDICAID_ID_FIELD, 10);
					}
					if("Medicare No".equalsIgnoreCase(memMatchKeyParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.memberKey_MEDICARE_NO_FIELD, 10);
					}
				}
			}
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, Member Matching Key:* ");
		}
		
		String memPicLogicParameters = formData.get("MEMPICKLOGIC");
		if(memPicLogicParameters != null && memPicLogicParameters.length()>0){
			String[] memPicLogicParameterValue = memPicLogicParameters.split("/");
			if(memPicLogicParameterValue != null && memPicLogicParameterValue.length >0){
				for(String memPicLogicParam : memPicLogicParameterValue){
					if("SSN".equalsIgnoreCase(memPicLogicParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_SEC_NO_FIELD, 10);
					}
					if("Last Name".equalsIgnoreCase(memPicLogicParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_LAST_NAME_FIELD, 10);
					}
					if("First Name".equalsIgnoreCase(memPicLogicParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_FIRST_NAME_FIELD, 10);
					}
					if("County".equalsIgnoreCase(memPicLogicParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_COUNTY_CODE_FIELD, 10);
					}
					if("Gender".equalsIgnoreCase(memPicLogicParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_GENDER_FIELD, 10);
					}
					if("Date Of Birth".equalsIgnoreCase(memPicLogicParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_DATE_OF_BIRTH_FIELD, 10);
					}
					if("Family Case ID".equalsIgnoreCase(memPicLogicParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_FAMILY_CASE_ID_FIELD, 10);
					}
					
				}
			}
		}
		
		String invoiceValidateKeyParameters = formData.get("INVOICEVALIDATIONKEY");
		if(invoiceValidateKeyParameters != null && invoiceValidateKeyParameters.length()>0){
			String[] invoiceValidateKeyParameterValue = invoiceValidateKeyParameters.split("/");
			if(invoiceValidateKeyParameterValue != null && invoiceValidateKeyParameterValue.length >0){
				for(String invoiceValidateKeyParam : invoiceValidateKeyParameterValue){
					if("Missing member key".equalsIgnoreCase(invoiceValidateKeyParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_MKM_FIELD, 10);
					}
					if("Missing Family Case Id".equalsIgnoreCase(invoiceValidateKeyParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_MFC_FIELD, 10);
					}
					if("Duplicate Member Id".equalsIgnoreCase(invoiceValidateKeyParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_DMI_FIELD, 10);
					}
					if("Incorrect Head of Family Information".equalsIgnoreCase(invoiceValidateKeyParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_IHF_FIELD, 10);
					}
					if("Multiple Eligibility Segment".equalsIgnoreCase(invoiceValidateKeyParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_MES_FIELD, 10);
					}
					if("Invoice Key Missing".equalsIgnoreCase(invoiceValidateKeyParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_IKM_FIELD, 10);
					}
					if("Multiple Rates Found".equalsIgnoreCase(invoiceValidateKeyParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_MRF_FIELD, 10);
					}
					if("No Rates Found".equalsIgnoreCase(invoiceValidateKeyParam.trim())){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_NRF_FIELD, 10);
					}
				}
			}
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, Invoice Validation Key:* ");
		}
		
	
		String ForceCloseThresholdAmount = formData.get("FCL_THRESHOLDAMT");
		if(ForceCloseThresholdAmount != null && ForceCloseThresholdAmount.length()>0){
		safeActionsobj.safeType(RevenueStreamTabLocators.fclThresholdAmount_FIELD, ForceCloseThresholdAmount, 10);
		}
		
		String PickEarliestEffectivePlanCodeFlag = formData.get("PICKEARLIEST_EFFPLANCODE");
		if(PickEarliestEffectivePlanCodeFlag != null && PickEarliestEffectivePlanCodeFlag.length()>0){
		safeActionsobj.safeSelectOptionInDropDown(RevenueStreamTabLocators.proPickFirstElig_DROPDOWN, PickEarliestEffectivePlanCodeFlag);
		}
		
		safeActionsobj.safeClick(RevenueStreamTabLocators.SAVE_REVENUE_STREAM_BTN, 20);
		Thread.sleep(5000);
		
		String errorMsg = safeActionsobj.safeGetText(RevenueStreamTabLocators.REVENUE_STREAM_SAVE_ERROR_MSG, 10);
		String successMsg = safeActionsobj.safeGetText(RevenueStreamTabLocators.REVENUE_STREAM_SAVE_SUCCESS_MSG, 10);
		PageModules pageModulesobj = new PageModules();
		pageModulesobj.signout();
		Thread.sleep(3000);
		if(errorMsg != null && errorMsg.length()>0){
			Assert.fail(testCaseId + " "+errorMsg);
		}
		if(successMsg != null && successMsg.length()>0){
			Assert.assertTrue(successMsg, true);
		}
		
	}
	
	public static boolean validateRevenueDetails(Map<String, String> tdMap) {
		boolean isDataPresent = false;
		String revenueType = tdMap.get("REVENUETYPE");
		String configEffDate = tdMap.get("CONFIGURATIONEFFECTIVEDATE");
		String sourceCode = tdMap.get("SOURCECODE");
		String companyCode = tdMap.get("COMPANYCODE");
		
		SafeActions safeActionsobj = SafeActions.getInstance();		
		List<WebElement> tr = safeActionsobj.safeGetWebElementList(RevenueStreamTabLocators.REVENUE_HISTORY_DETAILS);
		Map<String, String> map = null;
		List<Map<String, String>> list = null;
		if(tr != null && tr.size()>0){
			list = new ArrayList<>();
			for (WebElement currentRow : tr) {
				List<WebElement> td_data = currentRow.findElements(By.tagName("td"));
				map = new HashMap<>();
				map.put("SourceCode", td_data.get(0).getText());
				map.put("PlanName", td_data.get(1).getText());
				map.put("CompanyCode", td_data.get(2).getText());
				map.put("RevenueType", td_data.get(3).getText());
				map.put("Go-LiveDate", td_data.get(4).getText());
				map.put("ConfigEffectiveDate", td_data.get(5).getText());
				map.put("UpdateUser", td_data.get(6).getText());
				map.put("BaseOrComponent", td_data.get(7).getText());
				list.add(map);
			}
		}
		for(Map<String, String> uiMapValue : list){
			if(uiMapValue.get("SourceCode").equalsIgnoreCase(sourceCode) && uiMapValue.get("CompanyCode").equalsIgnoreCase(companyCode) 
			 && uiMapValue.get("RevenueType").equalsIgnoreCase(revenueType) && uiMapValue.get("ConfigEffectiveDate").equalsIgnoreCase(configEffDate)){
				isDataPresent = true;
			}
		}
		return isDataPresent;
	}
	
	public static void updateRevenueStreamDetails(Map<String, String> tdMap, String testCaseId) throws NullPointerException, ClassNotFoundException, SQLException, IOException, InterruptedException {
		String planName = tdMap.get("PLANNAME");
		String revenueType = tdMap.get("REVENUETYPE");
		String configEffectiveDt = tdMap.get("CONFIGURATIONEFFECTIVEDATE");
		DbQueryHelper dbhelper = new DbQueryHelper();
		String seqRevenueId = dbhelper.getMultipleValues(String.format(RateUploadDBqueries.SEQ_REVENUE_ID, planName, revenueType));
		
		SafeActions safeActionsobj = SafeActions.getInstance();
		boolean isButtonDisabled = safeActionsobj.safeVerify(By.xpath("//tbody[@class='tblBody']/tr/td/following-sibling::td[contains(.,'"+configEffectiveDt+"')]/following-sibling::td/input[@id='recordNO[0]' and @value='Details' and contains(@onclick,'"+seqRevenueId+"')]"), 10);
		if(isButtonDisabled == false){
		safeActionsobj.safeClick(By.xpath("//tbody[@class='tblBody']/tr/td/following-sibling::td[contains(.,'"+configEffectiveDt+"')]/following-sibling::td/input[@value='Details' and contains(@onclick,'"+seqRevenueId+"')]"), 10);
		Thread.sleep(3000);
		}
		
		String TermDate = tdMap.get("TERMDATE");	
		safeActionsobj.safeClearAndType(RevenueStreamTabLocators.termDate_FIELD, TermDate, 10);
		
		String LineOfBusiness = tdMap.get("LINEOFBUSINESS");
		if(LineOfBusiness != null && LineOfBusiness.length()>0){
		safeActionsobj.safeClearAndType(RevenueStreamTabLocators.lineofBusiness_FIELD, LineOfBusiness, 20);
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, Line Of Business:* ");
		}
		String PDA_BackInMonth = tdMap.get("PDABACKINMONTHS");
		if(PDA_BackInMonth != null && PDA_BackInMonth.length()>0){
			
		}
		
		String VarianceThreshold = tdMap.get("VARIANCETHRESHOLD");
		if(VarianceThreshold != null  && VarianceThreshold.length()>0){
		safeActionsobj.safeTypeWithAlertMessage(RevenueStreamTabLocators.varianceThreshold_FIELD, VarianceThreshold, 20);
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, Variance Threshold $:* ");
		}
		
		String CurrentInvoice_DayOfMonth = tdMap.get("CURRENTINVOICE_DAYOFMONTH");
		if(CurrentInvoice_DayOfMonth != null && CurrentInvoice_DayOfMonth.length()>0){
		safeActionsobj.safeClearAndType(RevenueStreamTabLocators.currentInvoiceDayOfMonth_FIELD, CurrentInvoice_DayOfMonth, 20);
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, Current Invoice (DayOfMonth):* ");
		}
		
		String GLBusinessAccount = tdMap.get("GLBUSINESSACCOUNT");
		if(GLBusinessAccount != null && GLBusinessAccount.length()>0){
		safeActionsobj.safeTypeWithAlertMessage(RevenueStreamTabLocators.glBusinessAccount_FIELD, GLBusinessAccount, 20);
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, GL Business Account:* ");
		}
		
		String GLBusinessUnit = tdMap.get("GLBUSINESSUNIT");
		if(GLBusinessUnit != null && GLBusinessUnit.length()>0){
		safeActionsobj.safeClearAndType(RevenueStreamTabLocators.glBusinessUnit_FIELD, GLBusinessUnit, 20);
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, GL Business Unit:* ");
		}
		
		String matchExactInvoiceAndPayDate = tdMap.get("MATCHEXACTINVANDPAYDATES");
		if(matchExactInvoiceAndPayDate != null && matchExactInvoiceAndPayDate.length()>0){
		safeActionsobj.safeSelectOptionInDropDown(RevenueStreamTabLocators.INVOICE_AND_PAYMENT_DATE, matchExactInvoiceAndPayDate);
		}
		
		String distStatusCode = tdMap.get("DISTRIBUTIONSTATUSCODE");
		if(distStatusCode != null && distStatusCode.length()>0){
		safeActionsobj.safeSelectOptionInDropDown(RevenueStreamTabLocators.DIST_STATUS_CODE, distStatusCode);
		}
		
		String dataArchival = tdMap.get("DATAARCHIVAL");
		if(dataArchival != null && dataArchival.length()>0){
		safeActionsobj.safeSelectOptionInDropDown(RevenueStreamTabLocators.DATA_ARCH_FLAG, dataArchival);
		}
		
		String dataArchivalInMonth = tdMap.get("DATAARCHLBACKINMONTHS");
		safeActionsobj.safeClearAndType(RevenueStreamTabLocators.dataArcBackInMnths_FIELD, dataArchivalInMonth, 20);
		
		
		String paymentParameters = tdMap.get("PAYMENTPARAMETERS");
		if(paymentParameters != null && paymentParameters.length()>0){
			String[] paymentParameterValue = paymentParameters.split("/");
			if(paymentParameterValue != null && paymentParameterValue.length >0){
				List<String> list = new ArrayList<>(Arrays.asList(paymentParameterValue));
				
					if(list.contains("Plan code")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.paymentParameters_PLAN_CODE_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.paymentParameters_PLAN_CODE_FIELD, 10);
					}
					if(list.contains("County")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.paymentParameters_COUNTY_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.paymentParameters_COUNTY_FIELD, 10);
					}
					if(list.contains("Age")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.paymentParameters_AGE_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.paymentParameters_AGE_FIELD, 10);
					}
					if(list.contains("Gender")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.paymentParameters_GENDER_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.paymentParameters_GENDER_FIELD, 10);
					}
				}
		}
		
		String invoiceParameters = tdMap.get("INVOICEPARAMETERS");
		if(invoiceParameters != null && invoiceParameters.length()>0){
			String[] invoiceParameterValue = invoiceParameters.split("/");
			if(invoiceParameterValue != null && invoiceParameterValue.length >0){
				List<String> list = new ArrayList<>(Arrays.asList(invoiceParameterValue));
					if(list.contains("Plan code")){
						safeActionsobj.safeClickOnCheckBox(RevenueStreamTabLocators.invoiceParameters_PLAN_CODE_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.invoiceParameters_PLAN_CODE_FIELD, 10);
					}
					if(list.contains("Gender")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.invoiceParameters_GENDER_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.invoiceParameters_GENDER_FIELD, 10);
					}
					if(list.contains("County")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.invoiceParameters_COUNTY_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.invoiceParameters_COUNTY_FIELD, 10);
					}
					if(list.contains("Age")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.invoiceParameters_AGE_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.invoiceParameters_AGE_FIELD, 10);
					}
					if(list.contains("Age including months with years")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.invoiceParameters_AGE_MONTHS_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.invoiceParameters_AGE_MONTHS_FIELD, 10);
					}
			}
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, Invoice Parameters:* ");
		}
		
		String reconParameters = tdMap.get("RECONPARAMETERS");
		if(reconParameters != null && reconParameters.length()>0){
			String[] reconParameterValue = reconParameters.split("/");
			if(reconParameterValue != null && reconParameterValue.length >0){
				List<String> list = new ArrayList<>(Arrays.asList(reconParameterValue));				
					if(list.contains("Plan code")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.reconParameters_PLAN_CODE_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.reconParameters_PLAN_CODE_FIELD, 10);
					}
					if(list.contains("County")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.reconParameters_COUNTY_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.reconParameters_COUNTY_FIELD, 10);
					}
					if(list.contains("Age")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.reconParameters_AGE_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.reconParameters_AGE_FIELD, 10);
					}
					if(list.contains("Gender")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.reconParameters_GENDER_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.reconParameters_GENDER_FIELD, 10);
					}
			}
		}
		
		String memberMatckKeyParameters = tdMap.get("MEMMATCHKEY");
		if(memberMatckKeyParameters != null && memberMatckKeyParameters.length()>0){
			String[] memMatchKeyParameterValue = memberMatckKeyParameters.split("/");
			if(memMatchKeyParameterValue != null && memMatchKeyParameterValue.length >0){
				List<String> list = new ArrayList<>(Arrays.asList(memMatchKeyParameterValue));
					if(list.contains("Medicaid ID")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.memberKey_MEDICAID_ID_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.memberKey_MEDICAID_ID_FIELD, 10);
					}
					if(list.contains("Employee Number")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.memberKey_EMPLOYEE_NO_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.memberKey_EMPLOYEE_NO_FIELD, 10);
					}
					if(list.contains("SSN")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.memberKey_SOCIAL_SEC_NO_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.memberKey_SOCIAL_SEC_NO_FIELD, 10);
					}
					if(list.contains("Subscriber ID")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.memberKey_SUBSCRIBER_ID_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.memberKey_SUBSCRIBER_ID_FIELD, 10);
					}
					if(list.contains("Previous Subscriber ID")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.memberKey_PREV_SUBSCRIBER_ID_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.memberKey_PREV_SUBSCRIBER_ID_FIELD, 10);
					}
					if(list.contains("Previous Medicaid Id")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.memberKey_PREV_MEDICAID_ID_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.memberKey_PREV_MEDICAID_ID_FIELD, 10);
					}
					if(list.contains("Medicare No")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.memberKey_MEDICARE_NO_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.memberKey_MEDICARE_NO_FIELD, 10);
					}
			}
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, Member Matching Key:* ");
		}
		
		String memPicLogicParameters = tdMap.get("MEMPICKLOGIC");
		if(memPicLogicParameters != null && memPicLogicParameters.length()>0){
			String[] memPicLogicParameterValue = memPicLogicParameters.split("/");
			if(memPicLogicParameterValue != null && memPicLogicParameterValue.length >0){
				List<String> list = new ArrayList<>(Arrays.asList(memPicLogicParameterValue));
					if(list.contains("SSN")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_SEC_NO_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_SEC_NO_FIELD, 10);
					}
					if(list.contains("Last Name")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_LAST_NAME_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_LAST_NAME_FIELD, 10);
					}
					if(list.contains("First Name")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_FIRST_NAME_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_FIRST_NAME_FIELD, 10);
					}
					if(list.contains("County")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_COUNTY_CODE_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_COUNTY_CODE_FIELD, 10);
					}
					if(list.contains("Gender")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_GENDER_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_GENDER_FIELD, 10);
					}
					if(list.contains("Date Of Birth")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_DATE_OF_BIRTH_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_DATE_OF_BIRTH_FIELD, 10);
					}
					if(list.contains("Family Case ID")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_FAMILY_CASE_ID_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.memberPickLogic_SOCIAL_FAMILY_CASE_ID_FIELD, 10);
					}
			}
		}
		
		String invoiceValidateKeyParameters = tdMap.get("INVOICEVALIDATIONKEY");
		if(invoiceValidateKeyParameters != null && invoiceValidateKeyParameters.length()>0){
			String[] invoiceValidateKeyParameterValue = invoiceValidateKeyParameters.split("/");
			if(invoiceValidateKeyParameterValue != null && invoiceValidateKeyParameterValue.length >0){
				List<String> list = new ArrayList<>(Arrays.asList(invoiceValidateKeyParameterValue));
					if(list.contains("Missing member key")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_MKM_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_MKM_FIELD, 10);
					}
					if(list.contains("Missing Family Case Id")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_MFC_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_MFC_FIELD, 10);
					}
					if(list.contains("Duplicate Member Id")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_DMI_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_DMI_FIELD, 10);
					}
					if(list.contains("Incorrect Head of Family Information")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_IHF_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_IHF_FIELD, 10);
					}
					if(list.contains("Multiple Eligibility Segment")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_MES_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_MES_FIELD, 10);
					}
					if(list.contains("Invoice Key Missing")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_IKM_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_IKM_FIELD, 10);
					}
					if(list.contains("Multiple Rates Found")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_MRF_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_MRF_FIELD, 10);
					}
					if(list.contains("No Rates Found")){
						safeActionsobj.clickOnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_NRF_FIELD, 10);
					}else{
						safeActionsobj.clickToUnCheckBox(RevenueStreamTabLocators.invoiceValidate_SOCIAL_NRF_FIELD, 10);
					}
			}
		}else{
			Assert.fail(testCaseId + " Missing Mandatory Form Field, Invoice Validation Key:* ");
		}
		String ForceCloseThresholdAmount = tdMap.get("FCL_THRESHOLDAMT");
		safeActionsobj.safeClearAndType(RevenueStreamTabLocators.fclThresholdAmount_FIELD, ForceCloseThresholdAmount, 10);
		
		String PickEarliestEffectivePlanCodeFlag = tdMap.get("PICKEARLIEST_EFFPLANCODE");
		if(PickEarliestEffectivePlanCodeFlag != null && PickEarliestEffectivePlanCodeFlag.length()>0){
		safeActionsobj.safeSelectOptionInDropDown(RevenueStreamTabLocators.proPickFirstElig_DROPDOWN, PickEarliestEffectivePlanCodeFlag);
		}
		safeActionsobj.safeClick(RevenueStreamTabLocators.UPDATE_REVENUE_STREAM_BTN, 2000);
		Thread.sleep(3000);
		String successMsg = safeActionsobj.safeGetText(RevenueStreamTabLocators.REVENUE_STREAM_UPDATE_SUCCESS_MSG, 10);
		PageModules pageModulesobj = new PageModules();
		if(successMsg == null || successMsg.length() == 0){
			String errorMsg = safeActionsobj.safeGetText(RevenueStreamTabLocators.REVENUE_STREAM_UPDATE_ERROR_MSG, 10);
			pageModulesobj.signout();
			Assert.fail(testCaseId + " "+errorMsg);
		}else{
			pageModulesobj.signout();
			Assert.assertTrue(successMsg, true);
		}
		Thread.sleep(3000);
	}
	
	public static void validateViewRevenueHistory(Map<String, String> tdMap, String testCaseId) throws NullPointerException, ClassNotFoundException, SQLException, IOException, InterruptedException {
		String planName = tdMap.get("PLANNAME");
		String revenueType = tdMap.get("REVENUETYPE");
		String configEffectiveDt = tdMap.get("CONFIGURATIONEFFECTIVEDATE");
		DbQueryHelper dbhelper = new DbQueryHelper();
		String seqRevenueId = dbhelper.getMultipleValues(String.format(RateUploadDBqueries.SEQ_REVENUE_ID, planName, revenueType));
		
		SafeActions safeActionsobj = SafeActions.getInstance();
		boolean isButtonDisabled = safeActionsobj.safeVerify(By.xpath("//tbody[@class='tblBody']/tr/td/following-sibling::td[contains(.,'"+configEffectiveDt+"')]/following-sibling::td/input[@id='recordNO[0]' and @value='Details' and contains(@onclick,'"+seqRevenueId+"')]"), 10);
		if(isButtonDisabled == false){
		safeActionsobj.safeClick(By.xpath("//tbody[@class='tblBody']/tr/td/following-sibling::td[contains(.,'"+configEffectiveDt+"')]/following-sibling::td/input[@value='Details' and contains(@onclick,'"+seqRevenueId+"')]"), 10);
		Thread.sleep(3000);
		}
	}

	
}
