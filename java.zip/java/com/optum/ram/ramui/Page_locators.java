package com.optum.ram.ramui;

import org.openqa.selenium.By;

public class Page_locators {

	public interface Pagelocators {
		public static By RAM_LOGO = By.xpath("//img[@src='img/RAM-logo.png']");
		public static By USERNAME_FIELD = By.xpath("//input[@name='userId']");
		public static By PASSWORD_FIELD = By.xpath("//input[@name='password']");
		public static By LOGIN_BUTTON = By.xpath("//input[@name='Login']");
		public static By COMPANY_CODE_REVENUESTREAM_DROPDOWN = By.xpath("//select[@id='companyCode']");
		public static By REVENUE_TYPE_REVENUESTREAM_DROPDOWN = By.xpath("//select[@id='revenueType']");
		public static By CHANGE_BUTTON = By.xpath("//input[@id='Change']");
		public static By HEADER_FRAME = By.xpath("//frame[contains(@src,'page_header.jsp')]");
		public static By Home_tab = By.xpath("//a[@id='ahome']");
		public static By BATCH_REPORT_LINK = By.id("fetchbatchreports");
		public static By REPORT_NAME_DD = By.id("reportName");
		public static By RIGHT_FRAME = By.id("right_frame");
		public static By LEFT_FRAME = By.xpath("//frame[@name='left_frame']");
		public static By SIGNOUT_BUTTON = By.xpath("//input[@value='Sign Out']");

		// RATES
		public static By RATES_TAB = By.id("arate");
		public static By BULK_RATE_UPLOAD = By.xpath("//a[contains(.,'Bulk Rates Upload')]");
		public static By BROWSE_BUTTON = By.xpath("//td[text()='Please Upload file: ']/input[@name='file']");
		public static By SUBMIT_BUTTON = By.xpath("//input[@value='Submit']");
		public static String RATES_FILE_GREEN_MSG = "//span[@class='MessageGreen' and contains(.,";
		public static String RATES_FILE_NAME = "UHGVA_CAP_RATES_180529092961.xlsxFile";
		public static String RATES_SUCESS_MSG = "uploaded successfully. Tonight's batch job will process the file and notify accordingly"
				+ ")]";

		public static By RATES_LEFT_PANE = By.xpath("//select[@name='plancode1']/option");
		public static By VIEW_RATES_TAB = By.xpath("//a[text()='View Rates']");
		public static By RATES_SELECT_ALL_BTN = By.xpath("//input[@value='>>']");


		
		public static By SEARCH_BTN = By.xpath("//input[@value='Search']");
		public static By RATE_CELL_LINK = By.xpath("(//table[@id='riskGroup']/tbody//a)[4]");
		public static By PLANCODE=By.xpath("//div[@id='DisplayTables']/table/tbody/tr[1]/td");
		
		public static By RATECELL_TR=By.xpath("");
		public static By PLAN_CODES_LIST=By.xpath("//div[@id='DisplayTables']/table/tbody/tr/td[1]");
		public static By VIEW_RATES_TR=By.xpath("//table[@id='riskGroup']/tbody/tr");
		public static By RATECELL_TD=By.xpath("//table[@id='riskGroup']/tbody/tr/td/a");
		public static By RATES_TERMDATE_TD=By.xpath("//table[@id='riskGroup']/tbody/tr/td[4]");
		public static By TERMDATE_PLANCODE_TD=By.xpath("//div[@id='DisplayTables']/table/tbody/tr/td[6]");
		public static By RISKGRP1_LINK=By.xpath("//table[@id='riskGroup']/tbody/tr[1]/td/a");
		public static By TERMDATE1_FIELD=By.xpath("//table[@id='riskGroup']/tbody/tr[1]/td[4]");
		public static By PLANCODES_REVENUETYPE =By.xpath("//div[@id='DisplayTables']/table/tbody/tr/td[4]");
		//insert Rate Screen:
		public static By BACK_BUTTON=By.xpath("//img[@id='btback']");
		public static By EFFECTIVEDATE_FIELD =By.xpath("//input[@id='effectiveDate']");
		public static By TERMDATE_FIELD =By.xpath("//input[@id='termDate']");
		public static By RISKGROUP_FIELD =By.xpath("//input[@id='riskGroup']");
		public static By RATEDESCRIPTION_FIELD =By.xpath("//input[@id='rateDescription']");
		public static By GENDER_DD =By.xpath("//select[@id='gender']");
		public static By COUNTY_FIELD=By.xpath("//input[@id='county']");
		public static By AGE_FROM=By.xpath("//input[@id='ageRangeFrom']");
		public static By AGE_TO=By.xpath("//input[@id='ageRangeTo']");
		public static By GLPRODUCT=By.xpath("//input[@id='glProduct']");
		public static By COA=By.xpath("//input[@id='categoryOfAssitance']");
		public static By PROGRAMSTATUSCODE=By.xpath("//input[@id='programStatusCode']");
		public static By PRODUCT_CODE=By.xpath("//input[@id='productCode']");
		public static By ADD_BUTTON=By.xpath("//input[@value='Add']");
		public static By INSERT_RATE_LINK=By.xpath("//a[contains(@href,'title=Insert Rate') and contains(.,'Insert')]");
		public static By RATEINSERTSUCCESSMSG=By.xpath("//span[@class='MessageGreen' and contains(.,'Rate inserted successfully')]");
		//update Rates:
		public static By UPDATERATES_LINK=By.xpath("//a[contains(@href,'Update Rates')]");
		public static By RATECELL_LEFTPANE=By.xpath("//select[@name='plancode1']");
		public static By MOVESELECTEDONLYBUTTON=By.xpath("//input[@class='btn' and contains(@value,'>') and contains(@onclick,'copySelectedPlancode1')]");
		public static By RATECELL_TERMDATE_1=By.xpath("//input[@name='ratesBean[0].termDate']");
		public static By SAVE_BTN=By.xpath("//input[@value='Save']");
		public static By RATE_UPDATED_MSG=By.xpath("//span[@class='MessageGreen' and contains(.,'Rates updated successfully')]");
		public static By VOID_RATE_CHECKBOX=By.xpath("(//table[@id='ratesBean']/tbody/tr/td/input[@type='checkbox'])[1]");
		public static By NOTHINGTODISPLAY_MSG=By.xpath("//table[@id='riskGroup']/tbody/tr/td[contains(.,'Nothing found to display')]");
		//Add plancode
				public static By RISKGROUP_DD=By.xpath("//select[@id='riskGroup']");
				public static By PLANCODE_FIELD=By.xpath("//input[@id='planCode']");
				public static By RATES_SUCCESS_MSG=By.xpath("//span[@class='MessageGreen' and contains(.,'Rate inserted successfully')]");
				public static By ADDPLANCODE_LINK=By.xpath("//a[contains(@href,'Add Plancodes') and contains(.,'Add Plancodes')]");
				//View RateMatrix:
				public static By VIEWRATEMATRIX_LINK=By.xpath("//a[@id='ratematrix' and text()='View Rate Matrix']");
				public static By VIEWRATEMATRIX_TR=By.xpath("//table[@id='riskGroup']/tbody/tr");
				public static By VIEWRATEMATRIX_TD=By.xpath("//table[@id='riskGroup']/tbody/tr/td");
				public static By PLANCODE_RISKGROUPS=By.xpath("//div[@id='DisplayTables']/table/tbody/tr");
				
				
		//Recon Tab:
				public static By RECON_TAB=By.id("arecon");
				public static By HOLD_RECONCILIATION_HEADER_LINK=By.id("holdrecon");
				public static By HOLD_INVOICE_CHECKBOX=By.id("holdInvoice");
				public static By HOLD_RECONCILIATION_CHECKBOX = By
						.xpath("//span[text()='Hold Reconciliation:']/parent::td/following-sibling::td/input[@id='holdRecon']");
				public static By Hold_Finance_Summarization_Checkbox = By.xpath(
						"//span[text()='Hold Finance Summarization:']/parent::td/following-sibling::td/input[@id='holdFinance']");
				public static By CHK_INVOICEFLAG=By.xpath("//input[@id='holdInvoice' and @checked]");
				public static By CHK_RECONFLAG=By.xpath("//input[@id='holdRecon' and @checked]");
				
				public static By STATUSUPDATEDMSG=By.xpath("//span[@class='MessageGreen' and contains(.,'Status updated successfully')]");
				//Aging Report
				public static By AGINGREPORT_LINK=By.xpath("//a[@id='aging']");
				public static By AGINGHEADER_TITLE=By.xpath("//div[@class='headingMajor']/b[contains(.,'AGING REPORT AS ON')]");
				public static By AGINGREPORT_TR=By.xpath("//table[@id='agingReport']/tbody/tr");
				
				
	}

}
