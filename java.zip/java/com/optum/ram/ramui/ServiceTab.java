package com.optum.ram.ramui;

import static org.testng.Assert.fail;

import java.io.File;
import java.io.IOException;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.optum.ram.atdd.common.utils.DbQueryHelper;
import com.optum.ram.atdd.common.utils.RAMCommonDBQuires;
import com.optum.ram.atdd.common.utils.SafeActions;
import com.optum.ram.ramui.Page_locators.Pagelocators;
import com.optum.ram.rateUpload.RateUploadDBqueries;
import com.optum.ram.recon.ReconDBqueries;

public class ServiceTab {



	/**
	 * @throws InterruptedException
	 * @purpose:Click on the Service tab under homePage
	 */
	public void clickonServiceTab() throws InterruptedException {
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeSwitchToFrame(ServiceTablocators.HEADER_FRAME, 10);
		safeActionsobj.safeClick(ServiceTablocators.SERVICE_TAB, 10);
		safeActionsobj.safeSwitchToDefaultFrame();
		safeActionsobj.safeSwitchToFrame(ServiceTablocators.RIGHT_FRAME, 10);
	}

	/**
	 * @purpose:Method used to click on the Tracking OVerall link under Service
	 * tab
	 */
	public void clickOnTrackingOverallPageLink() {
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeVerify(ServiceTablocators.TrackingReportOverall_link, 10);
		safeActionsobj.safeClick(ServiceTablocators.TrackingReportOverall_link, 10);
	}

	/**
	 * @purpose:Method used to click on the Tracking Detail link under Service
	 * tab
	 */
	public void clickOnTrackingDetailPageLink() {
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeVerify(ServiceTablocators.TrackingReportDetail_link, 10);
		safeActionsobj.safeClick(ServiceTablocators.TrackingReportDetail_link, 10);
	}

	/**
	 * @throws Throwable
	 * @Purpose:Method used to enter the date fields under the TrackingOVerall Page
	 *           
	 */
	public void typeFromAndToDate(String fromDate, String toDate) throws Throwable {
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeType(ServiceTablocators.Date_From_Field, fromDate, 20);
		safeActionsobj.safeType(ServiceTablocators.Date_To_Field, toDate, 20);
		safeActionsobj.safeClick(ServiceTablocators.REPORT_BUTTON, 20);

	}

	/**
	 * @param fromDate
	 * @param toDate
	 * @Purpose:Method used to enter the date fields under the  Tracking Detail Page
	 *           
	 */
	public void enterDates(String fromDate, String toDate) {
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeType(ServiceTablocators.FROM_DATE_INPUT_FIELD, fromDate, 10);
		safeActionsobj.safeType(ServiceTablocators.TO_DATE_INPUT_FIELD, toDate, 10);
		safeActionsobj.safeClick(ServiceTablocators.REPORT_BUTTON, 10);
	}

	/**
	 * @param planName
	 * @param seqRevenueID
	 * @throws Throwable
	 * @Purpose:Method used to compare the data displayed in the TrackingOVerall page with the Db
	 *            
	 * 
	 */
	public void verifyTrackingOverallPageWithDbRecords(String planName, String seqRevenue_id, String fromDate,
			String toDate,String company_code) throws Throwable {

		DbQueryHelper dbhelper = new DbQueryHelper();

		// verify the Web Elements 'Excel 2007',CSV links & No.of records
		// displayed for the selected time period
		SafeActions safeActionsobj = SafeActions.getInstance();
		Thread.sleep(1000);
		safeActionsobj.safeVerify(ServiceTablocators.TrackingReportoverall_Header_Msg, 20);
		safeActionsobj.safeVerify(ServiceTablocators.Export_CSV_link, 10);
		safeActionsobj.safeVerify(ServiceTablocators.Export_Excel_2007_link, 10);
		safeActionsobj.safeVerify(ServiceTablocators.TrackingReportoverall_Header_Msg, 10);

		String noOfRecordsUI = safeActionsobj.safeGetText(ServiceTablocators.Noof_Items_Found_Msg, 20).split("i")[0]
				.replaceAll("\\s+$", "");

		// Executing the Query to display the No.of records in the
		// RAM_RECONCILIATION_DETAIL table based on the search time period

		String noOfRecordDb = dbhelper
				.getMultipleValues(String.format(ReconDBqueries.TRACKINGOVERALL_COUNT,company_code, fromDate, toDate));
		if (removeComma(noOfRecordsUI).equals(noOfRecordDb)) {
			System.out.print("No.of Record in RAM UI -" + noOfRecordsUI + " matched with Record Counts in Database - "
					+ noOfRecordDb + "");
			// compare the data in the displayed page with db
			compareUIDataWithDb(planName, seqRevenue_id, "");
		}

		else {
			Assert.fail("UI records Count Not matched with Db Records ..Actual UI" + noOfRecordsUI + "Actual DB records"
					+ noOfRecordDb);

		}
	}

	
	/**
	 * @param planName
	 * @param seqRevenueID
	 * @param reconStatus
	 * @throws Throwable
	 * @Purpose:Method used to validate the memberSearch page results in UI with
	 *                 the Db
	 */
	public void compareUIDataWithDb(String planName, String seqRevenueID, String reconStatus) throws Throwable {

		SafeActions safeActionsobj = SafeActions.getInstance();
		// get all the row data from UI in the list
		List<WebElement> tr = safeActionsobj.safeGetWebElementList(ServiceTablocators.ROWDATA_TRACKINGOVERALLPAGE);
		for (WebElement currentRow : tr) {
			List<String> dbRow = null;
			// get all the column values of the each row and store them in the
			// list[tdata]
			List<WebElement> tData = currentRow.findElements(By.tagName("td"));
			// get the data from the database and store them in the list[dbRow]
			if (reconStatus.equals("PSA")) {
				dbRow = getMemberSearchRowForPSA(planName, seqRevenueID, tData.get(2).getText(),
						tData.get(13).getText(), tData.get(14).getText());
			} else {
				dbRow = getMemberSearchRowFromDB(planName, seqRevenueID, tData.get(2).getText(),
						tData.get(13).getText(), tData.get(14).getText());
			}
			// compare the data between the UI list[tdata] and Db list[dbRow]
			for (int i = 2; i < tData.size() - 1; i++) {
				// added removeZeroAfterDecimal-TC057
				if (i != 15 && i != 16 && i != 17 && i != 18) {
					if (!removeZeroAfterDecimal(removeComma(removeDecimalZero(tData.get(i).getText())))
							.equals(dbRow.get(i - 2))) {

						fail("Unable to match the data for medicaid:" + tData.get(2).getText() + "UI data:"
								+ tData.get(i).getText() + "Db results:" + dbRow.get(i - 2));
					}
					System.out.println("\nUI Column" + tData.get(i).getText() + "******DB Column:" + dbRow.get(i - 2));
				} else {
					if (convertToNumberformat(tData.get(i).getText()).equals(dbRow.get(i - 2))) {
						System.out.println(
								"\nUI Column" + tData.get(i).getText() + "******DB Column:" + dbRow.get(i - 2));

					} else {
						fail("\n UI Column" + tData.get(i).getText() + "******DB Column:" + dbRow.get(i - 2));
					}
				}
			}
		}

	}

	/**
	 * @param planName
	 * @param seqRevenueID
	 * @param medicaidID
	 * @param revenue_start
	 * @param revenue_end
	 * @return
	 * @throws Throwable
	 * @purpose: Method used to return the output of Query for memberSearch
	 *           Screen Page
	 */
	public List<String> getMemberSearchRowFromDB(String planName, String seqRevenueID, String medicaidID,
			String revenue_start, String revenue_end) throws Throwable {

		String query = String.format(RateUploadDBqueries.MEMBERSEARCHPAGE_DBRESULTS, planName, seqRevenueID,
				revenue_start, revenue_end, planName, medicaidID);
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		return rcmnDbobj.getRow(query);
	}

	/**
	 * @param planName
	 * @param seqRevenueID
	 * @param medicaidID
	 * @param revenue_start
	 * @param revenue_end
	 * @return
	 * @throws Throwable
	 * @purpose : Used to return the output of Query for PSA record in
	 *          memberSearch Screen Page
	 */
	public List<String> getMemberSearchRowForPSA(String planName, String seqRevenueID, String medicaidID,
			String revenue_start, String revenue_end) throws Throwable {
		String query = String.format(RateUploadDBqueries.MEMBERSEARCH_PSA_VAL, planName, seqRevenueID, revenue_start,
				revenue_end, planName, medicaidID);
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		return rcmnDbobj.getRow(query);
	}

	/**
	 * @param planName
	 * @param seqRevenueID
	 * @param medicaidID
	 * @param revenue_start
	 * @param revenue_end
	 * @return
	 * @throws Throwable
	 * @purpose:Used to return the output of the query for demographics info in
	 *               the MemberDetail page
	 */
	public List<String> memberDemoDetailPageDb(String planName, String seqRevenueID, String medicaidID,
			String revenueMonth, String dob_UI) throws Throwable {
		String query = String.format(RateUploadDBqueries.DEMOGRAPHICS_MEMBERDETAIL, planName, planName, seqRevenueID,
				medicaidID, seqRevenueID, planName, planName, seqRevenueID, seqRevenueID, revenueMonth, dob_UI);
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		return rcmnDbobj.getRow(query);
	}

	/**
	 * @param planName
	 * @throws Throwable
	 * @purpose:Used to verify the Demo info in the memberDetail Screen with the
	 *               db.
	 * 
	 */
	public List<WebElement> memberDemoDetailTable(String planName, String seqRevenueId, String medicaid_id,
			String revenueMonth) throws Throwable {
		SafeActions safeActionsobj = SafeActions.getInstance();
		List<WebElement> td_data = null;
		List<WebElement> tr = safeActionsobj.safeGetWebElementList(ServiceTablocators.MEMBERDEMO_DETAIL_TR);
		// String
		// dob_UI=safeActionsobj.safeGetText(ServiceTablocators.MEMBERDETAIL_DOB,
		// 10);
		// List<String> dbRow =
		// memberDemoDetailPageDb(planName,seqRevenueId,medicaid_id,revenueMonth,dob_UI);
		for (WebElement currentRow : tr) {
			td_data = currentRow.findElements(By.tagName("td"));
			if (td_data.get(0).getText().equals("Nothing found to display.")) {
				System.out.println("NO Demo record found in UI");
				/*
				 * if (dbRow.isEmpty()) { System.out.
				 * println("\n There is no demo entry in MemberDetail page for mediaid_id:"
				 * +medicaid_id+"-" + dbRow); } else { System.out.
				 * println("\n There is an demo entry in MemberDetail page for mediaid_id:"
				 * +medicaid_id+"-"+ dbRow); }
				 */
			} else {
				String dob_UI = safeActionsobj.safeGetText(ServiceTablocators.MEMBERDETAIL_DOB, 10);
				List<String> dbRow = memberDemoDetailPageDb(planName, seqRevenueId, medicaid_id, revenueMonth, dob_UI);

				// List<String> DbRow =
				// memberDemoDetailPageDb(planName,seqRevenueId,medicaid_id);
				for (int i = 1; i < td_data.size(); i++) {

					if (td_data.get(i).getText().equals(dbRow.get(i))) {
						System.out.println("\n <<<<<UI Column" + td_data.get(i).getText() + "******>>>>>>>>DB Column:"
								+ dbRow.get(i));
					} else {
						Assert.fail("\nUI Column" + td_data.get(i).getText() + "******DB Column:" + dbRow.get(i));
					}

				}

			}
		}
		return td_data;
	}

	/**
	 * @param planName
	 * @throws Throwable
	 * @purpose:Used to compare the data b/w UI and db of the Eligibility info
	 *               in the memberDetail page
	 * 
	 */
	public void memberEligDetail(String planName, String seqRevenueId, String subscriber_id) throws Throwable {
		SafeActions safeActionsobj = SafeActions.getInstance();

		List<WebElement> tr = safeActionsobj.safeGetWebElementList(ServiceTablocators.MEMBERELIG_DETAIL_TR);
		List<ArrayList<String>> dbRows = memberEligDetailPageDb(planName, seqRevenueId, subscriber_id);
		String Errors = "";
		for (WebElement currentRow : tr) {
			List<WebElement> td_data = currentRow.findElements(By.tagName("td"));
			if (td_data.get(0).getText().equals("Nothing found to display.")) {
				System.out.println("NO Demo record found in UI");
				if (dbRows.isEmpty()) {
					System.out.println("\n There is no Elig entry in MemberDetail page for subscriber_id:"
							+ subscriber_id + "-" + dbRows);
				} else {
					System.out.println("\n There is an Elig entry in MemberDetail page for subscriber_id:"
							+ subscriber_id + "-" + dbRows);
				}
			} else {
				// List<ArrayList<String>> dbRows =
				// memberEligDetailPageDb(planName,seqRevenueId,subscriber_id
				// );//"110846234"
				Boolean Match = false;
				for (List<String> dbRow : dbRows) {
					String TD = "", DD = "";
					for (int i = 1; i < td_data.size(); i++) {
						TD = TD + td_data.get(i).getText();
					}
					for (int i = 1; i < dbRow.size(); i++) {
						DD = DD + dbRow.get(i);
					}
					if (TD.equals(DD)) {
						Match = true;
						break;
					}
				}
				if (Match == false) {
					Errors = Errors + "\n<<<<<<<UI Row" + currentRow.getText() + "******do not match******DB";
				}
			}
			if (Errors.length() > 0)
				fail(Errors);
		}
	}

	/**
	 * @param planName
	 * @param seqRevenueID
	 * @param subscriberID
	 * @return
	 * @throws Throwable
	 * @purpose:Used to get the db results of the EligibilityData in the
	 *               MemberDetails page
	 * 
	 */
	public List<ArrayList<String>> memberEligDetailPageDb(String planName, String seqRevenueID, String subscriberID)
			throws Throwable {
		String Query = String.format(RateUploadDBqueries.ELIGIBILITY_MEMBERDETAIL, planName, subscriberID, planName,
				seqRevenueID, seqRevenueID);
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		return rcmnDbobj.getRows(Query);

	}

	/**
	 * @param planName
	 * @throws Throwable
	 * @purpose:Used to compare the data b/w UI and Db of the Invoice info in
	 *               the memberDetail table
	 * 
	 */
	public void memberInvoiceDetail(String planName, String seqRevenueID, String subscriberID, String revenueMonth)
			throws Throwable {
		SafeActions safeActionsobj = SafeActions.getInstance();

		List<WebElement> tr = safeActionsobj.safeGetWebElementList(ServiceTablocators.MEMBERINVOICE_DETAIL_TR);
		String Errors = "";
		List<ArrayList<String>> dbRows = memberInvoiceDetailPageDb(planName, seqRevenueID, subscriberID, revenueMonth);// "07/01/2017"
		for (WebElement currentRow : tr) {
			List<WebElement> td_data = currentRow.findElements(By.tagName("td"));
			if (td_data.get(0).getText().equals("Nothing found to display.")) {
				System.out.println("NO Demo record found in UI");
				if (dbRows.isEmpty()) {
					System.out.println("\n There is no Elig entry in MemberDetail page for subscriber_id:"
							+ subscriberID + "-" + dbRows);
				} else {
					System.out.println("\n There is an Elig entry in MemberDetail page for subscriber_id:"
							+ subscriberID + "-" + dbRows);
				}
			} else {
				Boolean Match = false;
				// String TD = "", DD = "";
				for (List<String> dbRow : dbRows) {
					String TD = "", DD = "";
					for (int i = 0; i < td_data.size(); i++) {

						if (i != 6) {
							String a = td_data.get(i).getText();
							if (a.contains("(")) {
								String negativeValue = "-" + a.substring(a.indexOf("(") + 1, a.indexOf(")"));
								TD = TD + negativeValue;
								System.out.println("\n Negative Value<<<<<" + TD + ">>>>>>>>>" + TD);
							} else {
								TD = removeComma(removeZeroAfterDecimal(
										removePrefixZero(removeDecimalZeros(TD + td_data.get(i).getText()))));
							}
						}
						// TD=TD + td_data.get(i).getText();
					}
					for (int i = 0; i < dbRow.size() - 1; i++) {
						if (i != 6) {
							DD = DD + dbRow.get(i);
						}
						// DD=DD + dbRow.get(i);
					}
					if (TD.equals(DD)) {
						Match = true;
						System.out.println("Matched Successfully UI:" + TD + "And Db" + DD);
						break;
					}
				}
				if (Match == false) {
					Errors = Errors + "\nUI Row<<<<<<" + td_data + "<<<<<<do not match>>>>>>>>DB" + dbRows.get(1);
				}
			}
		}
		if (Errors.length() > 0)
			fail(Errors);

	}

	/**
	 * @param planName
	 * @param seqRevenueID
	 * @param revenueStartDate
	 * @return
	 * @throws Throwable
	 * @purpose: Used to get the db results of the Invoice info in the
	 *           MemberDetais page
	 * 
	 */

	public List<ArrayList<String>> memberInvoiceDetailPageDb(String planName, String seqRevenueID, String subscriber_id,
			String revenueStartDate) throws Throwable {
		String Query = String.format(RateUploadDBqueries.INVOICE_MEMBERDETAIL, planName, seqRevenueID, seqRevenueID,
				subscriber_id, revenueStartDate, planName, seqRevenueID, seqRevenueID, subscriber_id, subscriber_id);
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		System.out.println("The DB list size is:" + rcmnDbobj.getRow(Query));
		return rcmnDbobj.getRows(Query);

	}

	/**
	 * @param planName
	 * @throws Throwable
	 * @purpose:Used to validate the UI results of payment entry in memberDetail
	 *               page with db
	 */
	public void memberPaymentDetailPage(String planName, String seqRevenueID, String medicaid_id) throws Throwable {
		SafeActions safeActionsobj = SafeActions.getInstance();
		List<WebElement> tr = safeActionsobj.safeGetWebElementList(ServiceTablocators.MEMBERPAYMENT_DETAIL_TR);

		String Errors = "";
		for (WebElement currentRow : tr) {
			List<WebElement> td_data = currentRow.findElements(By.tagName("td"));
			if (td_data.get(0).getText().equals("Nothing found to display.")) {
				System.out.println("NO Demo record found in UI");
				/*
				 * if (dbRows.isEmpty()) { System.out.
				 * println("\n There is no Payment entry in MemberDetail page for subscriber_id:"
				 * +medicaid_id+"-" + dbRows); } else { System.out.
				 * println("\n There is an Payment entry in MemberDetail page for subscriber_id:"
				 * +medicaid_id+"-"+ dbRows); }
				 */
			} else {
				String paymentStartDateUI = safeActionsobj
						.safeGetText(ServiceTablocators.PAYMENT_STARTDATE_MEMBERDETAIL, 10);
				List<ArrayList<String>> dbRows = memberPaymentDetailPageDb(planName, seqRevenueID, medicaid_id,
						paymentStartDateUI);
				Boolean Match = false;
				String TD = "", DD = "";
				for (List<String> dbRow : dbRows) {
					for (int i = 1; i < td_data.size(); i++) {
						if (i != 6) {
							String tdata = td_data.get(i).getText();
							if (tdata.equals("NA")) {
								tdata = "";
							}
							if (i == 8) {
								tdata = convertToNumberformat(td_data.get(i).getText());

							}
							TD = removeComma(TD + tdata);
						}
					}
					for (int i = 1; i < dbRow.size(); i++) {
						DD = DD + dbRow.get(i);
					}
					if (TD.equals(DD)) {
						Match = true;
						break;
					}
				}
				if (Match == false) {
					Errors = Errors + "\n<<<<<<<UI Row" + TD + "******do not match******DB" + DD;
				}
			}
		}
		if (Errors.length() > 0)
			fail(Errors);

	}

	/**
	 * @param planName
	 * @param seqRevenueID
	 * @param revenueStartDate
	 * @return
	 * @throws Throwable
	 * @purpose Used to get the db results of the Payment info in the
	 *          MemberDetais page
	 * 
	 */

	public List<ArrayList<String>> memberPaymentDetailPageDb(String planName, String seqRevenueID, String medicaid_id,
			String paymentStartDateUI) throws Throwable {
		// Add Payment StartDate parameter from RAm UI
		String Query = String.format(RateUploadDBqueries.PAYMENT_MEMBERDETAIL, planName, seqRevenueID, seqRevenueID,
				paymentStartDateUI, planName, medicaid_id, seqRevenueID, seqRevenueID, planName, seqRevenueID,
				seqRevenueID, planName, medicaid_id, seqRevenueID, seqRevenueID);
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		System.out.println("The DB list size is:" + rcmnDbobj.getRow(Query));
		return rcmnDbobj.getRows(Query);

	}

	/**
	 * @param planName
	 * @throws Throwable
	 * @purpose:Used to validate the BNP record[having Invoice Entries and No
	 *               payment entries in the MemberDetail page]
	 * 
	 */
	public void bnpValidation(String planName, String medicaid_id, String seq_revenue_id, List<WebElement> demoInfo)
			throws Throwable {
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeVerify(By.xpath("//form[@name='memberDetailsForm']//table[@class]/tbody/tr/td[contains(.,'"
				+ demoInfo.get(1).getText() + "') and contains(.,'" + demoInfo.get(3).getText() + "') and contains(.,'"
				+ demoInfo.get(4).getText() + "')]"), 10);
		String systemStatus = safeActionsobj.safeGetText(ServiceTablocators.MEMBERDETAIL_SYSTEM_STATUS, 10);
		// String
		// paymentStartDateUI=safeActionsobj.safeGetText(ServiceTablocators.PAYMENT_STARTDATE_MEMBERDETAIL,10);
		if (systemStatus.equals("BNP -Billed Not Paid")) {
			System.out.println("The System Status is BNP.....");

			List<WebElement> tr = safeActionsobj.safeGetWebElementList(ServiceTablocators.MEMBERPAYMENT_DETAIL_TR);
			List<ArrayList<String>> dbRows = memberPaymentDetailPageDb(planName, seq_revenue_id, medicaid_id, "");
			for (WebElement currentRow : tr) {
				List<WebElement> td_data = currentRow.findElements(By.tagName("td"));

				for (int i = 0; i < td_data.size(); i++) {

					if (td_data.get(i).getText().equals("Nothing found to display.")) {
						System.out
								.println("\n <<<<<UI Column for the payment section is>>:" + td_data.get(i).getText());
						if (dbRows.isEmpty()) {
							System.out.println("\n For BNP No Db entry for the payment section" + dbRows);
						} else {
							System.out.println("\n There is Db entry for the payment section of BNP" + dbRows);
						}
					} else {
						Assert.fail("\n UI Column for the payment section is present for BNP record:"
								+ td_data.get(i).getText());
					}

				}

			}
		} else {
			Assert.fail("The System Status should be BNP-but the Actual Status is:" + systemStatus);
		}

	}

	/**
	 * @param planName
	 * @param searchParameter
	 * @param revenueMonth
	 * @throws Exception
	 * @purpose: used to validate the PNB Status in the memberDetail Screen
	 */
	public void pnbValidation(String planName, String searchParameter, String revenueMonth) throws Exception {

		SafeActions safeActionsobj = SafeActions.getInstance();
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		String[] dateformat;
		dateformat = revenueMonth.split("/");
		String systemStatus = safeActionsobj.safeGetText(ServiceTablocators.MEMBERDETAIL_SYSTEM_STATUS, 10);
		List<String> names = rcmnDbobj.getRow(String.format(ReconDBqueries.NAMES_MEMEBERDETAIL, planName,
				searchParameter, dateformat[0] + dateformat[2]));
		if (systemStatus.contains("PNB")) {
			System.out.println("\n The System Status is PNB.....");
			safeActionsobj
					.safeVerify(By.xpath("//form[@name='memberDetailsForm']//table[@class]/tbody/tr/td[contains(.,'"
							+ names.get(0) + "') and contains(.,'" + names.get(1) + "')]"), 10);
		} else {
			Assert.fail("The System Status should be PNB,but Actual status is:" + systemStatus);
		}

	}

	/**
	 * @param s
	 * @return s
	 * @purpose:Used to remove the decimal value 00 after point
	 */
	public String removeDecimalZero(String s) {
		if (s.equals(".00")) {
			String SA[] = s.split("\\.");
			String s1 = SA[0];
			return s1;
		}

		else if (s.contains(".00")) {
			String SA[] = s.split("\\.");
			String s1 = SA[0];
			return s1;
		} else {
			return s;
		}
	}

	/**
	 * @param s
	 * @purpose:Used to remove the comma from the value[i.e.For NumberFormat
	 *               conversion validation]
	 * 
	 */
	public String removeComma(String s) {
		if (s.contains(",")) {
			String s1 = s.replace(",", "");
			return s1;
		} else
			return s;

	}

	/**
	 * @param s
	 * @return
	 * @purpose:Used to remove the Zero before the point
	 */
	public String removePrefixZero(String s) {
		if (s.contains("0.")) {
			String s1 = s.replace("0.", ".");
			return s1;
		} else
			return s;

	}

	/**
	 * @param s
	 * @return
	 * @purpose:Used to remove the Zero before the point
	 */
	public String removeZeroAfterDecimal(String s) {
		if (s.contains(".0")) {
			String s1 = s.replace("0.", ".");
			return s1;
		} else
			return s;

	}

	/**
	 * @param s
	 * @return
	 * @purpose:Used to remove the decimal zero's.
	 */
	public String removeDecimalZeros(String s) {
		if (s.contains("0.00")) {
			String s1 = s.replace("0.00", "0");
			return s1;
		} else
			return s;

	}

	/**
	 * @return
	 * @throws ParseException
	 * @purpose: used to convert the String to the number format
	 */
	public String convertToNumberformat(String s) throws ParseException {
		String finalValue = "";
		if (NumberFormat.getInstance().parse(s) instanceof Double) {
			Double value = (Double) (NumberFormat.getInstance().parse(s));
			finalValue = String.valueOf(value);
		}
		if (NumberFormat.getInstance().parse(s) instanceof Long) {
			Long value = (Long) (NumberFormat.getInstance().parse(s));
			finalValue = String.valueOf(value);
		}

		System.out.println(finalValue);
		return finalValue;
	}

	/**
	 * @param medicaid_id
	 * @throws InterruptedException
	 * @purpose Used to search the member with medicaid_id in the MemberSearch
	 *          page
	 * 
	 */
	public void memberSearchWithMedicaid_id(String medicaid_id, String revenueMonth) throws InterruptedException {

		SafeActions safeActionsobj = SafeActions.getInstance();
		String[] dateformat;
		dateformat = revenueMonth.split("/");
		safeActionsobj.safeSwitchToFrame(ServiceTablocators.HEADER_FRAME, 10);
		safeActionsobj.safeVerify(ServiceTablocators.SEARCH_TAB, 10);
		safeActionsobj.safeClick(ServiceTablocators.SEARCH_TAB, 10);
		safeActionsobj.safeSwitchToDefaultFrame();
		safeActionsobj.safeSwitchToFrame(ServiceTablocators.RIGHT_FRAME, 10);
		safeActionsobj.safeType(ServiceTablocators.REVENUE_MONTH_FIELD, dateformat[0] + dateformat[2], 10);
		safeActionsobj.safeType(ServiceTablocators.MEDICAID_ID_FIELD, medicaid_id, 10);
		safeActionsobj.safeClick(ServiceTablocators.SEARCH_BTN, 10);
	}

	/**
	 * @param planName
	 * @param seqRevenueID
	 * @throws Throwable
	 * @purposse:Used to validate the memberSearch results with Db
	 */
	public void memberSearchVal(String reconStatus, String planName, String seqRevenueID, String searchParameter,
			String subscriberID, String revenueMonth, String invoiceError) throws Throwable {
		SafeActions safeActionsobj = SafeActions.getInstance();
		DbQueryHelper dbhelper = new DbQueryHelper();
		RAMCommonDBQuires RCDBQ = new RAMCommonDBQuires();
		String systemStatus = null;
	

		// verify the Web Elements 'Excel 2007',CSV links & No.of records;
		// displayed for the selected time period
		Thread.sleep(1000);
		safeActionsobj.safeVerify(ServiceTablocators.Export_CSV_link, 10);
		safeActionsobj.safeVerify(ServiceTablocators.Export_Excel_2007_link, 10);

		String noOfRecordsUI = safeActionsobj.safeGetText(ServiceTablocators.NOOFRECORDS_MEMBERDETAILS, 20)
				.split("i")[0].replaceAll("\\s+$", "");

		if (noOfRecordsUI.equals("One")) {
			noOfRecordsUI = "1";
		}

		// Executing the Query to display the No.of records in the
		// RAM_RECONCILIATION_DETAIL table based on the search time period
		String[] dateformat;
		dateformat = revenueMonth.split("/");// ,MEMEBER_SEARCH_RESULTS_COUNT
		String noOfRecordDb = dbhelper.getMultipleValues(
				String.format(ReconDBqueries.MEMEBER_SEARCH_RESULTS_COUNT_PSA, planName, searchParameter,
						dateformat[0] + dateformat[2], planName, searchParameter, dateformat[0] + dateformat[2]));
		if (removeComma(noOfRecordsUI).equals(noOfRecordDb)) {
			System.out.print("No.of Record in RAM UI :" + noOfRecordsUI + " matched with Record Counts in Database: "
					+ noOfRecordDb + "");

			compareUIDataWithDb(planName, seqRevenueID, reconStatus);
			// Click on the row to open the memberDetail page
			safeActionsobj.safeClick(ServiceTablocators.ROW_1, 10);
			Thread.sleep(2000);

			// Switching to Member Screen window
			String parentWindow = BaseSetup.driver.getWindowHandle();
			Set<String> handles = BaseSetup.driver.getWindowHandles();

			for (String windowHandle : handles) {
				BaseSetup.driver.switchTo().window(windowHandle);
				  String myTitle = BaseSetup.driver.switchTo().window(windowHandle).getTitle();
				 if( myTitle.isEmpty()){
							Assert.fail("The Open window is sessionOut,The page title is:"+myTitle); 
							BaseSetup.driver.close();
				 }
				 else{
				 if(myTitle.contains("AmeriChoice - Revenue Reconciliation")){
					 safeActionsobj.safeVerify(ServiceTablocators.MEMEBERDETAILS_HEADER_MSG, 10);
						safeActionsobj.safeVerify(ServiceTablocators.MemberDetailsForm, 10);
						safeActionsobj.safeVerify(ServiceTablocators.Member_Demographics_Table, 10);
						List<WebElement> demo_data = memberDemoDetailTable(planName, seqRevenueID, searchParameter,
								revenueMonth);
						memberEligDetail(planName, seqRevenueID, subscriberID);
						memberInvoiceDetail(planName, seqRevenueID, subscriberID, revenueMonth);																		
						memberPaymentDetailPage(planName, seqRevenueID, searchParameter);

						switch (reconStatus) {
						case "BNP":
							bnpValidation(planName, searchParameter, seqRevenueID, demo_data);
							break;
						case "PNB":
							pnbValidation(planName, searchParameter, revenueMonth);
							break;
						case "PDL":
							systemStatus = safeActionsobj.safeGetText(ServiceTablocators.MEMBERDETAIL_SYSTEM_STATUS, 10);
							dateformat = revenueMonth.split("/");
							List<String> names = RCDBQ.getRow(String.format(ReconDBqueries.NAMES_MEMEBERDETAIL, planName,
									searchParameter, dateformat[0] + dateformat[2]));
							if (systemStatus.contains("PDL")) {
								System.out.println("\n The System Status is PDL ..");
								safeActionsobj.safeVerify(
										By.xpath("//form[@name='memberDetailsForm']//table[@class]/tbody/tr/td[contains(.,'"
												+ names.get(0) + "') and contains(.,'" + names.get(1) + "')]"),
										10);
							} else {
								Assert.fail("The System Status should be PDL,but Actual status is:" + systemStatus);
							}
							break;
						case "PDH":
							systemStatus = safeActionsobj.safeGetText(ServiceTablocators.MEMBERDETAIL_SYSTEM_STATUS, 10);
							dateformat = revenueMonth.split("/");
							names = RCDBQ.getRow(String.format(ReconDBqueries.NAMES_MEMEBERDETAIL, planName,
									searchParameter, dateformat[0] + dateformat[2]));
							if (systemStatus.contains("PDH")) {
								System.out.println("\n The System Status is PDH ..");
								safeActionsobj.safeVerify(
										By.xpath("//form[@name='memberDetailsForm']//table[@class]/tbody/tr/td[contains(.,'"
												+ names.get(0) + "') and contains(.,'" + names.get(1) + "')]"),
										10);
							} else {
								Assert.fail("The System Status should be PDH,but Actual status is:" + systemStatus);
							}
							break;
						case "PSA":
							System.out.println("\n The System Status is PSA Passed ..");
							systemStatus = safeActionsobj.safeGetText(ServiceTablocators.MEMBERDETAIL_SYSTEM_STATUS, 10);
							dateformat = revenueMonth.split("/");
							names = RCDBQ.getRow(String.format(ReconDBqueries.NAME_MEMBERDETAIL_ARCHIVE, planName,
									searchParameter, dateformat[0] + dateformat[2]));
							if (systemStatus.contains("PSA")) {
								System.out.println("\n The System Status is PSA ..");
								safeActionsobj.safeVerify(
										By.xpath("//form[@name='memberDetailsForm']//table[@class]/tbody/tr/td[contains(.,'"
												+ names.get(0) + "') and contains(.,'" + names.get(1) + "')]"),
										10);
							} else {
								Assert.fail("The System Status should be PSA,but Actual status is:" + systemStatus);
							}
							break;
						case "ERR":
							systemStatus = safeActionsobj.safeGetText(ServiceTablocators.MEMBERDETAIL_SYSTEM_STATUS, 10);
							dateformat = revenueMonth.split("/");
							names = RCDBQ.getRow(String.format(ReconDBqueries.NAMES_MEMEBERDETAIL, planName,
									searchParameter, dateformat[0] + dateformat[2]));
							if (systemStatus.contains("ERR")) {
								System.out.println("\n The System Status is ERR ..");
								safeActionsobj.safeVerify(
										By.xpath("//form[@name='memberDetailsForm']//table[@class]/tbody/tr/td[contains(.,'"
												+ names.get(0) + "') and contains(.,'" + names.get(1) + "')]"),
										10);

							} else {
								Assert.fail("The System Status should be ERR,but Actual status is:" + systemStatus);
							}

							switch (invoiceError) {
							case "IKM":
								safeActionsobj.safeVerify(By.xpath("//font[contains(.,'Missing Invoice Key')]"), 10);
								break;
							case "NRF":
								safeActionsobj.safeVerify(By.xpath("//font[contains(.,'No Rate Found')]"), 10);
								break;
							case "MRF":
								safeActionsobj.safeVerify(By.xpath("//font[contains(.,'Multiple Rates found')]"), 10);
								break;
							case "MKM":
								safeActionsobj.safeVerify(By.xpath("//font[contains(.,'Missing Member Key')]"), 10);
								break;
							case "DMI":
								safeActionsobj.safeVerify(By.xpath("//font[contains(.,'Duplicate Member Identifier')]"),
										10);
								break;

							}
							break;
						}
						
						 BaseSetup.driver.close(); 	
					}
				 else{
					 BaseSetup.driver.switchTo().window(parentWindow);
				 }
				 BaseSetup.driver.switchTo().window(parentWindow);
				 }
			}
			
		}
		 
		else {
			Assert.fail("UI records Count Not matched with Db Records ..Actual Db" + noOfRecordDb + "Actual UI records:"
					+ noOfRecordsUI);
		}
			}
		
	 /*
	if (!windowHandle.equals(parentWindow)) {
		BaseSetup.driver.switchTo().window(windowHandle);

		// Member Detail Screen
		safeActionsobj.safeVerify(ServiceTablocators.MEMEBERDETAILS_HEADER_MSG, 10);
		safeActionsobj.safeVerify(ServiceTablocators.MemberDetailsForm, 10);
		safeActionsobj.safeVerify(ServiceTablocators.Member_Demographics_Table, 10);
		List<WebElement> demo_data = memberDemoDetailTable(planName, seqRevenueID, searchParameter,
				revenueMonth);
		memberEligDetail(planName, seqRevenueID, subscriberID);
		memberInvoiceDetail(planName, seqRevenueID, subscriberID, revenueMonth);// subscriberID
																				// ,revenueMonth
		memberPaymentDetailPage(planName, seqRevenueID, searchParameter);

		switch (reconStatus) {
		case "BNP":
			bnpValidation(planName, searchParameter, seqRevenueID, demo_data);
			break;
		case "PNB":
			pnbValidation(planName, searchParameter, revenueMonth);
			break;
		case "PDL":
			systemStatus = safeActionsobj.safeGetText(ServiceTablocators.MEMBERDETAIL_SYSTEM_STATUS, 10);
			dateformat = revenueMonth.split("/");
			List<String> names = RCDBQ.getRow(String.format(ReconDBqueries.NAMES_MEMEBERDETAIL, planName,
					searchParameter, dateformat[0] + dateformat[2]));
			if (systemStatus.contains("PDL")) {
				System.out.println("\n The System Status is PDL ..");
				safeActionsobj.safeVerify(
						By.xpath("//form[@name='memberDetailsForm']//table[@class]/tbody/tr/td[contains(.,'"
								+ names.get(0) + "') and contains(.,'" + names.get(1) + "')]"),
						10);
			} else {
				Assert.fail("The System Status should be PDL,but Actual status is:" + systemStatus);
			}
			break;
		case "PDH":
			systemStatus = safeActionsobj.safeGetText(ServiceTablocators.MEMBERDETAIL_SYSTEM_STATUS, 10);
			dateformat = revenueMonth.split("/");
			names = RCDBQ.getRow(String.format(ReconDBqueries.NAMES_MEMEBERDETAIL, planName,
					searchParameter, dateformat[0] + dateformat[2]));
			if (systemStatus.contains("PDH")) {
				System.out.println("\n The System Status is PDH ..");
				safeActionsobj.safeVerify(
						By.xpath("//form[@name='memberDetailsForm']//table[@class]/tbody/tr/td[contains(.,'"
								+ names.get(0) + "') and contains(.,'" + names.get(1) + "')]"),
						10);
			} else {
				Assert.fail("The System Status should be PDH,but Actual status is:" + systemStatus);
			}
			break;
		case "PSA":
			System.out.println("\n The System Status is PSA Passed ..");
			systemStatus = safeActionsobj.safeGetText(ServiceTablocators.MEMBERDETAIL_SYSTEM_STATUS, 10);
			dateformat = revenueMonth.split("/");
			names = RCDBQ.getRow(String.format(ReconDBqueries.NAME_MEMBERDETAIL_ARCHIVE, planName,
					searchParameter, dateformat[0] + dateformat[2]));
			if (systemStatus.contains("PSA")) {
				System.out.println("\n The System Status is PSA ..");
				safeActionsobj.safeVerify(
						By.xpath("//form[@name='memberDetailsForm']//table[@class]/tbody/tr/td[contains(.,'"
								+ names.get(0) + "') and contains(.,'" + names.get(1) + "')]"),
						10);
			} else {
				Assert.fail("The System Status should be PSA,but Actual status is:" + systemStatus);
			}
			break;
		case "ERR":
			systemStatus = safeActionsobj.safeGetText(ServiceTablocators.MEMBERDETAIL_SYSTEM_STATUS, 10);
			dateformat = revenueMonth.split("/");
			names = RCDBQ.getRow(String.format(ReconDBqueries.NAMES_MEMEBERDETAIL, planName,
					searchParameter, dateformat[0] + dateformat[2]));
			if (systemStatus.contains("ERR")) {
				System.out.println("\n The System Status is ERR ..");
				safeActionsobj.safeVerify(
						By.xpath("//form[@name='memberDetailsForm']//table[@class]/tbody/tr/td[contains(.,'"
								+ names.get(0) + "') and contains(.,'" + names.get(1) + "')]"),
						10);

			} else {
				Assert.fail("The System Status should be ERR,but Actual status is:" + systemStatus);
			}

			switch (invoiceError) {
			case "IKM":
				safeActionsobj.safeVerify(By.xpath("//font[contains(.,'Missing Invoice Key')]"), 10);
				break;
			case "NRF":
				safeActionsobj.safeVerify(By.xpath("//font[contains(.,'No Rate Found')]"), 10);
				break;
			case "MRF":
				safeActionsobj.safeVerify(By.xpath("//font[contains(.,'Multiple Rates found')]"), 10);
				break;
			case "MKM":
				safeActionsobj.safeVerify(By.xpath("//font[contains(.,'Missing Member Key')]"), 10);
				break;
			case "DMI":
				safeActionsobj.safeVerify(By.xpath("//font[contains(.,'Duplicate Member Identifier')]"),
						10);
				break;

			}
			break;
		}

		BaseSetup.driver.close();
	}

}

BaseSetup.driver.switchTo().window(parentWindow);
}*/

	/**
	 * @param planName
	 * @throws Exception
	 * @purpose:Used to validate the tracking detail page results with db
	 */

	public void trackingDetailVerify(String planName, String seqRevenueId, String toDate, String fromDate)
			throws Exception {
		SafeActions safeActionsobj = SafeActions.getInstance();
		DbQueryHelper dbhelper = new DbQueryHelper();

		String noOfRecordsUI = safeActionsobj.safeGetText(ServiceTablocators.PAGEBANNER_TRACKINGDETAILREPORT, 20)
				.split("i")[0].replaceAll("\\s+$", "");

		String noOfRecordDb = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.TRACKINGDETAIL_SYS_STATUS_COUNT, planName, planName));
		if (noOfRecordsUI.equals(noOfRecordDb)) {
			System.out.println("\n No.of items in UI matched with Db in tracking detail page");
			List<WebElement> tr = safeActionsobj
					.safeGetWebElementList(ServiceTablocators.ROWDATA_SYSSTATUS_TRACKINGDETAIL);
			for (WebElement currentRow : tr) {
				List<WebElement> td_data = new ArrayList<WebElement>();

				td_data = currentRow.findElements(By.tagName("td"));

				List<String> DbRow = getTrackingDetailRowFromDb(td_data.get(0).getText(), seqRevenueId, toDate,
						fromDate);
				for (int i = 1; i < td_data.size() - 1; i++) {

					if (removeDecimalZeros(removeComma((td_data.get(i).getText()))).equals(DbRow.get(i - 1))) {
						System.out.println(
								"\nUI Column" + td_data.get(i).getText() + "******DB Column:" + DbRow.get(i - 1));

					}

					else {
						Assert.fail("\nUI Column" + td_data.get(i).getText() + "******DB Column:" + DbRow.get(i - 1));
					}

				}

			}
			List<String> systStatusList = getSystemStatus_UI();
			String integer = null, decimal = null, fin = null, finP = null;

			for (String systemStatus : systStatusList) {
				List<String> dbRow = getTrackingDetailRowFromDb(systemStatus, seqRevenueId, toDate, fromDate);

				NumberFormat numberFormats = NumberFormat.getNumberInstance(Locale.US);
				if (dbRow.get(3).contains(".") || dbRow.get(4).contains(".")) {
					if (null != dbRow.get(3) || !dbRow.get(3).isEmpty()) {
						if (dbRow.get(3).contains(".")) {
							String[] numFormat3 = dbRow.get(3).split("\\.+");
							integer = numFormat3[0];
							decimal = numFormat3[1];
							fin = numberFormats.format(new Integer(integer)).concat("." + decimal + "");
						} else {
							fin = numberFormats.format(new Integer(dbRow.get(3)));
						}
					}
					if (null != dbRow.get(4) || !dbRow.get(4).isEmpty()) {
						if (dbRow.get(4).contains(".")) {
							String[] numFormat4 = dbRow.get(4).split("\\.+");
							integer = numFormat4[0];
							decimal = numFormat4[1];
							finP = numberFormats.format(new Integer(integer)).concat("." + decimal + "");

						} else {
							fin = numberFormats.format(new Integer(dbRow.get(4)));
						}
					} else {
						fin = numberFormats.format(new Integer(dbRow.get(3)));
						finP = numberFormats.format(new Integer(dbRow.get(4)));
					}
				}

				safeActionsobj.safeClick(
						By.xpath("//table[@id='System_Status']/tbody/tr/td[1]/a[text()='" + systemStatus + "']"), 10);
				safeActionsobj.safeVerify(By
						.xpath("//table/tbody/tr/td/b[contains(.,'#Closed')]/parent::td/following-sibling::td[@class='bodyText' and contains(.,'"
								+ numberFormats.format(new Integer(dbRow.get(0))) + "')]"),
						20);
				safeActionsobj.safeVerify(By
						.xpath("//table/tbody/tr/td/b[contains(.,'Status')]/parent::td/following-sibling::td[@class='bodyText' and contains(.,'"
								+ systemStatus + "')]"),
						20);
				safeActionsobj.safeVerify(By
						.xpath("//table/tbody/tr/td/b[contains(.,'#Open')]/parent::td/following-sibling::td[@class='bodyText' and contains(.,'"
								+ numberFormats.format(new Integer(dbRow.get(1))) + "')]"),
						20);
				safeActionsobj.safeVerify(By
						.xpath("//table/tbody/tr/td/b[contains(.,'#Worked')]/parent::td/following-sibling::td[@class='bodyText' and contains(.,'"
								+ numberFormats.format(new Integer(dbRow.get(2))) + "')]"),
						20);
				safeActionsobj.safeVerify(By
						.xpath("//table/tbody/tr/td/b[contains(.,'Invoice Amount')]/parent::td/following-sibling::td[@class='bodyText' and contains(.,'"
								+ fin + "')]"),
						20);
				safeActionsobj.safeVerify(By
						.xpath("//table/tbody/tr/td/b[contains(.,'Paid Amount')]/parent::td/following-sibling::td[@class='bodyText' and contains(.,'"
								+ finP + "')]"),
						20);

				safeActionsobj.safeVerify(ServiceTablocators.BACK_BTN, 10);
				safeActionsobj.safeClick(ServiceTablocators.BACK_BTN, 10);

			}
		} else {
			Assert.fail("UI records Count Not matched with Db Records ..Actual Db" + noOfRecordsUI
					+ "Actual UI records:" + noOfRecordDb);
		}
	}

	/**
	 * @return
	 * @purpose:Stores all the System Status in Tracking Detail Report Page to
	 *                 WebElement list
	 */
	public List<String> getSystemStatus_UI() {
		SafeActions safeActionsobj = SafeActions.getInstance();
		List<WebElement> listElement = safeActionsobj.safeGetWebElementList(ServiceTablocators.SYSTEM_STATUS_COLUMN);

		List<String> systStatusList = new ArrayList<String>();
		for (WebElement w : listElement) {

			String systStatus = w.getText();
			if (!systStatus.equals("null")) {
				systStatusList.add(systStatus);
				System.out.println("Size in Status List in Array list" + systStatusList.size());

			} else {
				fail("The System_status in the Tacking Detail Report page are Null");
				System.out.println("The System_status in the Tacking Detail Report page are Null");
			}
		}
		return systStatusList;
	}

	/**
	 * @param reconStatus
	 * @param seqRevenueId
	 * @param toDate
	 * @param fromDate
	 * @return
	 * @throws Exception
	 * @purpose: get the Db result of tracking detail page
	 */
	public List<String> getTrackingDetailRowFromDb(String reconStatus, String seqRevenueId, String toDate,
			String fromDate) throws Exception {
		String systemStatus = reconStatus.toString();// "100071",systemStatus,"01/18/2014","01/18/2019"
		switch (systemStatus) {
		case "BNP":
			systemStatus = "217";
			break;
		case "ERR":
			systemStatus = "222";
			break;
		case "PDH":
			systemStatus = "221";
			break;
		case "PDL":
			systemStatus = "202";
			break;
		case "PNB":
			systemStatus = "200";
			break;
		case "PSA":
			systemStatus = "203";
			break;
		}
		String query = String.format(RateUploadDBqueries.TRACKING_DETAIL_VAL, seqRevenueId, systemStatus, toDate,
				fromDate);
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		System.out.println("THE Query is:" + query);
		return rcmnDbobj.getRow(query);

	}

	/**
	 * @param uploadFile
	 * @param fileName
	 * @throws InterruptedException
	 * @purpose: upload the file in the bulkupdate screen
	 */
	public void bulkUpdate(String uploadFile, String fileName) throws InterruptedException {
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeVerify(ServiceTablocators.BULKUPDATE_LINK, 10);
		safeActionsobj.safeClick(ServiceTablocators.BULKUPDATE_LINK, 10);
		safeActionsobj.safeVerify(ServiceTablocators.BROWSE_BUTTON, 10);
		safeActionsobj.safeType(ServiceTablocators.BROWSE_BUTTON, uploadFile, 10);
		safeActionsobj.safeClick(ServiceTablocators.UPLOADFILE_BUTTON, 10);
		Thread.sleep(2000);
		safeActionsobj.safeVerify(ServiceTablocators.FILEUPLOAD_SUCCESS_MSG, 10);
		safeActionsobj.safeVerify(By.xpath("//table[@id='displaytable']//td[contains(.,'" + fileName
				+ "')]/following-sibling::td[contains(.,'Uploaded')]"), 10);

	}

	/**
	 * @param reportName
	 * @purpose: Select the reportName and click on report button
	 */
	public void batchReportScreen(String reportName) {
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeClick(ServiceTablocators.BATCH_REPORT_LINK, 10);
		safeActionsobj.safeVerify(ServiceTablocators.From_DATE, 10);
		safeActionsobj.safeVerify(ServiceTablocators.To_DATE, 10);
		safeActionsobj.safeSelectOptionInDropDown(ServiceTablocators.REPORTNAME_DD, reportName);
		safeActionsobj.safeClick(ServiceTablocators.REPORT_BTN, 10);
	}

	/**
	 * @param ErrorFileName
	 * @purpose :verify the membership Error file
	 */
	public void membershipErrorFile(String errorFileName) {
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeVerify(
				By.xpath("//table[@id='fetchMem']/tbody/tr/td[contains(.,'" + errorFileName + "')]/a"), 10);
		safeActionsobj.safeClick(By.xpath("//table[@id='fetchMem']/tbody/tr/td[contains(.,'" + errorFileName + "')]/a"),
				10);

	}

	/**
	 * @param errorFileName
	 * @purpose:
	 */
	public void bulkUpdateErrorFile(String errorFileName) {

		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeVerify(
				By.xpath("//table[@id='fetchMem']/tbody/tr/td/a[contains(.,'" + errorFileName + "')]"), 10);
		safeActionsobj.safeClick(By.xpath("//table[@id='fetch']/tbody/tr/td/a[contains(.,'" + errorFileName + "')]"),
				10);
	}
	
		public void membershipErrorFileDownLoad(String autoItFilePath, String downloadedFilePath, String ErrorFileName){
	        SafeActions SafeActionsobj = SafeActions.getInstance();
	        SafeActionsobj.safeVerify(By.xpath("//table[@id='fetchMem']/tbody/tr/td[contains(.,'"+ErrorFileName+"')]/a"), 10);
	        SafeActionsobj.safeClick(By.xpath("//table[@id='fetchMem']/tbody/tr/td[contains(.,'"+ErrorFileName+"')]/a"), 10);
	        downloadFile(autoItFilePath, downloadedFilePath, ErrorFileName);     
	
		}
	 public void bulkUpdateErrorFileDownLoad(String autoItFilePath, String downloadedFilePath, String errorFileName){
		 SafeActions SafeActionsobj = SafeActions.getInstance();
	     SafeActionsobj.safeVerify(By.xpath("//table[@id='fetch']/tbody/tr/td[contains(.,'"+errorFileName+"')]/a"), 10);
	     SafeActionsobj.safeClick(By.xpath("//table[@id='fetch']/tbody/tr/td/a[contains(.,'"+errorFileName+"')]"), 10);
	
	     downloadFile(autoItFilePath, downloadedFilePath, errorFileName);
	        
	 }

	 private void downloadFile(String autoItFilePath, String downloadedFilePath, String ErrorFileName){
		 try {
	        	//File resourceDirectory = new File("\\"+downloadedFilePath);
	        	//String absoulutePath = resourceDirectory.getAbsolutePath();
	        	File file = new File(downloadedFilePath+ErrorFileName);
	        	if(file != null && file.exists()){
	        		file.delete();
	        		Runtime.getRuntime().exec(autoItFilePath+" "+ downloadedFilePath+ErrorFileName);
	        	}else{
	        		Runtime.getRuntime().exec(autoItFilePath+" "+ downloadedFilePath+ErrorFileName);
	        	}			
				Thread.sleep(15000);
			} catch (IOException | InterruptedException e) {
				
				e.printStackTrace();
			} 
	 	}
	 
	 public void submitFieldsAndValidate(Map<String, String> tdMap) throws Throwable {
			String fromDate = tdMap.get("FROM_DATE");
			String toDate = tdMap.get("TO_DATE");
			String medicaidId = tdMap.get("MEDICAID_ID");
		
			SafeActions safeActionsobj = SafeActions.getInstance();
			safeActionsobj.safeClearAndType(ServiceTablocators.Date_From_Field, fromDate, 3000);
			safeActionsobj.safeClearAndType(ServiceTablocators.Date_To_Field, toDate, 3000);
			safeActionsobj.safeClearAndType(ServiceTablocators.TRACKING_OVERALL_MEDICAID_ID_FIELD, medicaidId, 10);
			safeActionsobj.safeClick(ServiceTablocators.BULK_UPDATE_BUTTON, 10);		
			Thread.sleep(5000);
			// Switching to new Screen window
			String parentWindow = BaseSetup.driver.getWindowHandle();
			Set<String> handles = BaseSetup.driver.getWindowHandles();
			System.out.println(" handles Size "+handles.size());
			System.out.println("&&&&&&&& "+handles);
			for (String windowHandle : handles) {
				BaseSetup.driver.switchTo().window(windowHandle);
				  String myTitle = BaseSetup.driver.switchTo().window(windowHandle).getTitle();
				  System.out.println(" ======== "+myTitle);
				  if(myTitle != null && myTitle.contains("AmeriChoice - Revenue Reconciliation")){
					  System.out.println(" AmeriChoice - Revenue Reconciliation ");
					  // Continue need to do validation...
				  }
				  if(myTitle == null || myTitle.isEmpty()){
					  System.out.println(" $$$$$$$ empty window ");
					  //BaseSetup.driver.close(); 
				  }
			}
		}
	 
	 public List<Map<String, String>> validateBulkUpdateProcess() throws InterruptedException{
			SafeActions safeActionsobj = SafeActions.getInstance();
			safeActionsobj.safeVerify(ServiceTablocators.BULKUPDATE_LINK, 10);
			safeActionsobj.safeClick(ServiceTablocators.BULKUPDATE_LINK, 10);		
			List<WebElement> tr = safeActionsobj.safeGetWebElementList(ServiceTablocators.BULK_UPDATE_FILES);
			Map<String, String> map = null;
			List<Map<String, String>> list = null;
			if(tr != null && tr.size()>0){
				list = new ArrayList<>();
				for (WebElement currentRow : tr) {
					List<WebElement> td_data = currentRow.findElements(By.tagName("td"));
					map = new HashMap<>();
					map.put("fileName", td_data.get(0).getText());
					map.put("uploadDate", td_data.get(1).getText());
					map.put("uploadBy", td_data.get(2).getText());
					map.put("status", td_data.get(2).getText());
					list.add(map);
				}
			}
			PageModules pageModulesobj = new PageModules();
			pageModulesobj.signout();
			return list;
		}
	 
	 public void validateMemberForBulkUpdate(Map<String, String> tdMap) throws InterruptedException {
			String medicaidId = tdMap.get("MEDICAID_ID");
			String revenueMonth = tdMap.get("REVENUE_MONTH");
			SafeActions safeActionsobj = SafeActions.getInstance();
			
			String[] dateformat;
			dateformat = revenueMonth.split("/");
			safeActionsobj.safeSwitchToFrame(ServiceTablocators.HEADER_FRAME, 10);
			safeActionsobj.safeVerify(ServiceTablocators.SEARCH_TAB, 10);
			safeActionsobj.safeClick(ServiceTablocators.SEARCH_TAB, 10);
			safeActionsobj.safeSwitchToDefaultFrame();
			safeActionsobj.safeSwitchToFrame(ServiceTablocators.RIGHT_FRAME, 10);
			safeActionsobj.safeType(ServiceTablocators.REVENUE_MONTH_FIELD, dateformat[0] + dateformat[2], 10);
			safeActionsobj.safeType(ServiceTablocators.MEDICAID_ID_FIELD, medicaidId, 10);
			safeActionsobj.safeClick(ServiceTablocators.SEARCH_BTN, 10);
			
			List<WebElement> tr = safeActionsobj.safeGetWebElementList(ServiceTablocators.MEMBER_DETAILS);
			Map<String, String> map = null;
			List<Map<String, String>> list = null;
			if(tr != null && tr.size()>0){
				list = new ArrayList<>();
				for (WebElement currentRow : tr) {
					List<WebElement> td_data = currentRow.findElements(By.tagName("td"));
					map = new HashMap<>();
					map.put("BilledAmount", td_data.get(15).getText());
					map.put("PaidAmount", td_data.get(16).getText());
					map.put("SystemStatus", td_data.get(19).getText());
					map.put("UserStatus", td_data.get(20).getText());
					map.put("Comments", td_data.get(21).getText());
					list.add(map);
				}
			}
			if(list != null){
				Map<String, String> mapValue = list.get(0);
				double billedAmount = Double.valueOf(mapValue.get("BilledAmount"));
				double paidAmount = Double.valueOf(mapValue.get("PaidAmount"));
				String userStatus = mapValue.get("UserStatus");
				String systemStatus = mapValue.get("SystemStatus");
				Assert.assertEquals(systemStatus, "PSA");
				if(billedAmount> paidAmount){
					Assert.assertEquals(userStatus, "WOF");
				}
				if(billedAmount < paidAmount){
					//Assert.assertEquals(userStatus, "WOF"); Confirm Status
				}
			}
			
		}

	 public void agingReport(){
			SafeActions SafeActionsobj = SafeActions.getInstance();
			SafeActionsobj.safeSwitchToDefaultFrame();
			SafeActionsobj.safeSwitchToFrame(Pagelocators.LEFT_FRAME, 10);
			SafeActionsobj.safeActionsClick(Pagelocators.AGINGREPORT_LINK, 10);
			SafeActionsobj.safeSwitchToDefaultFrame();
			SafeActionsobj.safeSwitchToFrame(Pagelocators.RIGHT_FRAME, 10);
			SafeActionsobj.safeVerify(Pagelocators.AGINGHEADER_TITLE, 10);
			SafeActionsobj.safeVerify(Pagelocators.AGINGREPORT_TR, 10);
			List<WebElement> tr = SafeActionsobj.safeGetWebElementList(Pagelocators.AGINGREPORT_TR);
			System.out.println("The No.of items on the  Aging Report page:"+tr.size());
			if(tr.size()>1){
			System.out.println("The No.of items on the  Aging Report page:"+tr.size());
			}
		}

}