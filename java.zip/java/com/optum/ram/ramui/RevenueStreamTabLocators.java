package com.optum.ram.ramui;

import org.openqa.selenium.By;

public class RevenueStreamTabLocators {
	public static By HEADER_FRAME = By.xpath("//frame[@name='header']");
	public static By REVENUE_TAB = By.xpath("//a[@id='revenue']");
	public static By RIGHT_FRAME = By.id("right_frame");
	public static By AddRevenueStream_link =By.xpath("//a[contains(.,'Add Revenue Stream')]");
	public static By UpdateRevenueStream_link =By.xpath("//a[contains(.,'Update Revenue History')]");
	public static By ViewRevenueStream_link =By.xpath("//a[contains(.,'View Revenue History')]");
	public static By baseRevenueStream_DROPDOWN = By.xpath("//select[@id='baseRevenueStream']");
	public static By planName_FIELD = By.xpath("//input[@id='planName']");
	public static By companyCode_FIELD = By.xpath("//input[@id='companyCode']");
	public static By revenueType_FIELD = By.xpath("//input[@id='revenueType']");
	public static By sourceCode_DROPDOWN = By.xpath("//select[@id='sourceCode']");
	public static By effectiveDate_FIELD = By.xpath("//input[@name='revenuedto.effectiveDate']");
	public static By termDate_FIELD = By.xpath("//input[@name='revenuedto.termDate']");
	public static By rsDescription_FIELD = By.xpath("//input[@name='revenuedto.rsDescription']");
	public static By invoiceEffectiveDate_FIELD = By.xpath("//input[@name='revenuedto.goliveDate']");	
	public static By implementationDate_FIELD = By.xpath("//input[@name='revenuedto.implementationDate']");
	public static By lineofBusiness_FIELD = By.xpath("//input[@name='revenuedto.lineofBusiness']");
	
	public static By varianceThreshold_FIELD = By.xpath("//input[@id='varianceThreshold']");
	
	public static By currentInvoiceDayOfMonth_FIELD = By.xpath("//input[@name='revenuedto.currentInvoice' and @id='currentInvoice']");
	
	public static By glBusinessAccount_FIELD = By.xpath("//input[@name='revenuedto.glBusinessAccount']");	
	public static By glBusinessUnit_FIELD = By.xpath("//input[@name='revenuedto.glBusinessUnit']");
	public static By INVOICE_AND_PAYMENT_DATE = By.xpath("//select[@name='revenuedto.invPartialMonth']");
	public static By DIST_STATUS_CODE = By.xpath("//select[@name='revenuedto.distStatusCode']");
	public static By DATA_ARCH_FLAG = By.xpath("//select[@id='dataArchivalFlag']");
	public static By dataArcBackInMnths_FIELD = By.xpath("//input[@id='dataArcBackInMnths']");
	
	
	public static By paymentParameters_PLAN_CODE_FIELD = By.xpath("//td[contains(.,'Plan code')]/input[@name='paymentParameters' and @value='PLAN_CODE']");
	public static By paymentParameters_COUNTY_FIELD = By.xpath("//td[contains(.,'Plan code')]/input[@name='paymentParameters' and @value='COUNTY']");
	public static By paymentParameters_AGE_FIELD = By.xpath("//td[contains(.,'Plan code')]/input[@name='paymentParameters' and @value='REC_AGE']");
	public static By paymentParameters_GENDER_FIELD = By.xpath("//td[contains(.,'Plan code')]/input[@name='paymentParameters' and @value='GENDER']");
	
	public static By invoiceParameters_PLAN_CODE_FIELD = By.xpath("//td[contains(.,'Plan code')]/input[@name='invoiceParameters' and @value='PLAN_CODE']");
	public static By invoiceParameters_GENDER_FIELD = By.xpath("//td[contains(.,'Plan code')]/input[@name='invoiceParameters' and @value='GENDER']");
	public static By invoiceParameters_COUNTY_FIELD = By.xpath("//td[contains(.,'Plan code')]/input[@name='invoiceParameters' and @value='COUNTY']");
	public static By invoiceParameters_AGE_FIELD = By.xpath("//td[contains(.,'Plan code')]/input[@name='invoiceParameters' and @value='AGE']");
	public static By invoiceParameters_AGE_MONTHS_FIELD = By.xpath("//td[contains(.,'Plan code')]/input[@name='invoiceParameters' and @value='AGE_MONTHS']");
	
	public static By reconParameters_PLAN_CODE_FIELD = By.xpath("//td[contains(.,'Plan Code')]/input[@name='reconParameters' and @value='PLAN_CODE']");
	public static By reconParameters_COUNTY_FIELD = By.xpath("//td[contains(.,'Plan Code')]/input[@name='reconParameters' and @value='COUNTY']");
	public static By reconParameters_AGE_FIELD = By.xpath("//td[contains(.,'Plan Code')]/input[@name='reconParameters' and @value='AGE']");
	public static By reconParameters_GENDER_FIELD = By.xpath("//td[contains(.,'Plan Code')]/input[@name='reconParameters' and @value='GENDER']");
	 
	static By memberKey_MEDICAID_ID_FIELD = By.xpath("//td[contains(.,'Medicaid ID')]/input[@name='memberKey' and @value='MEDICAID_ID']");
	static By memberKey_EMPLOYEE_NO_FIELD = By.xpath("//td[contains(.,'Medicaid ID')]/input[@name='memberKey' and @value='EMPLOYEE_NO']");
	static By memberKey_SOCIAL_SEC_NO_FIELD = By.xpath("//td[contains(.,'Medicaid ID')]/input[@name='memberKey' and @value='SOCIAL_SEC_NO']");
	static By memberKey_SUBSCRIBER_ID_FIELD = By.xpath("//td[contains(.,'Medicaid ID')]/input[@name='memberKey' and @value='SUBSCRIBER_ID']");
	static By memberKey_PREV_SUBSCRIBER_ID_FIELD = By.xpath("//td[contains(.,'Medicaid ID')]/input[@name='memberKey' and @value='PREV_SUBSCRIBER_ID']");
	static By memberKey_PREV_MEDICAID_ID_FIELD = By.xpath("//td[contains(.,'Medicaid ID')]/input[@name='memberKey' and @value='PREV_MEDICAID_ID']");
	static By memberKey_MEDICARE_NO_FIELD = By.xpath("//td[contains(.,'Medicaid ID')]/input[@name='memberKey' and @value='MEDICARE_NO']");
	
	static By memberPickLogic_SOCIAL_SEC_NO_FIELD = By.xpath("//td[contains(.,'SSN')]/input[@name='memberPickLogic' and @value='SOCIAL_SEC_NO']");
	static By memberPickLogic_SOCIAL_LAST_NAME_FIELD = By.xpath("//td[contains(.,'Last Name')]/input[@name='memberPickLogic' and @value='LAST_NAME']");
	static By memberPickLogic_SOCIAL_FIRST_NAME_FIELD = By.xpath("//td[contains(.,'First Name')]/input[@name='memberPickLogic' and @value='FIRST_NAME']");
	static By memberPickLogic_SOCIAL_COUNTY_CODE_FIELD = By.xpath("//td[contains(.,'County')]/input[@name='memberPickLogic' and @value='COUNTY_CODE']");
	static By memberPickLogic_SOCIAL_GENDER_FIELD = By.xpath("//td[contains(.,'Gender')]/input[@name='memberPickLogic' and @value='GENDER']");
	static By memberPickLogic_SOCIAL_DATE_OF_BIRTH_FIELD = By.xpath("//td[contains(.,'Date Of Birth')]/input[@name='memberPickLogic' and @value='DATE_OF_BIRTH']");
	static By memberPickLogic_SOCIAL_FAMILY_CASE_ID_FIELD = By.xpath("//td[contains(.,'Family Case ID')]/input[@name='memberPickLogic' and @value='FAMILY_CASE_ID']");
	
	static By invoiceValidate_SOCIAL_MKM_FIELD = By.xpath("//td[contains(.,'Missing member key')]/input[@name='invoiceValidate' and @value='MKM']");
	static By invoiceValidate_SOCIAL_MFC_FIELD = By.xpath("//td[contains(.,'Missing Family Case Id')]/input[@name='invoiceValidate' and @value='MFC']");
	static By invoiceValidate_SOCIAL_DMI_FIELD = By.xpath("//td[contains(.,'Duplicate Member Id')]/input[@name='invoiceValidate' and @value='DMI']");
	static By invoiceValidate_SOCIAL_IHF_FIELD = By.xpath("//td[contains(.,'Incorrect Head of Family Information')]/input[@name='invoiceValidate' and @value='IHF']");
	static By invoiceValidate_SOCIAL_MES_FIELD = By.xpath("//td[contains(.,'Multiple Eligibility Segment')]/input[@name='invoiceValidate' and @value='MES']");
	static By invoiceValidate_SOCIAL_IKM_FIELD = By.xpath("//td[contains(.,'Invoice Key Missing')]/input[@name='invoiceValidate' and @value='IKM']");
	static By invoiceValidate_SOCIAL_MRF_FIELD = By.xpath("//td[contains(.,'Multiple Rates Found')]/input[@name='invoiceValidate' and @value='MRF']");
	static By invoiceValidate_SOCIAL_NRF_FIELD = By.xpath("//td[contains(.,'No Rates Found')]/input[@name='invoiceValidate' and @value='NRF']");
	
	public static By fclThresholdAmount_FIELD = By.xpath("//input[@name='revenuedto.fclThresholdAmount' and @id='fclThresholdAmount']");
	public static By proPickFirstElig_DROPDOWN = By.xpath("//select[@name='revenuedto.proPickFirstElig']");
	
	public static By SAVE_REVENUE_STREAM_BTN = By.xpath("//input[@value='Save']");
	public static By REVENUE_STREAM_SAVE_ERROR_MSG = By.xpath("//span[@class='MessageRed']");
	public static By REVENUE_STREAM_SAVE_SUCCESS_MSG = By.xpath("//span[@class='MessageGreen']");
	public static String XPATH_REVENUE_HISTORY_DETAILS = "//tbody[@class='tblBody']/tr/td/following-sibling::td[contains(.,'%s')]/following-sibling::td/input[@value='Details' and contains(@onclick,'%s')]";
	public static By REVENUE_HISTORY_DETAILS = By.xpath("//table[@class='tblMain']/tbody/tr");
	
	public static By UPDATE_REVENUE_STREAM_BTN = By.xpath("//input[@value='Update']");
	public static By REVENUE_STREAM_UPDATE_ERROR_MSG = By.xpath("//font[contains(@style,'COLOR: red')]//li");
	public static By REVENUE_STREAM_UPDATE_SUCCESS_MSG = By.xpath("//span[@class='MessageGreen']");
	
}
