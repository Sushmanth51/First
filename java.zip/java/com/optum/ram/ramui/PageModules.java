package com.optum.ram.ramui;

import java.io.IOException;

import org.openqa.selenium.By;

import com.optum.ram.atdd.common.utils.CSPPropertyReader;
import com.optum.ram.atdd.common.utils.DbQueryHelper;
import com.optum.ram.atdd.common.utils.SafeActions;
import com.optum.ram.ramui.Page_locators.Pagelocators;
import com.optum.ram.rateUpload.RateUploadDBqueries;

public class PageModules {

	/**
	 * @throws Exception
	 * @Purpose:Used to Navigate to the RAM application URL
	 */
	public void navigateToRAMUI() throws Exception {
		System.out.println("The Ram URl is -" + CSPPropertyReader.getappUrl());
		BaseSetup.driver.get(CSPPropertyReader.getappUrl());
	}

	/**
	 * @throws IOException
	 * @throws InterruptedException
	 * @Purpose:Enter the UserName,Password for the RAM application
	 */
	public void enterCredentials() throws IOException, InterruptedException {
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeJsType(Pagelocators.USERNAME_FIELD, CSPPropertyReader.getapp_userName(), 10);
		safeActionsobj.safeJsType(Pagelocators.PASSWORD_FIELD, CSPPropertyReader.getapp_password(), 10);
		safeActionsobj.safeClick(Pagelocators.LOGIN_BUTTON,10);

	}

	/**
	 * @param companyCode
	 * @param revenueType
	 * @throws Throwable
	 * @Purpose:Selecting the State(i.e company code) and corresponding
	 * 				RevenueType from their dropDowns under Revenue Stream from left hand side
	 */
	public void selectRevenueStream(String companyCode, String revenueType) throws Throwable {
		SafeActions safeActionsobj = SafeActions.getInstance();
		Thread.sleep(4000);
		safeActionsobj.safeSwitchToFrame(Pagelocators.LEFT_FRAME,10);
		safeActionsobj.safeSelectOptionInDropDown(Pagelocators.COMPANY_CODE_REVENUESTREAM_DROPDOWN, companyCode);
		System.out.println("Selected Company Code as :" + companyCode);

		/* revenue Type selection */
		safeActionsobj.safeSelectOptionInDropDown(Pagelocators.REVENUE_TYPE_REVENUESTREAM_DROPDOWN, revenueType);
		System.out.println("Selected revenueType as :" + revenueType);
		safeActionsobj.safeClick(Pagelocators.CHANGE_BUTTON,10);
		safeActionsobj.safeSwitchToDefaultFrame();

	}

	/**
	 * @throws Exception
	 * @Purpose:Click on the Rates tab
	 */
	public void clickonRatesTab() throws Exception {
		SafeActions safeActionsobj = SafeActions.getInstance();
		// SafeActions safeActionsobj = new SafeActions(BaseSetup.driver);
		safeActionsobj.safeSwitchToFrame(Pagelocators.HEADER_FRAME, 10);
		safeActionsobj.safeClick(Pagelocators.RATES_TAB, 10);
		safeActionsobj.safeSwitchToDefaultFrame();
		safeActionsobj.safeSwitchToFrame(Pagelocators.LEFT_FRAME, 10);
	}

	/**
	 * @param text
	 * @throws InterruptedException
	 * @Purpose:Click on the bulk rates upload link and upload the rate file
	 */
	public void uploadRatefile(String rateFilePath, String rateFile) throws InterruptedException {
		SafeActions safeActionsobj = SafeActions.getInstance();
		// SafeActions safeActionsobj = new SafeActions(BaseSetup.driver);
		safeActionsobj.safeVerify(Pagelocators.BULK_RATE_UPLOAD, 10);
		safeActionsobj.safeClick(Pagelocators.BULK_RATE_UPLOAD, 10);
		safeActionsobj.safeSwitchToDefaultFrame();
		safeActionsobj.safeSwitchToFrame(Pagelocators.RIGHT_FRAME, 10);
		safeActionsobj.safeType(Pagelocators.BROWSE_BUTTON, rateFilePath, 10);
		safeActionsobj.safeVerify(Pagelocators.SUBMIT_BUTTON, 10);
		Thread.sleep(2000);
		safeActionsobj.safeClick(Pagelocators.SUBMIT_BUTTON, 10);
		safeActionsobj.safeVerify(
				By.xpath(
						"//span[@class='MessageGreen' and contains(.,'" + rateFile + " File uploaded successfully.')]"),
				10);
	}

	/**
	 * @purpose:Navigate to the View Rates Screen and perform search
	 */
	public void navigateToViewRatesAndPerformSearch() {
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeClick(Pagelocators.VIEW_RATES_TAB, 10);
		safeActionsobj.safeSwitchToDefaultFrame();
		safeActionsobj.safeSwitchToFrame(Pagelocators.RIGHT_FRAME, 10);
		safeActionsobj.safeGetText(Pagelocators.RATES_LEFT_PANE, 10);
		safeActionsobj.safeClick(Pagelocators.RATES_SELECT_ALL_BTN, 10);
		safeActionsobj.safeClick(Pagelocators.SEARCH_BTN, 10);
	}

	/**
	 * @param companyCode
	 * @throws Exception
	 * @purpose:Validate the ViewRates search results with db
	 */
	public void validateSearchResultWithDb(String companyCode) throws Exception {
		SafeActions safeActionsobj = SafeActions.getInstance();
		DbQueryHelper dbhelper = new DbQueryHelper();
		String countOfRiskGroups = dbhelper
				.getMultipleValues(String.format(RateUploadDBqueries.RISK_GROUPS_COUNT, companyCode));
		safeActionsobj.safeVerify(
				By.xpath("//span[contains(.,'" + countOfRiskGroups + " items found, displaying all items.')]"), 10);

	}

	/**
	 * Purpose : Sign out from the RAM application
	 * @throws InterruptedException 
	 */
	public void signout() throws InterruptedException {
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeSwitchToDefaultFrame();
		safeActionsobj.safeSwitchToFrame(Pagelocators.RIGHT_FRAME, 10);
		safeActionsobj.safeClick(Pagelocators.SIGNOUT_BUTTON, 20);
		safeActionsobj.safeSwitchToDefaultFrame();
		Thread.sleep(2000);
		safeActionsobj.safeVerify(Pagelocators.USERNAME_FIELD,10);

	}
}
