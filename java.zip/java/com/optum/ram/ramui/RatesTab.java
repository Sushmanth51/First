package com.optum.ram.ramui;

import static org.testng.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.optum.ram.atdd.common.utils.DbQueryHelper;
import com.optum.ram.atdd.common.utils.RAMCommonDBQuires;
import com.optum.ram.atdd.common.utils.SafeActions;
import com.optum.ram.ramui.Page_locators.Pagelocators;
import com.optum.ram.rateUpload.RateUploadDBqueries;

public class RatesTab {
	
	SafeActions safeActionsobj = SafeActions.getInstance();
	/**
	 * @throws Exception
	 * @Purpose:Click on the Rates tab
	 */
	public void clickonRatesTab() throws Exception {
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeSwitchToFrame(Pagelocators.HEADER_FRAME, 10);
		safeActionsobj.safeClick(Pagelocators.RATES_TAB, 10);
		safeActionsobj.safeSwitchToDefaultFrame();
		safeActionsobj.safeSwitchToFrame(Pagelocators.LEFT_FRAME, 10);
	}
	/**
	 * @param text
	 * @throws InterruptedException
	 * @Purpose:Click on the bulk rates upload link and upload the rate file
	 */
	public void uploadRatefile(String rateFilePath, String rateFile) throws InterruptedException {
		SafeActions safeActionsobj = SafeActions.getInstance();
		// SafeActions safeActionsobj = new SafeActions(BaseSetup.driver);
		safeActionsobj.safeVerify(Pagelocators.BULK_RATE_UPLOAD, 10);
		safeActionsobj.safeClick(Pagelocators.BULK_RATE_UPLOAD, 10);
		safeActionsobj.safeSwitchToDefaultFrame();
		safeActionsobj.safeSwitchToFrame(Pagelocators.RIGHT_FRAME, 10);
		safeActionsobj.safeType(Pagelocators.BROWSE_BUTTON, rateFilePath, 10);
		safeActionsobj.safeVerify(Pagelocators.SUBMIT_BUTTON, 10);
		Thread.sleep(2000);
		safeActionsobj.safeClick(Pagelocators.SUBMIT_BUTTON, 10);
		safeActionsobj.safeVerify(
				By.xpath(
						"//span[@class='MessageGreen' and contains(.,'" + rateFile + " File uploaded successfully.')]"),
				10);
	}

	/**
	 * @purpose:Navigate to the View Rates Screen and perform search
	 */
	public void navigateToViewRatesAndPerformSearch() {
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeClick(Pagelocators.VIEW_RATES_TAB, 10);
		safeActionsobj.safeSwitchToDefaultFrame();
		safeActionsobj.safeSwitchToFrame(Pagelocators.RIGHT_FRAME, 10);
		safeActionsobj.safeGetText(Pagelocators.RATES_LEFT_PANE, 10);
		safeActionsobj.safeClick(Pagelocators.RATES_SELECT_ALL_BTN, 10);
		safeActionsobj.safeClick(Pagelocators.SEARCH_BTN, 10);
	}

	/**
	 * @param companyCode
	 * @throws Exception
	 * @purpose:Validate the ViewRates search results with db
	 */
	public void validateSearchResultWithDb(String companyCode) throws Exception {
		SafeActions safeActionsobj = SafeActions.getInstance();
		DbQueryHelper dbhelper = new DbQueryHelper();
		String countOfRiskGroups = dbhelper
				.getMultipleValues(String.format(RateUploadDBqueries.RISK_GROUPS_COUNT, companyCode));
		safeActionsobj.safeVerify(
				By.xpath("//span[contains(.,'" + countOfRiskGroups + " items found, displaying all items.')]"), 10);

	}
	
/**
 * Purpose:Navigate to Hold Reconciliation Screen
 */
public void clickOnHoldReconLink(){
	
	SafeActions safeActionsobj = SafeActions.getInstance();
	safeActionsobj.safeSwitchToFrame(Pagelocators.HEADER_FRAME, 10);
	safeActionsobj.safeVerify(Pagelocators.RECON_TAB, 10);
	safeActionsobj.safeClick(Pagelocators.RECON_TAB, 10);
	safeActionsobj.safeSwitchToDefaultFrame();
	safeActionsobj.safeSwitchToFrame(Pagelocators.RIGHT_FRAME, 10);
	safeActionsobj.safeClick(Pagelocators.HOLD_RECONCILIATION_HEADER_LINK,10);
}

/**
 * Purpose:Verify the Status of the Invoice Flag after the Rates Job
 */
public void CheckTheStatusOfholdInvoiceFlag(){
	String HoldInvoiceFlag;
	HoldInvoiceFlag=safeActionsobj.safeGetAttribute(Pagelocators.HOLD_INVOICE_CHECKBOX,"checked",10);
	if(HoldInvoiceFlag.equals("true")){
		System.out.println("The Hold Invoice Flag is Checked Successfully after the RateUpload Job:"+HoldInvoiceFlag);
	}
	else{
		Assert.fail("The Hold Invoice Flag is not checked up on the successfully insertion of the RateUpload Process");
	}
	safeActionsobj.safeClick(Pagelocators.HOLD_INVOICE_CHECKBOX,10);
}

/**
 * @purpose:Verify the Rates in the rateMatrix table
 * @throws Throwable
 */
public void viewRatesValiadtion() throws Throwable{
	SafeActions safeActionsobj = SafeActions.getInstance();
	
	List<WebElement> tr = safeActionsobj.safeGetWebElementList(Pagelocators.VIEW_RATES_TR);
	for (WebElement currentRow : tr) {
	List<String> dbRow = null;
	List<WebElement>tdata=currentRow.findElements(By.tagName("td"));
		for (int i = 1; i < tr.size(); i++) {
			String uiData=null;
			// added removeZeroAfterDecimal
		
			dbRow = getViewRateRowsFromDB(tdata.get(1).getText());
			if(i==4){
				ServiceTab serObj=new ServiceTab();
				uiData=serObj.convertToNumberformat(tdata.get(i).getText()).toString();
			}
			else{
				uiData=tdata.get(i).getText();
			}
			
			if(uiData.equals(dbRow.get(i))){
				System.out.println("The data for RateDes:" + tr.get(1).getText() + "matched with Db UI data:"
							+ tdata.get(i).getText() + "Db results:" + dbRow.get(i));
				
				/* termdate=tdata.get(3).getText();
				System.out.println("THe Db data:"+dbRow.get(i)+"matched with UI:"+tdata.get(i).getText()+"");
				safeActionsobj.safeClick(By.xpath("//table[@id='riskGroup']/tbody/tr/td[contains(.,'"+tdata.get(0).getText()+"')]/a"), 10);
				List<WebElement>plancodeTermDates=safeActionsobj.safeGetWebElementList(Pagelocators.TERMDATE_PLANCODE_TD);
				for(WebElement date:plancodeTermDates){
					System.out.println("The TermDate is:"+date.getText());
					if(date.getText().equals(termdate)){
						System.out.println("The TermDate of the RiskGroup:"+termdate+"matched with Plancodes:"+date);
					}
					else{
						Assert.fail("The TermDate of the RiskGroup:"+termdate+"NOT Matched with Plancodes:"+date);
					}
					
				}
				safeActionsobj.safeClick(Pagelocators.BACK_BUTTON,10);
				*/
			}
			else{
					fail("Unable to match the data for RateDes:" + tr.get(1).getText() + "UI data:"
							+ tdata.get(i).getText() + "Db results:" + dbRow.get(i));
				}
			
	}
	}
}

/**
 * @param rateCell
 * @return
 * @throws Throwable
 */
public List<String> getViewRateRowsFromDB(String rateCell) throws Throwable {

	//String query = String.format(RateUploadDBqueries.VIEWRATES_VAL, planName, revenueType);
	String query = String.format(RateUploadDBqueries.VIEWRATES_VAL,rateCell);		
	RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
	return rcmnDbobj.getRow(query);}

/**
 * @param rateCell
 * @param termDate
 * Purpose:perform search in view Rates screen based on the selected Rate Cell
 */
public void navigateToViewRatesSearchonlytheSelectedRiskGroup(String rateCell,String valColumn ) {
	SafeActions safeActionsobj = SafeActions.getInstance();
	safeActionsobj.safeClick(Pagelocators.VIEW_RATES_TAB, 10);
	safeActionsobj.safeSwitchToDefaultFrame();
	safeActionsobj.safeSwitchToFrame(Pagelocators.RIGHT_FRAME, 10);
	safeActionsobj.safeClick(By.xpath("//select[@name='plancode1']/option[contains(.,'"+rateCell+"')]"), 10);
	safeActionsobj.safeClick(Pagelocators.MOVESELECTEDONLYBUTTON, 10);
	safeActionsobj.safeClick(Pagelocators.SEARCH_BTN, 10);
	safeActionsobj.safeVerify(By.xpath("(//table[@id='riskGroup']/tbody/tr[1]/td[contains(.,'"+valColumn+"')])"), 10);
}


	/**
	 * Purpose:Used to validate the update the term date is reflected correctly or not
	 */
	public void termDateValidation() {
		SafeActions safeActionsobj = SafeActions.getInstance();
		List<WebElement> plancodeTermDates = safeActionsobj.safeGetWebElementList(Pagelocators.TERMDATE_PLANCODE_TD);
		safeActionsobj.safeVerify(Pagelocators.TERMDATE1_FIELD, 10);
		String termdate = safeActionsobj.safeGetText(Pagelocators.TERMDATE1_FIELD,2000);
		//String planCode = safeActionsobj.safeGetText(Pagelocators.PLANCODES_REVENUETYPE,2000);
		System.out.println("/n The TermDate is:"+termdate);
		safeActionsobj.safeClick(Pagelocators.RISKGRP1_LINK, 10);
		for (WebElement date : plancodeTermDates) {
			System.out.println("The TermDate is:" + date.getText());
			if (date.getText().equals(termdate)) {
				System.out.println("\n The TermDate of the RiskGroup:" + termdate + "matched with Plancodes:" + date);
			} else {
				Assert.fail("The TermDate of the RiskGroup:" + termdate + "NOT Matched with Plancodes:" + date);
			}
		}
		safeActionsobj.safeVerify(Pagelocators.BACK_BUTTON, 10);
		safeActionsobj.safeClick(Pagelocators.BACK_BUTTON, 10);

	}
	
	/**
	 * @param rateCell
	 * @param companyCode
	 * @param termdate
	 * @throws Exception
	 * Purpose:Used to insert the rate from the  Insert Rates Screen
	 */
	public void insertRateField(String rateCell,String companyCode,String termdate) throws Exception{//"testAutomation"
		SafeActions safeActionsobj = SafeActions.getInstance();
		String revenueTyp[];
		safeActionsobj.safeClick(Pagelocators.INSERT_RATE_LINK, 10);
		safeActionsobj.safeSwitchToDefaultFrame();
		safeActionsobj.safeSwitchToFrame(Pagelocators.RIGHT_FRAME, 10);
		safeActionsobj.safeClearAndType(Pagelocators.TERMDATE_FIELD,termdate, 10);
		safeActionsobj.safeClearAndType(Pagelocators.EFFECTIVEDATE_FIELD,"02/18/2018", 10);
		safeActionsobj.safeClearAndType(Pagelocators.RISKGROUP_FIELD,rateCell,10);
		safeActionsobj.safeClearAndType(Pagelocators.RATEDESCRIPTION_FIELD,rateCell,10);
		DbQueryHelper dbhelper = new DbQueryHelper();
		String revenueTypes = dbhelper.getMultipleValues(
				String.format(RateUploadDBqueries.RATES_REVENUETYPE,companyCode));
		revenueTyp=revenueTypes.split(",");
		for(String revType:revenueTyp){
			System.out.println("\n The revenueType are:"+revType);
			safeActionsobj.safeClearAndType(By.xpath("//input[@value='"+revType+"']/preceding-sibling::input[@type='text']"),"250",10);	
		}
		safeActionsobj.safeSelectOptionInDropDown(Pagelocators.GENDER_DD,"Male");
		safeActionsobj.safeClearAndType(Pagelocators.COUNTY_FIELD,"123",10);
		safeActionsobj.safeClearAndType(Pagelocators.AGE_FROM,"06",10);
		safeActionsobj.safeClearAndType(Pagelocators.AGE_TO,"99",10);
		safeActionsobj.safeClearAndType(Pagelocators.GLPRODUCT,"99",10);
		safeActionsobj.safeClearAndType(Pagelocators.COA,"1234",10);
		safeActionsobj.safeClearAndType(Pagelocators.PROGRAMSTATUSCODE,"9999",10);
		safeActionsobj.safeClearAndType(Pagelocators.PRODUCT_CODE,"1199",10);
		safeActionsobj.safeClick(Pagelocators.ADD_BUTTON,10);
		safeActionsobj.safeVerify(Pagelocators.RATEINSERTSUCCESSMSG,10);	
		safeActionsobj.safeSwitchToDefaultFrame();
	}
	
	/**
	 * @param rateCell
	 * Purpose:Used to update the term date from the  Screen
	 */
	public void perfromSearchOnUpdateRateScreen(String rateCell){
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeClick(Pagelocators.UPDATERATES_LINK, 10);
		safeActionsobj.safeSwitchToDefaultFrame();
		safeActionsobj.safeSwitchToFrame(Pagelocators.RIGHT_FRAME, 10);
		safeActionsobj.safeClick(By.xpath("//select[@name='plancode1']/option[contains(.,'"+rateCell+"')]"),10);
		//safeActionsobj.safeSelectOptionInDropDown(Pagelocators.RATECELL_LEFTPANE,rateCell);
		safeActionsobj.safeClick(Pagelocators.MOVESELECTEDONLYBUTTON,10);
		safeActionsobj.safeClick(Pagelocators.SEARCH_BTN, 10);
	}
	
	/**
	 * @param termDate
	 * Purpose:Used to update the term date of the riskGroup from the UpdateRates Screen
	 */
	public void updateTheTermDate(String termDate){
		safeActionsobj.safeClearAndType(Pagelocators.RATECELL_TERMDATE_1,termDate,10);
		safeActionsobj.safeClick(Pagelocators.SAVE_BTN,10);
		safeActionsobj.safeVerify(Pagelocators.RATE_UPDATED_MSG,10);	
		safeActionsobj.safeSwitchToDefaultFrame();
	}
	
	/**
	 * @param riskGroup
	 * @param planCode
	 * Purpose:Used to addPlancode from the Add Plancodes Screen
	 */
	public void addPlanCodes(String riskGroup,String planCode){
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeClick(Pagelocators.ADDPLANCODE_LINK,10);
		safeActionsobj.safeSwitchToDefaultFrame();
		safeActionsobj.safeSwitchToFrame(Pagelocators.RIGHT_FRAME, 10);
		safeActionsobj.safeSelectOptionInDropDown(Pagelocators.RISKGROUP_DD,riskGroup);
		safeActionsobj.safeClearAndType(Pagelocators.PLANCODE_FIELD,planCode,10);
		safeActionsobj.safeClick(Pagelocators.ADD_BUTTON,10);
		safeActionsobj.safeVerify(Pagelocators.RATES_SUCCESS_MSG,10);
		safeActionsobj.safeVerify(By.xpath("//select[@id='planCodes']/option[contains(.,'"+planCode+"')]"),10);
		safeActionsobj.safeSwitchToDefaultFrame();
	}
	
	/**
	 * @throws InterruptedException
	 *  Purpose:Used to void the rate from the UpdateRates Screen
	 */
	public void voidRate() throws InterruptedException{
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeClick(Pagelocators.VOID_RATE_CHECKBOX,10);
		safeActionsobj.safeClick(Pagelocators.SAVE_BTN,10);
		Thread.sleep(3000);
		safeActionsobj.safeVerify(Pagelocators.RATE_UPDATED_MSG,10);	
		//safeActionsobj.safeVerify(Pagelocators.NOTHINGTODISPLAY_MSG,10);
		safeActionsobj.safeSwitchToDefaultFrame();
	}
	
	/**
	 * @param rateCell
	 * Purpose:Used to perform search on the rateMatrix screen
	 */
	public void viewRateMatrixPage(String rateCell){
		SafeActions safeActionsobj = SafeActions.getInstance();
		safeActionsobj.safeClick(Pagelocators.VIEWRATEMATRIX_LINK, 10);
		safeActionsobj.safeSwitchToDefaultFrame();
		safeActionsobj.safeSwitchToFrame(Pagelocators.RIGHT_FRAME, 10);
		safeActionsobj.safeClick(By.xpath("//select[@name='plancode1']/option[contains(.,'"+rateCell+"')]"),10);
		safeActionsobj.safeClick(Pagelocators.MOVESELECTEDONLYBUTTON,10);
		safeActionsobj.safeClick(Pagelocators.SEARCH_BTN, 10);
	}
	/**
	 * @throws Exception
	 * Purpose:Used to Verify the rateMatrix screen
	 */
	public void validateRateMatrix() throws Exception{
		//
		SafeActions safeActionsobj = SafeActions.getInstance();
		//ServiceTab serviceTabObj =new ServiceTab();
		// get all the row data from UI in the list
		List<WebElement> td = safeActionsobj.safeGetWebElementList(Pagelocators.VIEWRATEMATRIX_TD);
		if(td.size()>1){
		System.out.println("There items are displayed in the view RateMatrix page:"+td);
		safeActionsobj.safeVerify(Pagelocators.VIEWRATEMATRIX_TD,10);
		}
		else{
			Assert.fail("There are No items displayed in the view RateMatrix Page:"+td);
		}
	}
	
	public List<String> getTheViewMatrix(String revenue_type,String riskGroup,String seq_revenue_id) throws Exception{
		String query = String.format(RateUploadDBqueries.VIEWRATEMATRIX, revenue_type, riskGroup, seq_revenue_id);
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		return rcmnDbobj.getRow(query);
	}
	
	/**
	 * @param ratecell
	 * @param seqRevenueId
	 * @throws Exception
	 * Purpose:Used to verify the plancodes associated for the riskgroups
	 */
	public void plancodeMappingToRiskGroup(String ratecell,String seqRevenueId) throws Exception{
		SafeActions safeActionsobj = SafeActions.getInstance();
		ServiceTab serviceTabObj =new ServiceTab();
		List<ArrayList<String>> dbRowslist = null;
		dbRowslist = getThePlaCodesRiskGroup(ratecell,seqRevenueId);
		safeActionsobj.safeClick(Pagelocators.RISKGRP1_LINK, 10);
		// get all the row data from UI in the list
		safeActionsobj.safeVerify(Pagelocators.PLANCODE_RISKGROUPS, 10);
		List<WebElement> tr = safeActionsobj.safeGetWebElementList(Pagelocators.PLANCODE_RISKGROUPS);
		if(tr.size()>1){
		System.out.println("There items are displayed in the view RateMatrix page:"+tr);
		//safeActionsobj.safeVerify(Pagelocators.VIEWRATEMATRIX_TD,10);
		}
		else{
			Assert.fail("There are No items displayed in the view RateMatrix Page:"+tr);
		}
		int a=0;
		for (WebElement currentRow : tr) {
			a++;
			// get all the column values of the each row and store them in the
			// list[tdata]
			List<WebElement> tData = currentRow.findElements(By.tagName("td"));
			List<String> dbRow =dbRowslist.get((a)-1);
				for (int i = 1; i < tData.size(); i++) {
					if(i==6){
						if (serviceTabObj.convertToNumberformat(tData.get(i).getText()).equals(dbRow.get(i))) {
							System.out.println("\n The UI Data:"+tData.get(i).getText()+" Matched with DB:"+dbRow.get(i));
						}
						else{
							Assert.fail("The UI Data:"+tData.get(i).getText()+"NOT  Matched with DB:"+dbRow.get(i));
						}
						}
					else{
						if ((tData.get(i).getText()).equals(dbRow.get(i))) {
							System.out.println("\n The UI Data:"+tData.get(i).getText()+" Matched with DB:"+dbRow.get(i));
						}
						else{
							Assert.fail("The UI Data:"+tData.get(i).getText()+"NOT  Matched with DB:"+dbRow.get(i));
						}
						
					}
				}
	}
		safeActionsobj.safeClick(Pagelocators.BACK_BUTTON,10);
	}
	
	public List<ArrayList<String>> getThePlaCodesRiskGroup(String riskGroup,String seq_revenue_id) throws Exception{
		String query = String.format(RateUploadDBqueries.PLANCODES_RISKGROUP, riskGroup,seq_revenue_id,seq_revenue_id);
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		return rcmnDbobj.getRows(query);
	}
	
	/**
	 * @throws InterruptedException
	 * Purpose:Used to Hold Invoice flag in Hold ReconciliationScreen UI
	 */
	public void holdInvoiceBatch() throws InterruptedException{
		
		List<WebElement> elems = safeActionsobj.safeGetWebElementList(Pagelocators.CHK_INVOICEFLAG);
		if (elems.size() > 0) {
			System.out.println("The Hold Invoice Flag is already checked");
		}
		else{
			safeActionsobj.safeClick(Pagelocators.HOLD_INVOICE_CHECKBOX,10);
			safeActionsobj.safeClick(Pagelocators.SAVE_BTN,10);
			safeActionsobj.alertAccept();
			safeActionsobj.safeVerify(Pagelocators.STATUSUPDATEDMSG,10);
		}
	}
	
	/**
	 * @throws InterruptedException
	 * Purpose:Used to Hold Reconciliation flag in Hold ReconciliationScreen UI
	 */
	public void holdReconBatch() throws InterruptedException{
		
		List<WebElement> elems = safeActionsobj.safeGetWebElementList(Pagelocators.CHK_RECONFLAG);
		if (elems.size() > 0) {
			System.out.println("The Hold Reconciliation Flag is already checked");
		}
		else{
			safeActionsobj.safeClick(Pagelocators.HOLD_RECONCILIATION_CHECKBOX,10);
			safeActionsobj.safeClick(Pagelocators.SAVE_BTN,10);
			safeActionsobj.alertAccept();
			safeActionsobj.safeVerify(Pagelocators.STATUSUPDATEDMSG,10);
		}
	}
	
}
	

