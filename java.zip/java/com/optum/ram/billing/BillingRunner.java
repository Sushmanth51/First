/*package com.optum.ram.billing;

import java.io.IOException;
import java.sql.SQLException;

import org.testng.Assert;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@CucumberOptions(features = BillingConstants.BILLING_FEATURES, format = {
		BillingConstants.BILLING_RESULT_FORMAT }, snippets = SnippetType.CAMELCASE)
public class BillingRunner {
	static boolean jobStatus = false;
	
	public static void main(String[] args) throws Exception {
		BillingRunner billingRunner = new BillingRunner();
			
	}
	
	*//**
	 * TC001
	 * @param seqrevid
	 * Method to check whether Invoice info is available in the system or not
	 * @throws IOException 
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 *//*
	@Given("^Invoices should be present in the system for seqrevid \"([^\"]*)\"$")
	public void checkInvoiceDataPresence(String plan) throws ClassNotFoundException, SQLException, IOException {
		boolean checkStatus = false;
		BillingCommon common = new BillingCommon();
		try {
			checkStatus = common.checkInvoiceDataPresence(plan);
			if (!checkStatus) {
				Assert.fail(String.format(BillingConstants.NO_INV_DATA,plan));
			}
		} catch (Exception e) {
			Assert.fail(String.format(BillingConstants.NO_INV_DATA,plan)+e.getMessage());
		}
	}

	*//**
	 * TC001
	 * @param plan
	 * @param revId
	 * @param seqRevId
	 *//*
	@When("^Billing process should run without any errors for plan \"([^\"]*)\" and revType \"([^\"]*)\" and seqRevId \"([^\"]*)\"$")
	public void checkBatchSuccessStatus(String plan, String revType, String seqRevId) {
		BillingCommon common = new BillingCommon();
		jobStatus = common.triggerBillingJob(plan, revType, seqRevId);
		if (!jobStatus) {
			Assert.fail(BillingConstants.BILLING_JOB_FAIL);
		}
	}

	*//**
	 * TC001
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 *//*
	@Then("^Verify the status of Billing process$")
	public void verifyBatchStatus() {
		if (!jobStatus) {
			Assert.fail(BillingConstants.BILLING_JOB_FAIL);
		}
	}
	
	*//**
	 * TC002
	 * @param seqRevId
	 * Method to check the presence of BILLING HEADER data
	 * @throws SQLException 
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 *//*
	@When("^Billing records should be inserted into Bill Header table for seqRevId \"([^\"]*)\"$")
	public void checkHeaderInfoPresence(String seqRevId) throws ClassNotFoundException, IOException, SQLException{
		boolean checkStatus = false;
		BillingCommon common = new BillingCommon();
		try {
			checkStatus = common.verifyHeaderInfoPresence(seqRevId);
			if (!checkStatus) {
				Assert.fail(String.format(BillingConstants.NO_BILLING_HEADER_DATA,seqRevId));
			}
		} catch (Exception e) {
			Assert.fail(String.format(BillingConstants.NO_BILLING_HEADER_DATA,seqRevId)+e.getMessage());
		}
	}

	*//**
	 * TC002
	 * @param seqRevId
	 * Method to validate the presence of BILLING HEADER records
	 * @throws SQLException 
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 *//*
	@Then("^Verify the Billing records are created based on Invoices calculated for plan \"([^\"]*)\" and seqRevId \"([^\"]*)\"$")
	public void validateHeaderData(String plan, String seqRevId) throws ClassNotFoundException, IOException, SQLException{
		boolean checkStatus = false;
		BillingCommon common = new BillingCommon();
		try {
			checkStatus = common.validateHeaderData(plan, seqRevId);
			if (!checkStatus) {
				Assert.fail(String.format(BillingConstants.IN_COMPATABLE_HEADER_DATA,plan,seqRevId));
			}
		} catch (Exception e) {
			Assert.fail(String.format(BillingConstants.IN_COMPATABLE_HEADER_DATA,plan,seqRevId)+e.getMessage());
		}
	}
	
	
}
*/