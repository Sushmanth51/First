package com.optum.ram.billing;

public class BillingDBqueries {
	
	public static final String CHECK_INV_DATA = "SELECT 1 FROM WEB.RAM_INVOICE_DETAIL WHERE SEQ_REVENUE_ID = '%s' AND rownum =1";
	
	public static final String VALIDATE_HEADER_DATA = "select COUNT(1) from RAM_BILL_HEADER where SEQ_REVENUE_ID = '%s'";
	
	
	
	
}
