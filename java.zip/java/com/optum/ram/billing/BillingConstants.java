package com.optum.ram.billing;

public class BillingConstants {

	public static final String BILLING_FEATURES = "src/main/resources/billing/feature_files";
	
	public static final String BILLING_RESULT_FORMAT = "json:target/test_results/billing.json";
	
	public static final String BILLING_JOB_FAIL = "The Bill generation Job was failed.Please check the Server log"; 
	
	public static final String NO_BILLING_HEADER_DATA = "There is no BILLING HEADER data available in system for the seqRevId %s"; 
	
	public static final String IN_COMPATABLE_HEADER_DATA = "BILLING HEADER data is not matched with the INVOICE DETAIL data for plan %s and seqRevId %s"; 
	
	public static final String NO_INV_DATA = "No Invoice Data available in system for the plan %s"; 
	
	public static final String JOB_FEATURE_STATUS = "The Job Status Feature file is ";
	
	public static final String BILLING_VALIDATION_FAILED = "Billing validation failed for the plan %s seqRevId %s - BillingDetailIds: %s";
	
	
}
