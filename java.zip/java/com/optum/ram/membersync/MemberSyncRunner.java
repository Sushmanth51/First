package com.optum.ram.membersync;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

import com.optum.facets.atdd.common.utils.ConnectionHelper;
import com.optum.facets.atdd.common.utils.DatabaseProcessor;
import com.optum.facets.atdd.common.utils.FlatFileProcessor;
import com.optum.ram.atdd.common.utils.CSPCommonTestBase;
import com.optum.ram.atdd.common.utils.CSPPropertyReader;
import com.optum.ram.atdd.common.utils.DbQueryHelper;
import com.optum.ram.atdd.common.utils.DemoBean;
import com.optum.ram.atdd.common.utils.EligBean;
import com.optum.ram.atdd.common.utils.MappingBeanMembers;
import com.optum.ram.atdd.common.utils.RAMCommonDBQuires;
import com.optum.ram.atdd.common.utils.UnixUtilityHelper;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
@CucumberOptions(features = "src/main/resources/memberSync/feature_files", format = {
"json:target/test_results/memberSyncRunner.json" }, tags={"@DEMO"}, snippets = SnippetType.CAMELCASE)
public class MemberSyncRunner extends CSPCommonTestBase {
	public static String inputFileName = "";
	public static String eligiblityUploadExtractTDFilePath = "src/main/resources/eligibilityUpload/testdata/EligibilityUpload_TestData.xls";
	public static String eligiblityUploadExtractTDConfigTable = "ELIGIBILITY_UPLOAD_TEST_DATA_CONFIG_TABLE";
	public static String eligiblityUploadExtractTDActualTable = "ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE";

	@BeforeClass
	public void setUpClass()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException, IOException {
		super.setUpClass();
		try {

			ConnectionHelper.sqliteConnection = ConnectionHelper
					.openSqliteConnection("src/main/resources/eligibilityUpload/db_file/eligibilityUpload.db");
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String strcolnames = FlatFileProcessor.getExcelColumn(eligiblityUploadExtractTDFilePath, "Global");
		FlatFileProcessor.createConfigTable(eligiblityUploadExtractTDConfigTable, strcolnames);
		List myList;
		try {

			myList = FlatFileProcessor.readExcelData(eligiblityUploadExtractTDFilePath, "Global");
			FlatFileProcessor.createAndPopulateDetailsTableFromDataFile(myList, eligiblityUploadExtractTDConfigTable,
					eligiblityUploadExtractTDActualTable, 1, myList.size(), true);
			System.out.println("The list is" + myList);
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	static boolean JobStatus;

	@Given("^The membership data for the required plan should be loaded into the Staging tables$")
	public void the_membership_data_for_the_required_plan_should_be_loaded_into_the_Staging_tables() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^Clear out the data in the membership tables for test case \"([^\"]*)\"$")
	public void clear_out_the_data_in_the_membership_tables_for_test_case(String testCaseId) throws Throwable {
		Map<String, String> tdMap;
		try {
			DbQueryHelper DbQueryHelperobj = new DbQueryHelper();
			Statement statement;
			statement = getConnection();
			RAMCommonDBQuires rcmnDbobj=new RAMCommonDBQuires();
			tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
			DatabaseProcessor.executeSqlUpdate(statement,
					DbQueryHelperobj.backoutTables(tdMap.get("PLANNAME"), tdMap.get("EXTRACT")));
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("The data is not cleared in the db tables due to the" + e.getMessage() + "Exception");
		}
	}

	@When("^Triggered the Membersync shell job in the bin folder for \"([^\"]*)\"$$")
	public void triggered_the_Membersync_shell_job_in_the_bin_folder(String testCaseId) throws Throwable {
		RAMCommonDBQuires rcmnDbobj=new RAMCommonDBQuires();
		Map<String, String> tdMap;
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		try {
			UnixUtilityHelper UnixUtilityHelperObj = new UnixUtilityHelper();
			System.out.println("The JOB Name is:" + CSPPropertyReader.getMemberSyncJob() + tdMap.get("PLANNAME") + ".sh");
			JobStatus = UnixUtilityHelperObj.execute_unix_job_jsch(
					CSPPropertyReader.getMemberSyncJob() + tdMap.get("PLANNAME") + ".sh", CSPPropertyReader.getUnixServer(),
					CSPPropertyReader.getUnixUsername(), CSPPropertyReader.getUnixPassword());
			System.out.println("The Job Status Feature file is" + JobStatus);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("The Shell Job does not triggered properly due to the " + e.getMessage() + "Exception");
		}
	}

	@Then("^The Membersync shell job should be completed successfully without any Errors$")
	public void the_Membersync_shell_job_should_be_completed_successfully_without_any_Errors() throws Throwable {
		if (JobStatus) {
			System.out.println("The MemberSync Job ran successfully and the Status is" + JobStatus);
		}

		else {
			Assert.fail("The MemberSync Job was failed.Please check the Server log");
		}

	}

	@When("^The data should be moved to ram membership tables from the Staging tables for \"([^\"]*)\"$")
	public void verifyDataMovedToRamMembership(String testcaseID) throws Throwable {
		MemberSyncCommon MemberSyncCommonobj = new MemberSyncCommon();
		try {
			MemberSyncCommonobj.dataMovedtoMembershipTables(testcaseID);
		} catch (Exception e) {
			Assert.fail("The data is not moved to ram membership table due to:" + e.getMessage() + "Exception");
		}

	}

	@Then("^Validate the data in the ram membership tables for the \"([^\"]*)\"$")
	public void validate_the_data_in_the_ram_membership_tables_for_the(String testcaseId) throws Throwable {
		MappingBeanMembers mpobj = new MappingBeanMembers();
		try {
			Map<DemoBean, List<EligBean>> memberInfoGroupID = mpobj.memberShipFileMapping(testcaseId);
			mpobj.verifyDataInRamMembershiptables(memberInfoGroupID, testcaseId);
		} catch (Exception e) {
			Assert.fail("The data is not matched with ram membership table due to:" + e.getMessage() + "Exception");
		}
	}

	@Given("^The data should be present in the ram membership tables$")
	public void the_data_should_be_present_in_the_ram_membership_tables() throws Throwable {

	}

	@When("^verify the count of records between the staging and ram membership tables for \"([^\"]*)\"$")
	public void verify_the_count_of_records_between_the_staging_and_ram_membership_tables_for(String testcaseId)
			throws Throwable {
		MemberSyncCommon MemberSyncCommonobj = new MemberSyncCommon();
		try {
			MemberSyncCommonobj.membershipTablesCountValidation(testcaseId);
		} catch (Exception e) {
			Assert.fail("The records counts in Staging tables not matched with ram membership table due to:"
					+ e.getMessage() + "Exception");
		}
	}

	@When("^verify the companyCode value  for all the members are populated based on the Xwalk table for \"([^\"]*)\"$")
	public void verifyCompanyCodeInMembershipTables(String testcaseId) throws Throwable {
		MemberSyncCommon memberSyncCommonobj = new MemberSyncCommon();
		try {
			memberSyncCommonobj.companCodeValidation(testcaseId);
		} catch (Exception e) {
			Assert.fail("The CompanyCode value in ram membership table not populated correctly due to:" + e.getMessage()
					+ "Exception");
		}

	}

	@When("^verify the LineOfBusiness\\[LOB\\] value  for all the members are populated based on the Xwalk table for \"([^\"]*)\"$")
	public void verify_the_LineOfBusiness_LOB_value_for_all_the_members_are_populated_based_on_the_Xwalk_table_for(
			String testcaseId) throws Throwable {
		MemberSyncCommon memberSyncCommonobj = new MemberSyncCommon();
		try {
			memberSyncCommonobj.companCodeValidation(testcaseId);
		} catch (Exception e) {
			Assert.fail("The LOB value in ram membership table not populated correctly due to:" + e.getMessage()
					+ "Exception");
		}

	}
	
}
