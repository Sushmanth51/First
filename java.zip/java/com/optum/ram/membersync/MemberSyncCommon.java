package com.optum.ram.membersync;

import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;

import com.optum.ram.atdd.common.utils.CSPCommonTestBase;
import com.optum.ram.atdd.common.utils.DbQueryHelper;
import com.optum.ram.atdd.common.utils.RAMCommonDBQuires;
import com.optum.ram.atdd.eligibility.eligibilityUpload.EligibilityDBqueries;

public class MemberSyncCommon extends CSPCommonTestBase {
	DbQueryHelper DbQueryHelperobj = new DbQueryHelper();
	
	/**
	 * @purpose Method used to validate the count between the fileData Staging and ram membership tables
	 * @throws Exception
	 */
	public void membershipTablesCountValidation(String testCaseId) throws Exception{
	
		Statement statement;
		statement = getConnection();
		Map<String, String> tdMap = new HashMap<String, String>();
		RAMCommonDBQuires rcmnDbobj=new RAMCommonDBQuires();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		Map<String, String>tdMap1 = rcmnDbobj.getTestDataBykeycolumn("batch_cntrl",null,null);
		String demoRecordCountMembershipTables = DbQueryHelperobj
				.getMultipleValues(String.format(MemberSyncDBqueries.COUNT_DEMO_MEMEBERS,tdMap.get("PLANNAME")));
		String eligRecordCountMembershipTables = DbQueryHelperobj
				.getMultipleValues(String.format(MemberSyncDBqueries.COUNT_ELIG_MEMEBERS,tdMap.get("PLANNAME")));
	
			
		if(demoRecordCountMembershipTables.equals(tdMap1.get("demoDetailCounts"))){
		System.out.println("The Demo counts "+tdMap1.get("demoDetailCounts")+"are matched"+demoRecordCountMembershipTables);
		}
		else{
			Assert.fail("Demo records in FileData:"+tdMap1.get("demoDetailCounts")+"Not Matche with Demo_Membership:"+demoRecordCountMembershipTables);
		}
		if(eligRecordCountMembershipTables.equals(tdMap1.get("eligDetailCounts"))){
			System.out.println("The Elig counts are matched"+eligRecordCountMembershipTables);
		}
		else{
			Assert.fail("Elig records in FileData:"+tdMap1.get("eligDetailCounts")+"Not matched with ELIG_Membership:"+eligRecordCountMembershipTables);
		}
	}
	
	
	/**
	 * @purpose Method is used to verify whether the companyCode value is generated based on the planName xwalk table or not
	 * @param testCaseId
	 * @throws Exception
	 */
	public void companCodeValidation(String testCaseId) throws Exception {
		Statement statement;
		statement = getConnection();
		RAMCommonDBQuires rcmnDbobj=new RAMCommonDBQuires();
		Map<String, String> tdMap = new HashMap<String, String>();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String companyCode_xwalk = DbQueryHelperobj
				.getMultipleValues(String.format(MemberSyncDBqueries.COMPANY_CODE_XWALK,tdMap.get("PLANNAME")));

		String companyCode_MemberElig = DbQueryHelperobj
				.getMultipleValues(String.format(MemberSyncDBqueries.COMPANY_CODE_ELIG_MEMBERS,tdMap.get("PLANNAME")));
		if (companyCode_xwalk.equals(companyCode_MemberElig)) {
			System.out.println("The CompanyCode for Members:" + companyCode_MemberElig
					+ " is generated based on the Xwalk table:" + companyCode_xwalk);
		} else {
			Assert.fail("The CompanyCode for Members:" + companyCode_MemberElig
					+ " is generated based on the Xwalk table:" + companyCode_xwalk);

		}
	}
	
	/**
	 * @Purpose Method is used to verify whether the LOB value is generated based on the planName xwalk table or not
	 * @param testCaseId
	 * @throws Exception
	 */
	public void lobValidation(String testCaseId) throws Exception {
		Statement statement;
		statement = getConnection();
		RAMCommonDBQuires rcmnDbobj=new RAMCommonDBQuires();
		Map<String, String> tdMap = new HashMap<String, String>();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String lob_xwalk = DbQueryHelperobj
				.getMultipleValues(String.format(MemberSyncDBqueries.LOB_XWALK,tdMap.get("PLANNAME")));

		String lob_MemberElig = DbQueryHelperobj
				.getMultipleValues(String.format(MemberSyncDBqueries.LOB_ELIG_MEMBERS,tdMap.get("PLANNAME")));
		if (lob_xwalk.equals(lob_MemberElig)) {
			System.out.println("The LOB for Members:" + lob_MemberElig
					+ " is generated based on the Xwalk table:" + lob_xwalk);
		} else {
			Assert.fail("The LOB for Members:" + lob_MemberElig + " is generated based on the Xwalk table:"
					+ lob_xwalk);

		}
	}
	
	/**
	 * @purpose This method is used to validate whether the data is moved to the
	 *          RAM_membership tables from the Staging tables or not
	 * @throws Exception
	 */
	public void dataMovedtoMembershipTables(String testCaseId) throws Exception {
		Statement statement;
		statement = getConnection();
		RAMCommonDBQuires rcmnDbobj = new RAMCommonDBQuires();
		Map<String, String> tdMap = new HashMap<String, String>();
		tdMap = rcmnDbobj.getTestDataByTestCaseID("ELIGIBILITY_UPLOAD_TEST_DATA_ACTUAL_TABLE", testCaseId);
		String countDemo_File = DbQueryHelperobj
				.getMultipleValues(String.format(EligibilityDBqueries.COUNT_OF_RECORDS_FILTER,
						"ram_demographics_file_data", "plan_name", tdMap.get("PLANNAME")));
		String countElig_File = DbQueryHelperobj
				.getMultipleValues(String.format(EligibilityDBqueries.COUNT_OF_RECORDS_FILTER,
						"ram_eligibility_file_data", "plan_name", tdMap.get("PLANNAME")));
		String countDemoMembership = DbQueryHelperobj
				.getMultipleValues(String.format(MemberSyncDBqueries.COUNT_DEMO_MEMEBERS, tdMap.get("PLANNAME")));
		String countEligMembership = DbQueryHelperobj
				.getMultipleValues(String.format(MemberSyncDBqueries.COUNT_ELIG_MEMEBERS, tdMap.get("PLANNAME")));
		if (countDemo_File.equals("0") && countElig_File.equals("0") && !countDemoMembership.equals("0")
				&& !countEligMembership.equals("0")) {
			System.out.println("The data is successfuly moved from the staging tables to RAM membership tables");
		} else {
			Assert.fail("The data is not moved to the Membership tables after memberSync Job run");
		}

	}


}


