package com.optum.ram.membersync;

public class MemberSyncDBqueries {
	public static final String MEMBER_ELIG_VALD ="select subscriber_id from ram_member_demographics where subscriber_id='%s' and seq_member_id IN( "
+"select seq_member_id from ram_member_eligibility where %s)";
	
	public static final String COUNT_DEMO_MEMEBERS="select count (*) from ram_member_demographics where plan_name='%s'";
	public static final String COUNT_ELIG_MEMEBERS="select count(*) from ram_member_eligibility where plan_name='%s'";
	public static final String COMPANY_CODE_XWALK="select distinct COMPANY_CODE from ram_plan_name_xwalk where plan_name='%s'";
	public static final String COMPANY_CODE_ELIG_MEMBERS="select distinct COMPANY_CODE from ram_member_eligibility where plan_name='%s'";
	public static final String LOB_ELIG_MEMBERS="select distinct line_of_business from ram_member_eligibility where plan_name='%s'";
	public static final String LOB_XWALK="select distinct RAM_LOB from ram_plan_name_xwalk where plan_name='%s'";
	
}
